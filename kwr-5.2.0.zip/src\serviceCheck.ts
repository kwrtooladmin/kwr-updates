/**
 * serviceCheck.ts
 *
 * Shared service-verification engine. Free — no API, no LLM, runs locally.
 * Visits a business website (and one service/about subpage if the homepage is
 * thin), reads the visible text, and decides whether the searched service is
 * actually evidenced there, using a per-vertical keyword map plus a language
 * gate (only judges languages we have loaded; see langDetect.ts).
 *
 * Used by:
 *   - results-checker.ts (ships to users — sorts output into Verified / For Review)
 *   - verify-output.ts   (internal QA — measures accuracy on test panels)
 *
 * Verdicts:
 *   CONFIRMED — service keywords clearly present
 *   MISMATCH  — page read fine but no service keywords found
 *   UNCLEAR   — could not judge (unloaded language, bot-blocked, thin page)
 *   DEAD      — page did not load
 */

import { chromium } from 'playwright-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import { randomUserAgent } from './humanize';
import { languageGate } from './langDetect';

chromium.use(StealthPlugin());

export type Verdict = 'CONFIRMED' | 'UNCLEAR' | 'MISMATCH' | 'DEAD';

export const PAGE_TIMEOUT = 15000;
export const MAX_TEXT_CHARS = 8000;
export const MIN_TEXT_LENGTH = 80;
const SUBPAGE_KEYWORDS = ['service', 'about', 'what-we-do', 'our-work', 'expertise', 'solutions', 'offering'];

/**
 * Page-text keyword map per vertical.
 * A CONFIRMED verdict requires at least MIN_KEYWORD_HITS keywords from this list
 * to appear in the extracted page text (case-insensitive).
 *
 * Keywords reflect what service pages actually say, not just the business
 * category — e.g. a plumber's site will say "drain", "leak", "pipe".
 */
export const VERTICAL_KEYWORD_MAP: Record<string, string[]> = {
  // Home services
  // NL: schilder=painter, verfwerk/schilderwerk=paintwork, stukadoor=plasterer, gevel=facade
  'painting service':      ['paint', 'coat', 'colour', 'color', 'brush', 'wall', 'interior', 'exterior', 'stain', 'primer', 'decorator', 'schilder', 'verfwerk', 'schilderwerk', 'gevel', 'stukadoor', 'bouw'],
  'painting services':     ['paint', 'coat', 'colour', 'color', 'brush', 'wall', 'interior', 'exterior', 'stain', 'primer', 'decorator', 'schilder', 'verfwerk', 'schilderwerk', 'gevel', 'stukadoor', 'bouw'],
  'mover':                 ['mov', 'relocat', 'transport', 'pack', 'storage', 'truck', 'haul', 'removal', 'shipping', 'freight'],
  'movers':                ['mov', 'relocat', 'transport', 'pack', 'storage', 'truck', 'haul', 'removal', 'shipping', 'freight'],
  // TH: ตกแต่ง=decorate, รับเหมา=contractor, ก่อสร้าง=construct; VI: cải tạo=renovate, xây dựng=construction
  'renovation contractor': ['renovat', 'remodel', 'construct', 'build', 'contractor', 'interior', 'floor', 'tile', 'kitchen', 'bathroom', 'ตกแต่ง', 'รับเหมา', 'ก่อสร้าง', 'cải tạo', 'xây dựng', 'nội thất'],
  'plumbing':              ['plumb', 'drain', 'pipe', 'leak', 'faucet', 'toilet', 'water heater', 'sewer', 'clog', 'fixture'],
  'plumbing services':     ['plumb', 'drain', 'pipe', 'leak', 'faucet', 'toilet', 'water heater', 'sewer', 'clog', 'fixture'],
  'maid agency':           ['maid', 'clean', 'housekeep', 'domestic', 'helper', 'housekeeper', 'tidy', 'household'],
  'dog trainer':           ['dog', 'train', 'puppy', 'obedien', 'behavio', 'leash', 'command', 'pet', 'canine'],
  'dog trainers':          ['dog', 'train', 'puppy', 'obedien', 'behavio', 'leash', 'command', 'pet', 'canine'],
  // VI: nấm mốc=mold, xử lý=treatment, vệ sinh=cleaning, khử khuẩn=disinfect
  'mold removal':          ['mold', 'mould', 'remediat', 'spore', 'fungi', 'moisture', 'damp', 'water damage', 'restoration', 'nấm mốc', 'xử lý', 'vệ sinh', 'khử khuẩn', 'diệt nấm'],
  'home inspection':       ['inspect', 'assessm', 'report', 'survey', 'property', 'defect', 'structural', 'foundation', 'roof'],
  // TH: รักษาความปลอดภัย=security, ยาม=guard, เฝ้าระวัง=surveillance
  'security company':      ['security', 'guard', 'patrol', 'surveillance', 'protect', 'cctv', 'alarm', 'access control', 'officer', 'รักษาความปลอดภัย', 'ยาม', 'เฝ้าระวัง', 'บริการรักษา'],
  'door repair':           ['door', 'repair', 'hinge', 'lock', 'install', 'replace', 'garage door', 'entry door', 'frame'],
  'fireplace repair':      ['fireplace', 'chimney', 'hearth', 'flue', 'mantel', 'repair', 'clean', 'sweep', 'gas fireplace'],

  // Health & wellness
  'naturopath':            ['naturopath', 'naturopathic', 'holistic', 'herbal', 'nutrition', 'wellness', 'supplement', 'functional medicine'],
  'physiotherapy':         ['physiotherapy', 'physiotherapist', 'rehab', 'physical therapy', 'exercise', 'musculoskel', 'injury', 'manual therapy'],
  'kinesiologist':         ['kinesiology', 'kinesiologist', 'movement', 'rehab', 'exercise', 'biomechanics', 'injury', 'sport'],
  'kinesiologists':        ['kinesiology', 'kinesiologist', 'movement', 'rehab', 'exercise', 'biomechanics', 'injury', 'sport'],
  'yoga studios':          ['yoga', 'pose', 'class', 'studio', 'meditation', 'flow', 'pilates', 'instructor', 'session'],
  'yoga studio':           ['yoga', 'pose', 'class', 'studio', 'meditation', 'flow', 'pilates', 'instructor', 'session'],
  'coolsculpting':         ['coolsculpt', 'fat freez', 'body contour', 'cryolipolysis', 'aesthetic', 'non-surgical', 'treatment', 'medspa', 'med spa'],
  'blood test':            ['blood', 'test', 'lab', 'diagnostic', 'sample', 'result', 'panel', 'analysis', 'specimen'],

  // Professional services
  'immigration agency':    ['immigrat', 'visa', 'permit', 'citizenship', 'permanent resident', 'work permit', 'study permit', 'application'],
  'tax consultant':        ['tax', 'return', 'filing', 'irs', 'cra', 'ato', 'income tax', 'deduction', 'accounting', 'gst', 'hst'],
  'tax consultants':       ['tax', 'return', 'filing', 'irs', 'cra', 'ato', 'income tax', 'deduction', 'accounting', 'gst', 'hst'],
  'bookkeeping':           ['bookkeep', 'accounting', 'ledger', 'payroll', 'reconcil', 'financial statement', 'accounts payable', 'quickbooks'],
  'mortgage broker':       ['mortgage', 'loan', 'lender', 'interest rate', 'refinanc', 'pre-approv', 'down payment', 'amortiz'],
  'life coach':            ['coach', 'goal', 'mindset', 'transform', 'motivat', 'session', 'accountability', 'clarity', 'life coach'],

  // Beauty & personal care
  'hair salon':            ['hair', 'cut', 'colour', 'color', 'style', 'blow dry', 'highlight', 'keratin', 'treatment', 'salon'],
  'barbershop':            ['barber', 'haircut', 'shave', 'beard', 'fade', 'trim', 'men', 'grooming'],

  // Education & fitness
  'dance class':           ['dance', 'class', 'lesson', 'studio', 'choreograph', 'instructor', 'beginner', 'enroll'],
  'dance classes':         ['dance', 'class', 'lesson', 'studio', 'choreograph', 'instructor', 'beginner', 'enroll'],
  'ballet lesson':         ['ballet', 'barre', 'pointe', 'dance', 'class', 'lesson', 'studio', 'instructor'],
  'ballet lessons':        ['ballet', 'barre', 'pointe', 'dance', 'class', 'lesson', 'studio', 'instructor'],
  'latin dance':           ['salsa', 'bachata', 'latin', 'dance', 'class', 'lesson', 'studio', 'instructor'],
  'online tutor':          ['tutor', 'tutoring', 'lesson', 'student', 'subject', 'math', 'english', 'homework', 'academic', 'online'],
  'online tutors':         ['tutor', 'tutoring', 'lesson', 'student', 'subject', 'math', 'english', 'homework', 'academic', 'online'],

  // Food & drink
  'pho restaurant':        ['pho', 'vietnamese', 'noodle', 'soup', 'broth', 'beef', 'restaurant', 'menu', 'dine'],
  'pho restaurants':       ['pho', 'vietnamese', 'noodle', 'soup', 'broth', 'beef', 'restaurant', 'menu', 'dine'],

  // Technology
  'pos system':            ['pos', 'point of sale', 'payment', 'terminal', 'receipt', 'inventory', 'checkout', 'retail', 'software'],

  // Events
  'wedding photographer':  ['wedding', 'photo', 'portrait', 'couple', 'bride', 'groom', 'ceremony', 'album', 'gallery'],
  'funeral service':       ['funeral', 'service', 'burial', 'cremation', 'memorial', 'casket', 'grief', 'arrangement'],

  // Automotive
  'engine repair':         ['engine', 'repair', 'mechanic', 'auto', 'car', 'vehicle', 'diagnos', 'oil', 'motor'],

  // Signage
  'digital signage':       ['sign', 'display', 'digital', 'led', 'screen', 'graphic', 'print', 'banner', 'billboard'],

  // Added 2026-06-29 — verticals seen in Panel A/B that previously fell to manual
  // review. New keys only (no existing vertical changed), so prior metrics are
  // unaffected. Keywords kept specific to avoid false confirmations.
  'chiropractors':         ['chiropract', 'spine', 'spinal', 'adjustment', 'back pain', 'subluxation', 'posture', 'neck pain'],
  'chiropractor':          ['chiropract', 'spine', 'spinal', 'adjustment', 'back pain', 'subluxation', 'posture', 'neck pain'],
  'vet':                   ['veterinar', 'vet', 'animal hospital', 'pet', 'vaccin', 'spay', 'neuter', 'clinic', 'wellness exam'],
  'wig':                   ['wig', 'hairpiece', 'lace front', 'lace wig', 'human hair wig', 'synthetic wig', 'hair replacement'],
  'pet sitter':            ['pet', 'sitting', 'boarding', 'daycare', 'dog', 'cat', 'walking', 'care', 'kennel'],
  'catering':              ['cater', 'menu', 'event', 'buffet', 'canape', 'banquet', 'platter', 'function'],
  'dj':                    ['dj', 'disc jockey', 'event', 'party', 'wedding', 'sound', 'lighting', 'mix', 'entertainment'],
  'preschool':             ['preschool', 'childcare', 'early learning', 'toddler', 'nursery', 'kindergarten', 'daycare', 'kids'],
  'kindergarten':          ['kindergarten', 'early learning', 'childcare', 'preschool', 'nursery', 'kids', 'toddler'],
  'nursery schools':       ['nursery', 'preschool', 'childcare', 'early learning', 'toddler', 'kindergarten', 'kids'],
  'translation service':   ['translat', 'interpret', 'language', 'sworn', 'certified', 'document', 'localization'],
  'translation services':  ['translat', 'interpret', 'language', 'sworn', 'certified', 'document', 'localization'],
  'driving school':        ['driving', 'lesson', 'instructor', 'licence', 'license', 'learner', 'road test', 'driver'],
  'software developer':    ['software', 'develop', 'app', 'web', 'application', 'custom', 'solution', 'platform', 'coding'],
  'software company':      ['software', 'develop', 'app', 'web', 'application', 'custom', 'solution', 'platform', 'saas'],
  'accountant':           ['account', 'tax', 'audit', 'bookkeep', 'financial', 'payroll', 'advisory', 'vat'],
  'guitar lesson':         ['guitar', 'lesson', 'music', 'instructor', 'beginner', 'chord', 'student', 'tuition'],
  'freight forwarder':     ['freight', 'forward', 'logistics', 'shipping', 'cargo', 'customs', 'import', 'export', 'supply chain'],
  'private investigator':  ['investigat', 'detective', 'surveillance', 'background check', 'fraud', 'evidence', 'tracing'],
  'personal injury lawyer':['personal injury', 'accident', 'compensation', 'claim', 'negligence', 'injury', 'settlement'],
  'vinyl flooring':        ['vinyl', 'flooring', 'floor', 'spc', 'lvt', 'plank', 'laminate', 'install'],
  'epoxy flooring':        ['epoxy', 'floor', 'coating', 'resin', 'polyurethane', 'industrial', 'concrete', 'garage'],
  'spray foam insulation': ['spray foam', 'insulation', 'polyurethane', 'foam', 'thermal', 'r-value', 'air seal'],
  'chiropractic':          ['chiropract', 'spine', 'spinal', 'adjustment', 'back pain', 'subluxation', 'posture'],

  // Added 2026-07 — verticals that produced UNCLEAR/wrong-confirm on fresh Panel B
  // (13 known errors + 15 unmapped verticals). Keywords are deliberately narrow to
  // discriminate against the adjacent-but-wrong business types the errors showed:
  // generic pest control (not mosquito-specific), WordPress/IT sites (not hosting
  // providers), dog groomers (not daycare/boarding).
  'mosquito control':     ['mosquito', 'larvicid', 'fogging', 'midge', 'bite prevention'],
  'web hosting':          ['hosting', 'server', 'domain', 'uptime', 'cpanel', 'bandwidth', 'vps'],
  'dog daycare':          ['daycare', 'day care', 'boarding', 'kennel', 'playgroup', 'overnight'],
  'cat grooming':         ['cat', 'feline', 'groom', 'nail trim', 'de-shed'],
  'janitorial':           ['janitorial', 'commercial cleaning', 'office cleaning', 'custodial', 'facility'],
  'courier':              ['courier', 'parcel', 'same-day', 'dispatch', 'shipment', 'delivery service'],
  'wedding caterer':      ['wedding', 'catering', 'menu', 'reception', 'banquet', 'event catering'],
  'bed bug exterminator': ['bed bug', 'bedbug', 'heat treatment', 'extermin', 'infestation'],
  'seo':                  ['seo', 'search engine optimi', 'ranking', 'keyword', 'backlink', 'serp', 'organic traffic'],
  'structural engineer':  ['structural engineer', 'structural', 'load bearing', 'engineering', 'inspection report'],
  'window tinting':       ['tint', 'window film', 'ceramic tint', 'privacy film'],
  'furniture mover':      ['mover', 'moving', 'relocat', 'packing', 'furniture removal'],
  'gynaecologist':        ['gynaecolog', 'gynecolog', 'obstetric', 'obgyn', 'ob-gyn', 'prenatal', "women's health"],
  'photography studio':   ['photograph', 'studio', 'portrait', 'headshot', 'session', 'shoot'],
  'prenatal massage':     ['prenatal', 'pregnancy', 'maternity', 'massage', 'expecting'],
};

export const MIN_KEYWORD_HITS = 2;

export function judgeWithKeywords(vertical: string, pageText: string): { verdict: Verdict; notes: string } {
  const key = vertical.toLowerCase().trim();
  const keywords = VERTICAL_KEYWORD_MAP[key];

  if (!keywords) {
    // No keyword map for this vertical — fall back to checking if the vertical
    // term itself appears in the page text
    const verticalWords = key.split(/\s+/).filter(w => w.length > 3);
    const hits = verticalWords.filter(w => pageText.toLowerCase().includes(w));
    if (hits.length > 0) {
      return { verdict: 'CONFIRMED', notes: `Vertical term "${hits[0]}" found on page (no keyword map for "${vertical}")` };
    }
    return { verdict: 'UNCLEAR', notes: `No keyword map for "${vertical}" and vertical term not found on page` };
  }

  const lowerText = pageText.toLowerCase();
  const matched = keywords.filter(kw => lowerText.includes(kw.toLowerCase()));

  if (matched.length >= MIN_KEYWORD_HITS) {
    return { verdict: 'CONFIRMED', notes: `${matched.length} service keywords matched: ${matched.slice(0, 4).join(', ')}` };
  }

  if (matched.length === 1) {
    return { verdict: 'UNCLEAR', notes: `Only 1 keyword matched (${matched[0]}) — not enough to confirm` };
  }

  return { verdict: 'MISMATCH', notes: `No service keywords for "${vertical}" found on page` };
}

async function extractText(page: any): Promise<string> {
  try {
    return await page.evaluate(() => {
      const skipTags = new Set(['script', 'style', 'noscript', 'iframe', 'svg']);
      function walk(node: Node): string {
        if (node.nodeType === Node.TEXT_NODE) return (node.textContent || '').trim();
        if (node.nodeType !== Node.ELEMENT_NODE) return '';
        const el = node as Element;
        if (skipTags.has(el.tagName.toLowerCase())) return '';
        const style = window.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden') return '';
        return Array.from(node.childNodes).map(walk).filter(Boolean).join(' ');
      }
      return walk(document.body || document.documentElement);
    });
  } catch {
    return '';
  }
}

async function findSubpageUrl(page: any, baseOrigin: string): Promise<string | null> {
  try {
    const hrefs: string[] = await page.evaluate((keywords: string[]) => {
      const anchors = Array.from(document.querySelectorAll('a[href]')) as HTMLAnchorElement[];
      return anchors.map(a => a.href).filter(h => {
        try {
          const u = new URL(h);
          const p = u.pathname.toLowerCase();
          return keywords.some(kw => p.includes(kw));
        } catch { return false; }
      });
    }, SUBPAGE_KEYWORDS);

    // Pick a same-origin subpage link
    for (const href of hrefs) {
      try {
        const u = new URL(href);
        if (u.origin === baseOrigin && u.pathname !== '/' && u.pathname !== '') {
          return href;
        }
      } catch { /* skip */ }
    }
  } catch { /* skip */ }
  return null;
}

export async function fetchPageText(url: string): Promise<{ text: string; dead: boolean }> {
  const browser = await (chromium as any).launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
  });

  try {
    const context = await browser.newContext({
      userAgent: randomUserAgent(),
      viewport: { width: 1280, height: 800 },
      locale: 'en-US',
    });
    const page = await context.newPage();

    try {
      const resp = await page.goto(url, { timeout: PAGE_TIMEOUT, waitUntil: 'domcontentloaded' });
      if (!resp || resp.status() >= 400) {
        return { text: '', dead: true };
      }
      await page.waitForTimeout(2000);
    } catch {
      return { text: '', dead: true };
    }

    const homeText = await extractText(page);

    // If homepage text is thin, try one service/about subpage
    let subText = '';
    if (homeText.length < MIN_TEXT_LENGTH * 5) {
      try {
        const origin = new URL(url).origin;
        const subUrl = await findSubpageUrl(page, origin);
        if (subUrl) {
          const subResp = await page.goto(subUrl, { timeout: PAGE_TIMEOUT, waitUntil: 'domcontentloaded' });
          if (subResp && subResp.status() < 400) {
            await page.waitForTimeout(1500);
            subText = await extractText(page);
          }
        }
      } catch { /* subpage optional — ignore errors */ }
    }

    const combined = (homeText + ' ' + subText).trim();
    if (!combined) return { text: '', dead: true };
    return { text: combined.slice(0, MAX_TEXT_CHARS), dead: false };
  } finally {
    await browser.close();
  }
}

/**
 * High-level check for one business: fetch the site, apply the language gate,
 * then keyword-judge. Returns a verdict and a short human-readable note.
 */
export async function checkBusiness(url: string, vertical: string): Promise<{ verdict: Verdict; notes: string }> {
  const trimmed = (url || '').trim();
  if (!trimmed) {
    return { verdict: 'DEAD', notes: 'No website URL' };
  }

  const { text, dead } = await fetchPageText(trimmed);
  if (dead) {
    return { verdict: 'DEAD', notes: 'Site did not load' };
  }
  if (!text || text.length < MIN_TEXT_LENGTH) {
    return { verdict: 'UNCLEAR', notes: 'Page loaded but too little text extracted (likely JS-heavy or bot-blocked)' };
  }

  // Only keyword-judge pages in a language we have loaded keywords for.
  const { lang, supported } = languageGate(text);
  if (!supported) {
    return { verdict: 'UNCLEAR', notes: `Page language "${lang}" not loaded in checker — needs manual review` };
  }

  return judgeWithKeywords(vertical, text);
}

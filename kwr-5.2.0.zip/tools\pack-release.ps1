# Packages the current tool into a release zip for the auto-updater.
#
# Usage (from the project folder):
#   powershell -ExecutionPolicy Bypass -File tools\pack-release.ps1 -Version 5.2.0
#
# Produces:  release\kwr-<version>.zip
# Prints:    the exact version.json block to paste into the GitHub kwr-updates repo
#            (after you upload the zip to a GitHub Release and copy its download URL).

param(
  [Parameter(Mandatory = $true)][string]$Version
)

$ErrorActionPreference = 'Stop'
$root    = Split-Path -Parent $PSScriptRoot
$staging = Join-Path $env:TEMP "kwr-pack-$Version"
$relDir  = Join-Path $root 'release'
$zipPath = Join-Path $relDir "kwr-$Version.zip"

# Things that must NOT ship (deps are reinstalled; the rest is user data).
$excludeDirs  = @('node_modules', 'output', 'baseline', '.git', 'release', 'dist')
$excludeFiles = @('.env', 'run-history.json', 'update.log')

Write-Host "Staging files..." -ForegroundColor Cyan
if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
New-Item -ItemType Directory -Path $staging | Out-Null

$xd = $excludeDirs | ForEach-Object { Join-Path $root $_ }
$roboArgs = @($root, $staging, '/E', '/NFL', '/NDL', '/NJH', '/NJS', '/NP',
              '/XD') + $xd + @('/XF') + $excludeFiles + @('.update-backup-*')
& robocopy @roboArgs | Out-Null
if ($LASTEXITCODE -ge 8) { throw "robocopy failed ($LASTEXITCODE)" }

# Stamp the version into the staged package.json so local + remote agree.
$pkgPath = Join-Path $staging 'package.json'
$pkg = Get-Content $pkgPath -Raw | ConvertFrom-Json
$pkg.version = $Version
# Write WITHOUT a BOM - a UTF-8 BOM breaks JSON.parse in tools that read package.json.
$json = ($pkg | ConvertTo-Json -Depth 20)
[System.IO.File]::WriteAllText($pkgPath, $json, (New-Object System.Text.UTF8Encoding($false)))

Write-Host "Compressing..." -ForegroundColor Cyan
if (-not (Test-Path $relDir)) { New-Item -ItemType Directory -Path $relDir | Out-Null }
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Compress-Archive -Path (Join-Path $staging '*') -DestinationPath $zipPath -Force

$hash = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLower()
Remove-Item $staging -Recurse -Force

# Write the ready-to-edit version.json next to the zip.
$snippet = [ordered]@{
  version = $Version
  message = 'You are on the latest version.'
  zipUrl  = 'ZIP_URL_HERE'
  sha256  = $hash
}
$snippetPath = Join-Path $relDir 'version.json'
$snippet | ConvertTo-Json | Set-Content $snippetPath -Encoding utf8

Write-Host ''
Write-Host "Built: $zipPath" -ForegroundColor Green
Write-Host "SHA256: $hash" -ForegroundColor Green
Write-Host ''
Write-Host 'NEXT STEPS:' -ForegroundColor Yellow
Write-Host '  1. Create a GitHub Release on the kwr-updates repo and upload the zip above.'
Write-Host '  2. Copy the uploaded asset download URL.'
Write-Host ('  3. Open ' + $snippetPath)
Write-Host '     replace ZIP_URL_HERE with that URL, then paste the whole file'
Write-Host '     into version.json in the kwr-updates repo and commit.'
Write-Host ''
Write-Host 'Generated version.json (zipUrl still needs the real URL):' -ForegroundColor Cyan
Get-Content $snippetPath | Write-Host

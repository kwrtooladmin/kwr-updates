# One-step publisher for KWR auto-updates.
#
# What it does (fully automated):
#   1. Builds the release zip from the current tool folder.
#   2. Copies the zip into your local clone of the kwr-updates repo.
#   3. Writes version.json (version + raw download URL + checksum).
#   4. Commits and pushes - every user tool sees the update on next launch.
#
# Usage (from the project folder):
#   powershell -ExecutionPolicy Bypass -File tools\publish-update.ps1 -Version 5.3.0
#
# If you omit -Version, it uses the version already in package.json.

param(
  [string]$Version,
  [string]$RepoDir = "C:\Users\User\Desktop\kwr-updates-repo",
  [string]$RepoUser = "kwrtooladmin",
  [string]$RepoName = "kwr-updates",
  [string]$Branch   = "main"
)

$ErrorActionPreference = 'Stop'
$toolRoot = Split-Path -Parent $PSScriptRoot

# Default version = whatever package.json says.
if (-not $Version) {
  $pkg = Get-Content (Join-Path $toolRoot 'package.json') -Raw | ConvertFrom-Json
  $Version = $pkg.version
}

if (-not (Test-Path $RepoDir)) {
  throw "Repo clone not found at $RepoDir. Clone it first:  git clone https://github.com/$RepoUser/$RepoName.git `"$RepoDir`""
}

Write-Host "Publishing v$Version ..." -ForegroundColor Cyan

# 1. Build the zip.
& powershell -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'pack-release.ps1') -Version $Version | Out-Null
$zipName = "kwr-$Version.zip"
$zipPath = Join-Path $toolRoot "release\$zipName"
if (-not (Test-Path $zipPath)) { throw "Build failed - $zipPath not found." }

# 2. Copy zip into the repo.
Copy-Item $zipPath (Join-Path $RepoDir $zipName) -Force

# 3. Write version.json (no BOM).
$hash = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLower()
$rawUrl = "https://raw.githubusercontent.com/$RepoUser/$RepoName/$Branch/$zipName"
$manifest = [ordered]@{
  version = $Version
  message = 'You are on the latest version.'
  zipUrl  = $rawUrl
  sha256  = $hash
}
$json = ($manifest | ConvertTo-Json)
[System.IO.File]::WriteAllText((Join-Path $RepoDir 'version.json'), $json, (New-Object System.Text.UTF8Encoding($false)))

# 4. Ensure a commit identity exists (repo-local, does not touch global git config).
$existingEmail = (& git -C $RepoDir config user.email)
if (-not $existingEmail) {
  & git -C $RepoDir config user.email "kwrtooladmin@users.noreply.github.com"
  & git -C $RepoDir config user.name  "KWR Tool Admin"
  Write-Host "Set a commit identity for this repo." -ForegroundColor DarkGray
}

# 5. Commit and push (with hard success checks so we never falsely report success).
& git -C $RepoDir add -A
& git -C $RepoDir commit -m "Release v$Version"
if ($LASTEXITCODE -ne 0) { throw "git commit failed - nothing was published. See the message above." }

Write-Host "Pushing to GitHub..." -ForegroundColor Cyan
& git -C $RepoDir push origin $Branch
if ($LASTEXITCODE -ne 0) { throw "git push failed. If this was a browser login, complete it and run the script again." }

# Confirm the local branch actually matches the remote.
& git -C $RepoDir fetch origin $Branch | Out-Null
$local  = (& git -C $RepoDir rev-parse HEAD).Trim()
$remote = (& git -C $RepoDir rev-parse "origin/$Branch").Trim()
if ($local -ne $remote) { throw "Push did not land - local and remote differ. Nothing was published." }

Write-Host ""
Write-Host "Published v$Version successfully." -ForegroundColor Green
Write-Host "Verified live on GitHub (commit $($local.Substring(0,7)))." -ForegroundColor Green
Write-Host "Users will be offered the update the next time they launch the tool."

'use strict';

require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const fs   = require('fs');
const path = require('path');
const os   = require('os');
const nodemailer = require('nodemailer');

const MACHINE_NAME    = os.hostname();
const BASELINE_DIR    = path.join(__dirname, '..', 'baseline');
const REPORT_PATH     = path.join(BASELINE_DIR, `baseline-report-${MACHINE_NAME}.csv`);
const SUMMARY_PATH    = path.join(BASELINE_DIR, `baseline-summary-${MACHINE_NAME}.csv`);
const DISCARDS_PATH   = path.join(BASELINE_DIR, `baseline-discards-${MACHINE_NAME}.csv`);
const RESULTS_PATH    = path.join(BASELINE_DIR, `baseline-verified-results-${MACHINE_NAME}.csv`);

// ── QA-mode guard ─────────────────────────────────────────────────────────────
// A machine flagged QA (a `.qa-mode` file in the project root) never sends the
// report, so test/QA runs stay out of the real reporting — even if a previously
// registered scheduled task fires. The flag is excluded from published builds.
if (fs.existsSync(path.join(__dirname, '..', '.qa-mode'))) {
  console.log('[qa-mode] This machine is flagged QA — skipping email report.');
  process.exit(0);
}

// ── Validate config ───────────────────────────────────────────────────────────
const EMAIL_FROM = process.env.KWR_EMAIL_FROM;
const EMAIL_TO   = process.env.KWR_EMAIL_TO;
const EMAIL_PASS = process.env.KWR_EMAIL_PASS;

if (!EMAIL_FROM || !EMAIL_TO || !EMAIL_PASS) {
  console.error('[email] Missing KWR_EMAIL_FROM, KWR_EMAIL_TO, or KWR_EMAIL_PASS in .env — skipping report.');
  process.exit(0);
}

// ── Parse CSV ─────────────────────────────────────────────────────────────────
function parseCsv(filePath) {
  if (!fs.existsSync(filePath)) return [];
  const lines = fs.readFileSync(filePath, 'utf8').split('\n').filter(Boolean);
  if (lines.length < 2) return [];
  const headers = lines[0].split(',');
  return lines.slice(1).map(line => {
    const cols = line.split(',');
    const obj = {};
    headers.forEach((h, i) => { obj[h.trim()] = (cols[i] ?? '').trim(); });
    return obj;
  });
}

// ── Get yesterday's date string ───────────────────────────────────────────────
function yesterdayStr() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return d.toISOString().slice(0, 10);
}

function lastWeekStr() {
  const d = new Date();
  d.setDate(d.getDate() - 8); // same weekday last week relative to yesterday
  return d.toISOString().slice(0, 10);
}

// ── Build report ──────────────────────────────────────────────────────────────
function buildReport() {
  const allRows  = parseCsv(REPORT_PATH);
  const summary  = parseCsv(SUMMARY_PATH);
  const yesterday = yesterdayStr();
  const lastWeek  = lastWeekStr();

  // Rows from yesterday
  const todayRows = allRows.filter(r => r['Date'] === yesterday);

  if (todayRows.length === 0) {
    return { hasRuns: false, todayRows, summary, yesterday };
  }

  const total   = todayRows.length;
  const pass    = todayRows.filter(r => r['Result'] === 'PASS').length;
  const partial = todayRows.filter(r => r['Result'] === 'PARTIAL').length;
  const thin    = todayRows.filter(r => r['Result'] === 'THIN MARKET').length;
  const fail    = todayRows.filter(r => r['Result'] === 'FAIL').length;
  const passRate = total > 0 ? Math.round((pass / total) * 100) : 0;

  // Week-over-week: same day last week
  const lastWeekRows = allRows.filter(r => r['Date'] === lastWeek);
  let lastWeekPassRate = null;
  let wow = null; // week-over-week delta
  if (lastWeekRows.length > 0) {
    const lwPass = lastWeekRows.filter(r => r['Result'] === 'PASS').length;
    lastWeekPassRate = Math.round((lwPass / lastWeekRows.length) * 100);
    wow = passRate - lastWeekPassRate;
  }

  const fails      = todayRows.filter(r => r['Result'] === 'FAIL');
  const partials   = todayRows.filter(r => r['Result'] === 'PARTIAL');
  const needsAction = todayRows.filter(r => r['Notes'] === 'Check category filter');

  return { hasRuns: true, total, pass, partial, thin, fail, passRate, lastWeekPassRate, lastWeek, wow, fails, partials, needsAction, todayRows, summary, yesterday };
}

// ── Build HTML email ──────────────────────────────────────────────────────────
function buildHtml(report) {
  const { hasRuns, total, pass, partial, thin, fail, passRate, fails, partials, needsAction, todayRows, summary, yesterday } = report;

  if (!hasRuns) {
    return `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px">
        <h2 style="color:#e8a838">KWR Daily Report — ${yesterday}</h2>
        <p style="color:#666">No runs were recorded yesterday.</p>
      </div>
    `;
  }

  const { lastWeekPassRate, lastWeek, wow } = report;
  const passColor   = passRate >= 80 ? '#2e8f56' : passRate >= 60 ? '#b87c10' : '#c94040';
  const statusEmoji = passRate >= 80 ? '✅' : passRate >= 60 ? '⚠️' : '🔴';

  const wowHtml = wow !== null
    ? (() => {
        const arrow  = wow > 0 ? '▲' : wow < 0 ? '▼' : '→';
        const color  = wow > 0 ? '#2e8f56' : wow < 0 ? '#c94040' : '#888';
        const label  = wow > 0 ? `+${wow}pp` : wow < 0 ? `${wow}pp` : 'no change';
        return `<div style="font-size:13px;color:${color};margin-top:6px;font-weight:600">${arrow} ${label} vs last week (${lastWeekPassRate}% on ${lastWeek})</div>`;
      })()
    : `<div style="font-size:12px;color:#aaa;margin-top:6px">No data from last week to compare</div>`;

  const runsTable = todayRows.map(r => {
    const color = r['Result'] === 'PASS' ? '#2e8f56' : r['Result'] === 'FAIL' ? '#c94040' : r['Result'] === 'PARTIAL' ? '#b87c10' : '#666';
    return `
      <tr>
        <td style="padding:6px 10px;border-bottom:1px solid #eee;color:#999;font-size:12px">${r['Machine'] || '—'}</td>
        <td style="padding:6px 10px;border-bottom:1px solid #eee">${r['Vertical']}</td>
        <td style="padding:6px 10px;border-bottom:1px solid #eee">${r['City']}</td>
        <td style="padding:6px 10px;border-bottom:1px solid #eee">${r['Site']}</td>
        <td style="padding:6px 10px;border-bottom:1px solid #eee;text-align:center">${r['Verified']}</td>
        <td style="padding:6px 10px;border-bottom:1px solid #eee;font-weight:600;color:${color}">${r['Result']}</td>
        <td style="padding:6px 10px;border-bottom:1px solid #eee;color:#999;font-size:12px">${r['Top Discard Reason'] || '—'}</td>
      </tr>
    `;
  }).join('');

  const summaryTable = summary.map(r => {
    const rate = parseInt(r['Pass Rate %'] ?? '0');
    const rateColor = rate >= 80 ? '#2e8f56' : rate >= 60 ? '#b87c10' : '#c94040';
    return `
      <tr>
        <td style="padding:6px 10px;border-bottom:1px solid #eee">${r['Vertical']}</td>
        <td style="padding:6px 10px;border-bottom:1px solid #eee;text-align:center">${r['Total Runs']}</td>
        <td style="padding:6px 10px;border-bottom:1px solid #eee;text-align:center;color:#2e8f56">${r['Pass']}</td>
        <td style="padding:6px 10px;border-bottom:1px solid #eee;text-align:center;color:#b87c10">${r['Partial']}</td>
        <td style="padding:6px 10px;border-bottom:1px solid #eee;text-align:center;color:#c94040">${r['Fail']}</td>
        <td style="padding:6px 10px;border-bottom:1px solid #eee;text-align:center;font-weight:600;color:${rateColor}">${r['Pass Rate %']}</td>
        <td style="padding:6px 10px;border-bottom:1px solid #eee;color:#999;font-size:12px">${r['Last Run Date']}</td>
      </tr>
    `;
  }).join('');

  const actionBlock = needsAction.length > 0 ? `
    <div style="background:#fff8e1;border-left:4px solid #e8a838;padding:12px 16px;margin:20px 0;border-radius:4px">
      <strong>⚠️ Action needed — category filter issues:</strong>
      <ul style="margin:8px 0 0;padding-left:20px">
        ${needsAction.map(r => `<li>${r['Vertical']} — ${r['City']} (${r['Site']})</li>`).join('')}
      </ul>
      <p style="margin:8px 0 0;font-size:13px;color:#666">These runs returned FAIL or PARTIAL and the top discard reason was "Wrong category". Adding the vertical to <code>categoryFilter.ts</code> will fix it.</p>
    </div>
  ` : '';

  return `
    <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;max-width:680px;margin:0 auto;padding:24px;color:#1a1a1a">

      <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:24px">
        <tr>
          <td>
            <table cellpadding="0" cellspacing="0" border="0">
              <tr>
                <td style="background:#e8a838;width:32px;height:32px;border-radius:6px;text-align:center;vertical-align:middle;font-size:16px">▦</td>
                <td style="padding-left:12px">
                  <div style="font-size:18px;font-weight:700">KWR Selector — Daily Report</div>
                  <div style="font-size:13px;color:#888">${yesterday}</div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>

      <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:24px">
        <tr>
          ${[
            ['Runs', total, '#1a1a1a'],
            ['Pass', pass, '#2e8f56'],
            ['Partial', partial, '#b87c10'],
            ['Thin', thin, '#666'],
            ['Fail', fail, '#c94040'],
          ].map(([label, val, color]) => `
            <td width="20%" style="padding:4px">
              <table width="100%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                  <td style="background:#f7f5f2;border-radius:8px;padding:14px;text-align:center">
                    <div style="font-size:24px;font-weight:700;color:${color}">${val}</div>
                    <div style="font-size:11px;color:#888;text-transform:uppercase;letter-spacing:0.05em;margin-top:2px">${label}</div>
                  </td>
                </tr>
              </table>
            </td>
          `).join('')}
        </tr>
      </table>

      <div style="background:#f7f5f2;border-radius:8px;padding:16px;margin-bottom:24px;text-align:center">
        <div style="font-size:32px;font-weight:700;color:${passColor}">${statusEmoji} ${passRate}% pass rate</div>
        <div style="font-size:13px;color:#888;margin-top:4px">yesterday's runs</div>
        ${wowHtml}
      </div>

      ${actionBlock}

      <h3 style="font-size:14px;text-transform:uppercase;letter-spacing:0.06em;color:#888;margin:24px 0 10px">Yesterday's Runs</h3>
      <table style="width:100%;border-collapse:collapse;font-size:13px">
        <thead>
          <tr style="background:#f7f5f2">
            <th style="padding:8px 10px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#888">Machine</th>
            <th style="padding:8px 10px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#888">Vertical</th>
            <th style="padding:8px 10px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#888">City</th>
            <th style="padding:8px 10px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#888">Site</th>
            <th style="padding:8px 10px;text-align:center;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#888">Verified</th>
            <th style="padding:8px 10px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#888">Result</th>
            <th style="padding:8px 10px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#888">Discard Reason</th>
          </tr>
        </thead>
        <tbody>${runsTable}</tbody>
      </table>

      ${summary.length > 0 ? `
        <h3 style="font-size:14px;text-transform:uppercase;letter-spacing:0.06em;color:#888;margin:32px 0 10px">All-Time Summary by Vertical</h3>
        <table style="width:100%;border-collapse:collapse;font-size:13px">
          <thead>
            <tr style="background:#f7f5f2">
              <th style="padding:8px 10px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#888">Vertical</th>
              <th style="padding:8px 10px;text-align:center;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#888">Runs</th>
              <th style="padding:8px 10px;text-align:center;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#2e8f56">Pass</th>
              <th style="padding:8px 10px;text-align:center;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#b87c10">Partial</th>
              <th style="padding:8px 10px;text-align:center;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#c94040">Fail</th>
              <th style="padding:8px 10px;text-align:center;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#888">Pass Rate</th>
              <th style="padding:8px 10px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#888">Last Run</th>
            </tr>
          </thead>
          <tbody>${summaryTable}</tbody>
        </table>
      ` : ''}

      <div style="margin-top:32px;padding-top:16px;border-top:1px solid #eee;font-size:11px;color:#aaa;text-align:center">
        KWR Selector Tool — Admin Report · Sent automatically at 7AM PH time
      </div>
    </div>
  `;
}

// ── Send email ────────────────────────────────────────────────────────────────
async function sendReport() {
  const report = buildReport();
  // Strip excess whitespace to keep email under Gmail's 102KB clip threshold
  const html = buildHtml(report).replace(/\n\s*/g, ' ').replace(/>\s+</g, '><').trim();
  const subject = report.hasRuns
    ? `KWR Daily Report — ${report.yesterday} — ${report.passRate}% pass rate (${report.total} runs)`
    : `KWR Daily Report — ${yesterdayStr()} — No runs recorded`;

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: EMAIL_FROM,
      pass: EMAIL_PASS,
    },
  });

  const attachments = [];
  if (fs.existsSync(REPORT_PATH)) {
    attachments.push({ filename: `baseline-report-${MACHINE_NAME}.csv`, path: REPORT_PATH });
  }
  if (fs.existsSync(SUMMARY_PATH)) {
    attachments.push({ filename: `baseline-summary-${MACHINE_NAME}.csv`, path: SUMMARY_PATH });
  }
  if (fs.existsSync(DISCARDS_PATH)) {
    attachments.push({ filename: `baseline-discards-${MACHINE_NAME}.csv`, path: DISCARDS_PATH });
  }
  if (fs.existsSync(RESULTS_PATH)) {
    attachments.push({ filename: `baseline-verified-results-${MACHINE_NAME}.csv`, path: RESULTS_PATH });
  }

  await transporter.sendMail({
    from: `"KWR Admin" <${EMAIL_FROM}>`,
    to: EMAIL_TO,
    subject,
    html,
    attachments,
  });

  console.log(`[email] Report sent to ${EMAIL_TO} — subject: ${subject}`);
}

sendReport().catch(err => {
  // Never print credentials in error messages
  const safeMsg = String(err.message || err).replace(EMAIL_PASS || '', '***');
  console.error(`[email] Failed to send report: ${safeMsg}`);
  process.exit(1);
});

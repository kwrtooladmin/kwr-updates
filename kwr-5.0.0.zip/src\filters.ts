import { RawListing, ScoredListing, EnrichedListing, AppConfig } from './types';
import { logDiscard } from './discardLog';

/** Score = rating × sqrt(reviewCount + 1) */
function computeScore(listing: RawListing): number {
  const rating = listing.rating ?? 0;
  const reviews = listing.reviewCount ?? 0;
  return rating * Math.sqrt(reviews + 1);
}

/** Normalize business name for grouping (strip punctuation, lowercase, collapse spaces) */
function normalizeName(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Apply rating/review filter with two fallbacks and a last-resort tier.
 *
 * Tier 1 (strict):       rating ≥ minRating,         reviews ≥ minReviews
 * Tier 2 (fallback):     rating ≥ fallbackMinRating,  reviews ≥ fallbackMinReviews
 * Tier 3 (last resort):  any rating, any review count — keeps whatever Google found
 *
 * Each tier is only tried if the previous one yields fewer than 8 results.
 */
export function applyRatingFilter(
  listings: RawListing[],
  config: AppConfig
): RawListing[] {
  // Tier 1: strict
  const strict = listings.filter(
    (l) =>
      l.rating !== null &&
      l.reviewCount !== null &&
      l.rating >= config.minRating &&
      l.reviewCount >= config.minReviews
  );

  if (strict.length >= 8) {
    console.log(
      `  [filter] Strict filter (≥${config.minRating} rating, ≥${config.minReviews} reviews): ${strict.length} results`
    );
    return strict.map(l => ({ ...l, filterTier: 'Top rated' as const }));
  }

  // Tier 2: fallback
  console.log(
    `  [filter] Strict filter yielded only ${strict.length} results — applying fallback ` +
      `(≥${config.fallbackMinRating} rating, ≥${config.fallbackMinReviews} reviews)`
  );

  const fallback = listings.filter(
    (l) =>
      l.rating !== null &&
      l.reviewCount !== null &&
      l.rating >= config.fallbackMinRating &&
      l.reviewCount >= config.fallbackMinReviews
  );

  if (fallback.length >= 4) {
    console.log(`  [filter] Fallback filter: ${fallback.length} results`);
    return fallback.map(l => ({ ...l, filterTier: 'Good rated' as const }));
  }

  // Tier 3: thin market — keeps rating requirement but removes review count minimum
  // Catches legitimate businesses with few reviews (e.g. international corporate movers)
  console.log(
    `  [filter] Fallback filter yielded only ${fallback.length} results — applying thin market filter ` +
      `(≥${config.fallbackMinRating} rating, any reviews)`
  );

  const thinMarket = listings.filter(
    (l) => l.rating !== null && l.rating >= config.fallbackMinRating
  );

  if (thinMarket.length >= 2) {
    console.log(`  [filter] Thin market filter: ${thinMarket.length} results`);
    return thinMarket.map(l => ({ ...l, filterTier: 'Best available' as const }));
  }

  // Tier 4: last resort — accept anything with a rating, regardless of review count
  console.log(
    `  [filter] Thin market filter yielded only ${thinMarket.length} results — applying last-resort filter (any rating, any reviews)`
  );

  const lastResort = listings.filter((l) => l.rating !== null && l.rating > 0);
  console.log(`  [filter] Last-resort filter: ${lastResort.length} results`);

  if (lastResort.length > 0) return lastResort.map(l => ({ ...l, filterTier: 'Best available' as const }));

  // Nothing at all — return everything scraped and let downstream decide
  console.log(`  [filter] No rated listings found — returning all scraped results`);
  return listings.map(l => ({ ...l, filterTier: 'Best available' as const }));
}

/**
 * Remove franchise chains; keep only unique businesses.
 * In small markets (< 15 listings), relaxes the chain threshold
 * so boutique businesses with 2 locations aren't discarded entirely.
 */
export function applyBoutiqueFilter(listings: RawListing[]): RawListing[] {
  const isSmallMarket = listings.length < 15;

  // Group by normalized name
  const groups = new Map<string, RawListing[]>();
  for (const l of listings) {
    const key = normalizeName(l.name);
    const group = groups.get(key) ?? [];
    group.push(l);
    groups.set(key, group);
  }

  const result: RawListing[] = [];
  for (const [, group] of groups) {
    if (group.length > 3) {
      // Clear franchise — discard entirely regardless of market size
      const info = group[0].rating != null ? `${group[0].rating}★, ${group[0].reviewCount ?? 0} reviews, ${group.length} locations` : `${group.length} locations`;
      logDiscard('Franchise (name)', group[0].name, info);
      continue;
    }
    if (group.length > 1 && !isSmallMarket) {
      // Chain in a large market — discard all
      const info = group[0].rating != null ? `${group[0].rating}★, ${group[0].reviewCount ?? 0} reviews, ${group.length} locations` : `${group.length} locations`;
      logDiscard('Name chain', group[0].name, info);
      continue;
    }
    if (group.length > 1 && isSmallMarket) {
      // Small market: keep the top-rated one instead of discarding all
      const best = group.sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0))[0];
      console.log(`  [filter] Small market: keeping best "${best.name}" from ${group.length} duplicates`);
      result.push(best);
      continue;
    }
    result.push(group[0]);
  }

  console.log(`  [filter] After boutique filter: ${result.length} candidates`);
  return result;
}

/** Score and sort listings, return top N */
export function scoreAndRank(listings: RawListing[], topN: number): ScoredListing[] {
  const scored = listings.map((l) => ({
    ...l,
    websiteUrl: null as string | null,
    websiteVerified: false,
    address: null as string | null,
    cityMatch: true,
    score: computeScore(l),
  }));

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, topN);
}

// ─── Post-enrichment filters (run after Phase 2 detail fetching) ──────────────

function extractDomain(url: string): string | null {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return null;
  }
}

/**
 * Known shared aggregator/directory/booking platforms that multiple independent
 * businesses legitimately use. These should NOT trigger the domain chain filter.
 */
const AGGREGATOR_DOMAINS = new Set([
  // Link-in-bio / profile pages
  'linkbio.co', 'linktr.ee', 'linkin.bio', 'bio.link', 'beacons.ai',
  // Booking & directories
  'booksy.com', 'fresha.com', 'vagaro.com', 'mindbodyonline.com',
  'treatwell.co.uk', 'timely.com', 'setmore.com', 'square.site',
  'schedulicity.com', 'genbook.com', 'styleseat.com',
  // Asian/regional directories
  'foody.vn', 'now.vn', 'zalo.me', 'grabfood.com', 'shopeefood.com',
  'foodpanda.com', 'grab.com', 'gojek.com', 'klook.com',
  // Review/listing platforms
  'yelp.com', 'tripadvisor.com', 'zomato.com', 'happycow.net',
  // Website builders used by small businesses
  'wixsite.com', 'weebly.com', 'squarespace.com', 'godaddysites.com',
  'wordpress.com', 'sites.google.com', 'notion.site',
]);

/**
 * Domain-based chain detection: if two or more listings share the same website
 * domain, they are branches of the same chain — discard ALL of them.
 * Aggregator/directory/booking domains are exempt from this check.
 */
export function applyDomainFilter(listings: EnrichedListing[]): EnrichedListing[] {
  const domainCounts = new Map<string, number>();
  for (const l of listings) {
    if (!l.websiteUrl) continue;
    const domain = extractDomain(l.websiteUrl);
    if (domain && ![...AGGREGATOR_DOMAINS].some(a => domain === a || domain.endsWith('.' + a))) {
      domainCounts.set(domain, (domainCounts.get(domain) ?? 0) + 1);
    }
  }

  return listings.filter((l) => {
    if (!l.websiteUrl) return true;
    const domain = extractDomain(l.websiteUrl);
    if (!domain) return true;
    if ([...AGGREGATOR_DOMAINS].some(a => domain === a || domain.endsWith('.' + a))) return true;
    if ((domainCounts.get(domain) ?? 0) > 1) {
      logDiscard('Domain chain', l.name, l.websiteUrl ?? undefined);
      return false;
    }
    return true;
  });
}

/** Known hospital / health-directory domains — Dr. listings pointing here are discarded */
const HOSPITAL_DOMAINS = [
  'parkwaypantai.com',
  'gleneagles.com.sg',
  'rafflesmedical.com',
  'raffleshealth.com',
  'columbiasia.com',
  'pantai.com.my',
  'kpjhealth.com.my',
  'healthhub.sg',
  'singhealth.com.sg',
  'nuhs.edu.sg',
  'nuh.com.sg',
  'sgh.com.sg',
  'ktph.com.sg',
  'cgh.com.sg',
  'ttsh.com.sg',
  'bookdoc.com',
  'doctoranywhere.com',
  'doctor2u.my',
];

/**
 * Entity filter: discard listings that start with "Dr." unless they have a
 * dedicated clinic website (i.e. not null and not a known hospital/directory).
 */
export function applyEntityFilter(listings: EnrichedListing[]): EnrichedListing[] {
  return listings.filter((l) => {
    if (!l.name.toLowerCase().startsWith('dr.')) return true;

    if (!l.websiteUrl) {
      logDiscard('Entity (no website)', l.name);
      return false;
    }

    const domain = extractDomain(l.websiteUrl) ?? '';
    const isHospitalOrDirectory = HOSPITAL_DOMAINS.some(
      (h) => domain === h || domain.endsWith('.' + h)
    );
    if (isHospitalOrDirectory) {
      logDiscard('Entity (hospital)', l.name);
      return false;
    }

    return true;
  });
}

/** Full filter pipeline */
export function runFilterPipeline(
  listings: RawListing[],
  config: AppConfig,
  topN = 25
): ScoredListing[] {
  const ratingFiltered = applyRatingFilter(listings, config);
  const boutiqueFiltered = applyBoutiqueFilter(ratingFiltered);
  return scoreAndRank(boutiqueFiltered, topN);
}

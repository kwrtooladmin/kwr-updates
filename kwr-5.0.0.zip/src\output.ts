import { createObjectCsvWriter } from 'csv-writer';
import { EnrichedListing, AppConfig } from './types';
import * as path from 'path';
import * as fs from 'fs';

export interface OutputRow {
  Rank: number;
  Tier: string;
  'Quality Level': string;
  'Business Name': string;
  Rating: string;
  'Review Count': string;
  'Website URL': string;
  'Website Status': string;
  'Reference URL': string;
  City: string;
  Vertical: string;
}

function websiteStatus(l: EnrichedListing): string {
  if (l.websiteUrl && l.websiteVerified) return 'verified';
  if (l.websiteUrl) return 'unverified';
  if (l.socialUrl) return 'social_only';
  if (l.mapsUrl) return 'maps_only';
  return 'none';
}

function referenceUrl(l: EnrichedListing): string {
  if (l.websiteUrl) return l.websiteUrl;
  if (l.socialUrl) return l.socialUrl;
  if (l.mapsUrl) return l.mapsUrl ?? '';
  return '';
}

/**
 * Select primary (top 5 verified with website) + backup (next 3).
 */
export function selectFinalListings(listings: EnrichedListing[]): {
  primary: EnrichedListing[];
  backup: EnrichedListing[];
} {
  const withWebsite = listings.filter((l) => l.websiteUrl && l.websiteUrl.trim() !== '');
  const fallbackOnly = listings.filter((l) => (!l.websiteUrl || l.websiteUrl.trim() === '') && (l.socialUrl || l.mapsUrl));

  const verified = withWebsite.filter((l) => l.websiteVerified);
  const primary = verified.slice(0, 5);

  const remainingVerified = verified.slice(5);
  const unverifiedWithWebsite = withWebsite.filter((l) => !l.websiteVerified);
  const backupPool = [...remainingVerified, ...unverifiedWithWebsite, ...fallbackOnly];
  const backup = backupPool.slice(0, 3);

  return { primary, backup };
}

const HEADERS = [
  { id: 'Rank',           title: 'Rank' },
  { id: 'Tier',           title: 'Tier' },
  { id: 'Quality Level',  title: 'Quality Level' },
  { id: 'Business Name',  title: 'Business Name' },
  { id: 'Rating',         title: 'Rating' },
  { id: 'Review Count',   title: 'Review Count' },
  { id: 'Website URL',    title: 'Website URL' },
  { id: 'Website Status', title: 'Website Status' },
  { id: 'Reference URL',  title: 'Reference URL' },
  { id: 'City',           title: 'City' },
  { id: 'Vertical',       title: 'Vertical' },
];

/** Write results to an individual CSV file per run */
export async function writeCsv(
  listings: EnrichedListing[],
  config: AppConfig
): Promise<string> {
  const { primary, backup } = selectFinalListings(listings);

  if (primary.length === 0) {
    console.warn('  [output] No verified primary listings with websites found');
  }

  const outputDir = path.dirname(config.outputPath);
  if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

  const rows: OutputRow[] = [];

  primary.forEach((l, i) => {
    rows.push({
      Rank: i + 1,
      Tier: 'primary',
      'Quality Level': l.filterTier ?? 'Top rated',
      'Business Name': l.name,
      Rating: l.rating !== null ? l.rating.toFixed(1) : '',
      'Review Count': l.reviewCount !== null ? String(l.reviewCount) : '',
      'Website URL': l.websiteUrl ?? '',
      'Website Status': websiteStatus(l),
      'Reference URL': referenceUrl(l),
      City: config.city,
      Vertical: config.vertical,
    });
  });

  backup.forEach((l, i) => {
    rows.push({
      Rank: primary.length + i + 1,
      Tier: 'backup',
      'Quality Level': l.filterTier ?? 'Top rated',
      'Business Name': l.name,
      Rating: l.rating !== null ? l.rating.toFixed(1) : '',
      'Review Count': l.reviewCount !== null ? String(l.reviewCount) : '',
      'Website URL': l.websiteUrl ?? '',
      'Website Status': websiteStatus(l),
      'Reference URL': referenceUrl(l),
      City: config.city,
      Vertical: config.vertical,
    });
  });

  const writer = createObjectCsvWriter({
    path: config.outputPath,
    header: HEADERS,
  });

  await writer.writeRecords(rows);
  return config.outputPath;
}

@echo off
REM Double-click to publish the current version as a live auto-update.
REM It builds the zip, updates the kwr-updates repo, and pushes to GitHub.
REM The version published is whatever is set in package.json.
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%~dp0tools\publish-update.ps1"
echo.
pause

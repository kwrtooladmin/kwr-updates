/**
 * City-match logic for geographic filtering.
 *
 * Matching strategy (applied in order):
 *
 *  1. CITY-STATE exclusion  — for dense city-states where addresses omit the city name.
 *                             Pass unless address contains a foreign country keyword.
 *
 *  2. ALIAS match           — city name + known alternate spellings/names checked against address.
 *                             Works for any city: aliases are built dynamically from the input
 *                             plus a universal alternate-name map.
 *
 *  3. POSTCODE pattern      — if the address contains a postcode-like token, pass it through.
 *                             Avoids rejecting businesses whose address drops the city name
 *                             but includes a valid postcode (e.g. "EH14 1RL", "75008").
 *
 *  4. BENEFIT OF DOUBT      — if none of the above match, pass the listing anyway.
 *                             A false rejection is worse than a false acceptance at this stage;
 *                             downstream geo/domain filters provide a safety net.
 */

// ─── Accent & normalization ───────────────────────────────────────────────────

/** Strip diacritics/accents and lowercase — works for any language */
function stripAccents(str: string): string {
  return str.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

// ─── Universal alternate city name map ───────────────────────────────────────
/**
 * Maps plain-English city names to all acceptable address fragments,
 * including local-language spellings, historical names, and alternate romanizations.
 * Both keys and values are already accent-stripped and lowercased.
 *
 * Add entries here whenever a new city alias is discovered in team feedback.
 */
const CITY_ALTERNATE_NAMES: Record<string, string[]> = {
  // Vietnam
  hanoi:          ['hanoi', 'ha noi', 'tp. ha noi', 'thanh pho ha noi'],
  'ho chi minh':  ['ho chi minh', 'hcm', 'tp. hcm', 'tp hcm', 'thanh pho ho chi minh', 'saigon', 'sai gon'],
  'da nang':      ['da nang', 'tp. da nang'],

  // Thailand
  bangkok:        ['bangkok', 'krung thep', 'krung thep maha nakhon'],

  // Canada
  montreal:       ['montreal', 'montréal', 'ville de montreal', 'ville de montréal'],
  toronto:        ['toronto', 'north york', 'scarborough', 'etobicoke', 'east york', 'york'],
  vancouver:      ['vancouver', 'city of vancouver'],

  // Australia
  sydney:         ['sydney', 'city of sydney', 'inner sydney'],
  melbourne:      ['melbourne', 'city of melbourne'],
  brisbane:       ['brisbane', 'city of brisbane'],
  canberra:       ['canberra', 'australian capital territory', 'act'],

  // UK
  edinburgh:      ['edinburgh', 'city of edinburgh'],
  london:         ['london', 'city of london', 'greater london'],
  birmingham:     ['birmingham', 'city of birmingham'],
  manchester:     ['manchester', 'city of manchester', 'greater manchester'],
  liverpool:      ['liverpool', 'city of liverpool'],

  // Germany
  cologne:        ['cologne', 'koln', 'köln'],
  munich:         ['munich', 'munchen', 'münchen'],
  nuremberg:      ['nuremberg', 'nurnberg', 'nürnberg'],

  // Malaysia
  'kuala lumpur': ['kuala lumpur', 'kl', 'wp kuala lumpur', 'w.p. kuala lumpur', 'federal territory', 'wilayah persekutuan'],

  // USA
  'new york':     ['new york', 'brooklyn', 'queens', 'bronx', 'manhattan', 'staten island', 'new york city', 'nyc'],
  'los angeles':  ['los angeles', 'la,', 'city of los angeles'],
  phoenix:        ['phoenix', 'city of phoenix'],

  // India
  mumbai:         ['mumbai', 'bombay'],
  bangalore:      ['bangalore', 'bengaluru'],
  kolkata:        ['kolkata', 'calcutta'],
  chennai:        ['chennai', 'madras'],

  // Malta
  malta:          ['malta', 'valletta', 'birkirkara', 'qormi', 'mosta', 'zabbar', 'naxxar', 'attard'],
};

// ─── City-state exclusion list ────────────────────────────────────────────────
/**
 * For city-states or dense cities where addresses commonly omit the city name,
 * pass listings unless the address contains a clearly foreign indicator.
 */
const CITY_STATE_EXCLUSIONS: Record<string, string[]> = {
  singapore:   ['malaysia', 'indonesia', 'thailand', 'philippines', 'vietnam', 'brunei'],
  'hong kong': ['mainland', 'shenzhen', 'guangzhou', 'macau'],
  monaco:      ['france', 'italy'],
  luxembourg:  ['belgium', 'france', 'germany'],
};

// ─── Postcode pattern ─────────────────────────────────────────────────────────
/**
 * Matches common postcode formats from any country.
 * If an address contains something that looks like a postcode, we assume
 * the business is local and pass it through.
 *
 * Covers: UK (EH14 1RL), US ZIP (75008), Canada (M5V 2T6),
 *         EU numeric (75008, 10115), Australia (2000), and others.
 */
const POSTCODE_REGEX = /\b([A-Z]{1,2}\d{1,2}[A-Z]?\s?\d[A-Z]{2}|\d{4,6}|[A-Z]\d[A-Z]\s?\d[A-Z]\d)\b/i;

function hasPostcode(address: string): boolean {
  return POSTCODE_REGEX.test(address);
}

// ─── Build alias list for any city ───────────────────────────────────────────
/**
 * Returns all acceptable address fragments for a given city.
 * Always includes the accent-stripped city name itself plus any known alternates.
 */
function buildAliases(normCity: string): string[] {
  const known = CITY_ALTERNATE_NAMES[normCity] ?? [];
  const base = known.length > 0 ? known : [normCity];
  return [...new Set([normCity, ...base])];
}

// ─── Main export ──────────────────────────────────────────────────────────────
/**
 * Returns true if `address` is considered to be within `city`.
 * If `address` is null (not extracted), returns true (benefit of the doubt).
 */
export function matchesCity(address: string | null, city: string): boolean {
  if (address === null) return true;

  const normAddress = stripAccents(address);
  const normCity    = stripAccents(city).trim();

  // 1. City-state strategy: pass unless a clearly foreign indicator is found
  const exclusions = CITY_STATE_EXCLUSIONS[normCity];
  if (exclusions) {
    return !exclusions.some((keyword) => normAddress.includes(keyword));
  }

  // 2. Alias strategy: pass if any known name/alternate spelling is found
  const aliases = buildAliases(normCity);
  if (aliases.some((alias) => normAddress.includes(alias))) {
    return true;
  }

  // 3. Postcode fallback: if address has a postcode pattern, give benefit of doubt
  //    (the city name may simply be omitted in the address format)
  if (hasPostcode(normAddress)) {
    return true;
  }

  // 4. Benefit of doubt: pass rather than reject — downstream filters catch outliers
  return true;
}

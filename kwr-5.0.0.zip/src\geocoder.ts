import { Page } from 'playwright';
import { GeoLocation } from './types';
import { GeocodeError, CaptchaError } from './errors';
import { randomDelay } from './humanize';
import { isCaptchaPresent } from './selectors';

export const GEO_REGEX = /@(-?\d+\.\d+),(-?\d+\.\d+),([\d\.]+)z/;

/**
 * Cities that Google Maps sometimes zooms out too far for.
 * Any input matching one of these is always treated as a city
 * regardless of the zoom level returned.
 */
const KNOWN_CITY_COORDS: Record<string, { lat: number; lng: number; zoom: number }> = {
  'ho chi minh': { lat: 10.8230989, lng: 106.6296638, zoom: 11 },
  'ho chi minh city': { lat: 10.8230989, lng: 106.6296638, zoom: 11 },
  'kuala lumpur': { lat: 3.1390, lng: 101.6869, zoom: 11 },
  'phnom penh': { lat: 11.5564, lng: 104.9282, zoom: 11 },
  'vientiane': { lat: 17.9757, lng: 102.6331, zoom: 11 },
};

const KNOWN_CITIES = new Set([
  'ho chi minh', 'ho chi minh city', 'kuala lumpur', 'buenos aires',
  'mexico city', 'new york', 'new york city', 'los angeles', 'san francisco',
  'hong kong', 'sao paulo', 'rio de janeiro', 'cape town', 'dar es salaam',
  'addis ababa', 'port of spain', 'port elizabeth', 'phnom penh',
  'vientiane', 'ulaanbaatar', 'port moresby',
]);

function classifyZoom(zoom: number, cityInput?: string): 'country' | 'region' | 'city' {
  // If the input is a known multi-word city, always treat it as a city
  if (cityInput) {
    const norm = cityInput.toLowerCase().trim();
    if (KNOWN_CITIES.has(norm)) return 'city';
  }
  // Raised threshold — only flag as country if very zoomed out
  if (zoom <= 5) return 'country';
  if (zoom <= 8) return 'region';
  return 'city';
}

function extractGeoFromUrl(url: string, cityInput?: string): GeoLocation | null {
  const match = GEO_REGEX.exec(url);
  if (!match) return null;
  const zoom = parseInt(match[3], 10);
  return {
    lat: parseFloat(match[1]),
    lng: parseFloat(match[2]),
    zoom,
    locationType: classifyZoom(zoom, cityInput),
  };
}

export async function geocodeCity(page: Page, city: string): Promise<GeoLocation> {
  const encoded = encodeURIComponent(city);
  const url = `https://www.google.com/maps/search/${encoded}`;

  await page.goto(url, { waitUntil: 'load', timeout: 30000 });
  await randomDelay(2000, 3500);

  if (await isCaptchaPresent(page)) {
    throw new CaptchaError();
  }

  // Check for known city with hardcoded coordinates first
  const normCity = city.toLowerCase().trim();
  if (KNOWN_CITY_COORDS[normCity]) {
    const coords = KNOWN_CITY_COORDS[normCity];
    return { lat: coords.lat, lng: coords.lng, zoom: coords.zoom, locationType: 'city' };
  }

  // First attempt — pass city so known multi-word cities are never mis-classified
  let geo = extractGeoFromUrl(page.url(), city);
  if (geo) return geo;

  // Retry with extra wait
  console.log('  [geocoder] First geocode attempt failed, retrying...');
  await randomDelay(2000, 4000);
  await page.waitForLoadState('load').catch(() => {});
  geo = extractGeoFromUrl(page.url(), city);
  if (geo) return geo;

  throw new GeocodeError(city);
}

const TLD_COUNTRY_MAP: Record<string, string> = {
  'co.uk':  'UK',
  'com.au': 'Australia',
  'ca':     'Canada',
  'sg':     'Singapore',
  'co.nz':  'New Zealand',
  'ie':     'Ireland',
  'co.za':  'South Africa',
  'in':     'India',
  'co.in':  'India',
  'com':    'United States',
};

export function haversineDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function siteToCountry(site: string): string | null {
  const lower = site.toLowerCase();
  for (const [tld, country] of Object.entries(TLD_COUNTRY_MAP)) {
    if (lower.endsWith('.' + tld) || lower === tld) {
      return country;
    }
  }
  return null;
}

export function buildSearchUrl(
  vertical: string,
  geo: GeoLocation,
  city?: string,
  country?: string | null,
  lang?: string,
): string {
  let query = vertical;
  if (city) {
    query += ` in ${city}`;
    // Only append country when there is NO city — a city already scopes the search.
    // Appending country alongside a city causes Google to misinterpret the location
    // (e.g. "Hair Salon in Hanoi, United States" for a .com site based in Vietnam).
  } else if (country) {
    query += ` in ${country}`;
  }
  const encoded = encodeURIComponent(query);
  const base = `https://www.google.com/maps/search/${encoded}/@${geo.lat},${geo.lng},${geo.zoom}z`;
  // Default to English (hl=en) so results stay relevant in non-English countries.
  // User can override with --lang flag.
  const language = lang ?? 'en';
  return `${base}?hl=${language}`;
}

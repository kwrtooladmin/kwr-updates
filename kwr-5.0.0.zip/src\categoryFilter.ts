import { ScoredListing } from './types';
import { logDiscard } from './discardLog';

/**
 * Maps vertical search terms to acceptable Google Maps business category labels.
 * Categories are always returned in English by Google regardless of country.
 * A business passes if its category contains ANY of the listed keywords.
 * If a vertical is not in this map, the filter is skipped for that vertical.
 */
const VERTICAL_CATEGORY_MAP: Record<string, string[]> = {
  // Home services
  'air duct cleaning':     ['hvac', 'duct', 'air duct', 'ventilation', 'heating', 'cleaning', 'contractor'],
  'aircon servicing':      ['hvac', 'air conditioning', 'aircon', 'cooling', 'heating', 'contractor', 'appliance'],
  'hvac':                  ['hvac', 'heating', 'air conditioning', 'cooling', 'ventilation', 'contractor', 'furnace'],
  'appliance repair':      ['appliance', 'repair', 'contractor', 'handyman', 'technician', 'maintenance'],
  'house cleaning':        ['cleaning', 'housekeeping', 'maid', 'domestic', 'janitorial', 'home service'],
  'general contractor':    ['contractor', 'construction', 'builder', 'renovation', 'remodel', 'handyman'],
  'basement renovation':   ['contractor', 'renovation', 'construction', 'builder', 'remodel', 'handyman'],
  'termite control':       ['pest control', 'exterminator', 'pest', 'fumigation', 'termite', 'insect'],
  'tree service':          ['tree', 'arborist', 'landscaping', 'landscape', 'garden', 'horticulture'],
  'lawn care':             ['landscaping', 'lawn', 'garden', 'landscape', 'horticulture', 'grounds'],
  'pool clean':            ['pool', 'swimming', 'cleaning', 'maintenance', 'contractor'],
  'water softener':        ['water', 'filtration', 'purification', 'treatment', 'plumbing', 'contractor'],
  'masonry contractors':   ['masonry', 'contractor', 'construction', 'concrete', 'brick', 'stone', 'builder'],
  'home health care':      ['home care', 'health care', 'nursing', 'caregiver', 'medical', 'clinic'],
  'furniture delivery':    ['furniture', 'delivery', 'moving', 'logistics', 'transport', 'mover'],
  'furniture mover':       ['mover', 'moving', 'furniture', 'relocation', 'logistics', 'transport'],
  'deck builder':          ['contractor', 'construction', 'builder', 'deck', 'carpentry', 'handyman', 'renovation', 'outdoor'],
  'deck builders':         ['contractor', 'construction', 'builder', 'deck', 'carpentry', 'handyman', 'renovation', 'outdoor'],
  'waterproofing':         ['waterproofing', 'contractor', 'construction', 'renovation', 'roofing', 'basement', 'foundation', 'handyman'],
  'deep cleaning':         ['cleaning', 'deep cleaning', 'housekeeping', 'janitorial', 'maid', 'sanitation', 'disinfection'],
  'deep cleaning services':['cleaning', 'deep cleaning', 'housekeeping', 'janitorial', 'maid', 'sanitation', 'disinfection'],
  'attic insulation':      ['insulation', 'contractor', 'construction', 'roofing', 'handyman', 'energy', 'hvac'],
  'mosquito control':      ['pest control', 'exterminator', 'pest', 'fumigation', 'insect', 'termite', 'mosquito'],
  'bed bug exterminator':  ['pest control', 'exterminator', 'pest', 'fumigation', 'bed bug', 'insect'],
  'office cleaning':       ['cleaning', 'janitorial', 'commercial cleaning', 'housekeeping', 'maintenance'],
  'janitorial':            ['cleaning', 'janitorial', 'commercial cleaning', 'housekeeping', 'maintenance'],
  'laundry service':       ['laundry', 'dry cleaning', 'cleaning', 'washing', 'linen'],
  'structural engineer':   ['engineer', 'structural', 'civil', 'construction', 'consultant', 'surveyor'],
  'water treatment':       ['water', 'filtration', 'purification', 'treatment', 'plumbing', 'contractor'],
  'professional organizer':['organizer', 'organiser', 'organizing', 'declutter', 'storage', 'consultant'],
  'arborist':              ['arborist', 'tree', 'landscaping', 'landscape', 'horticulture', 'garden'],
  'conveyancing':          ['conveyancing', 'solicitor', 'lawyer', 'law firm', 'legal', 'notary', 'real estate'],
  'furnace repair':        ['hvac', 'heating', 'furnace', 'air conditioning', 'cooling', 'contractor', 'plumbing'],
  'furnace repairs':       ['hvac', 'heating', 'furnace', 'air conditioning', 'cooling', 'contractor', 'plumbing'],
  'painting service':      ['painter', 'painting contractor', 'painting service', 'house painter', 'building painter', 'decorator', 'painting company', 'construction', 'contractor', 'handyman'],
  'painting services':     ['painter', 'painting contractor', 'painting service', 'house painter', 'building painter', 'decorator', 'painting company', 'construction', 'contractor', 'handyman'],
  'mover':                 ['mover', 'moving', 'moving company', 'moving and storage', 'relocation', 'removalist', 'removal', 'freight forwarder', 'logistics', 'trucking', 'transport', 'storage service'],
  'movers':                ['mover', 'moving', 'moving company', 'moving and storage', 'relocation', 'removalist', 'removal', 'freight forwarder', 'logistics', 'trucking', 'transport', 'storage service'],
  'renovation contractor': ['contractor', 'renovation', 'construction', 'builder', 'remodel', 'interior design', 'handyman'],
  'plumbing':              ['plumb', 'plumber', 'pipe', 'drainage', 'sanitary'],
  'plumbing services':     ['plumb', 'plumber', 'pipe', 'drainage', 'sanitary'],
  'maid agency':           ['maid', 'cleaning', 'housekeeping', 'domestic', 'staffing', 'employment', 'labor', 'recruitment'],
  'dog trainer':           ['dog', 'pet', 'animal', 'trainer', 'grooming', 'kennel'],
  'dog trainers':          ['dog', 'pet', 'animal', 'trainer', 'grooming', 'kennel'],
  'mold removal':          ['mold', 'mould', 'remediation', 'restoration', 'cleaning', 'contractor'],
  'home inspection':       ['inspection', 'inspector', 'surveyor', 'assessment', 'consultant'],
  'security company':      ['security service', 'security guard', 'guard service', 'surveillance', 'protection service', 'investigation'],

  // Health & wellness
  'prenatal massage':      ['massage', 'spa', 'wellness', 'prenatal', 'maternity', 'health', 'physiotherapy'],
  'osteopath':             ['osteopath', 'osteopathic', 'clinic', 'health', 'rehabilitation', 'physiotherapy', 'medical'],
  'botox':                 ['aesthetic', 'clinic', 'medical spa', 'dermatology', 'cosmetic', 'beauty', 'skin'],
  'lip filler':            ['aesthetic', 'clinic', 'medical spa', 'dermatology', 'cosmetic', 'beauty', 'skin'],
  'dermal filler':         ['aesthetic', 'clinic', 'medical spa', 'dermatology', 'cosmetic', 'beauty', 'skin'],
  'laser hair removal':    ['laser', 'aesthetic', 'clinic', 'beauty', 'skin', 'cosmetic', 'medical spa'],
  'invisalign':            ['dentist', 'dental', 'orthodontist', 'clinic', 'orthodontic'],
  'dental clinic':         ['dentist', 'dental', 'orthodontist', 'clinic', 'oral', 'tooth', 'health'],
  'mental health clinic':  ['mental health', 'psychology', 'psychologist', 'psychiatry', 'counseling', 'therapy', 'clinic'],
  'marriage counselling':  ['counseling', 'counselling', 'therapist', 'therapy', 'psychologist', 'mental health', 'clinic'],
  'speech therapist':      ['speech', 'therapist', 'therapy', 'clinic', 'health', 'rehabilitation', 'medical'],
  'aesthetic clinic':      ['aesthetic', 'clinic', 'medical spa', 'dermatology', 'cosmetic', 'beauty', 'skin'],
  'facial':                ['spa', 'beauty', 'aesthetic', 'skin care', 'salon', 'clinic', 'wellness'],
  'health screening':      ['clinic', 'health', 'medical', 'diagnostic', 'laboratory', 'screening'],
  'tattoo':                ['tattoo', 'tattoo shop', 'body art', 'studio', 'piercing'],
  'permanent makeup':      ['tattoo', 'beauty', 'aesthetic', 'salon', 'studio', 'cosmetic', 'microblading'],
  'hypnotherapy':          ['hypnotherapy', 'hypnotherapist', 'therapy', 'wellness', 'counseling', 'mental health'],
  'reiki':                 ['reiki', 'holistic', 'alternative medicine', 'wellness', 'energy', 'healing', 'spiritual'],
  'acne scar treatment':   ['skin care', 'dermatology', 'dermatologist', 'aesthetic', 'clinic', 'beauty', 'laser', 'medical spa'],
  'gynecologist':          ['gynecologist', 'gynaecologist', 'obstetrician', 'women', 'clinic', 'hospital', 'medical', 'health'],
  'hair removal':          ['laser', 'aesthetic', 'beauty', 'skin', 'clinic', 'spa', 'electrolysis', 'waxing'],
  'naturopath':            ['naturopath', 'naturopathic', 'holistic', 'alternative medicine', 'wellness', 'health', 'homeopath', 'herbalist'],
  'physiotherapy':         ['physiotherapy', 'physiotherapist', 'physical therapist', 'physical therapy', 'rehabilitation', 'clinic', 'health', 'sports medicine'],
  'kinesiologist':         ['kinesiology', 'kinesiologist', 'rehabilitation', 'sports', 'physical therapy', 'wellness', 'health'],
  'kinesiologists':        ['kinesiology', 'kinesiologist', 'rehabilitation', 'sports', 'physical therapy', 'wellness', 'health'],

  // Medical specialists
  'chiropractor':          ['chiropractor', 'chiropractic', 'clinic', 'health', 'rehabilitation', 'sports medicine', 'wellness'],
  'chiropractors':         ['chiropractor', 'chiropractic', 'clinic', 'health', 'rehabilitation', 'sports medicine', 'wellness'],
  'acupuncture':           ['acupuncture', 'acupuncturist', 'traditional chinese medicine', 'tcm', 'holistic', 'clinic', 'wellness', 'alternative medicine'],
  'acupuncturist':         ['acupuncture', 'acupuncturist', 'traditional chinese medicine', 'tcm', 'holistic', 'clinic', 'wellness', 'alternative medicine'],
  'optometrist':           ['optometrist', 'optometry', 'optical', 'eye care', 'eye clinic', 'vision', 'ophthalmology', 'clinic'],
  'optometrists':          ['optometrist', 'optometry', 'optical', 'eye care', 'eye clinic', 'vision', 'ophthalmology', 'clinic'],
  'eye doctor':            ['optometrist', 'optometry', 'optical', 'eye care', 'eye clinic', 'vision', 'ophthalmology', 'ophthalmologist', 'clinic'],
  'audiologist':           ['audiologist', 'audiology', 'hearing', 'clinic', 'health', 'medical', 'ear'],
  'hearing aid':           ['hearing', 'audiologist', 'audiology', 'clinic', 'health', 'medical', 'ear'],
  'podiatrist':            ['podiatrist', 'podiatry', 'foot', 'clinic', 'health', 'rehabilitation', 'medical'],
  'podiatrists':           ['podiatrist', 'podiatry', 'foot', 'clinic', 'health', 'rehabilitation', 'medical'],
  'general practitioner':  ['general practitioner', 'gp', 'family medicine', 'family doctor', 'clinic', 'medical', 'health centre', 'primary care'],
  'family doctor':         ['general practitioner', 'gp', 'family medicine', 'family doctor', 'clinic', 'medical', 'health centre', 'primary care'],
  'pediatrician':          ['pediatrician', 'paediatrician', 'pediatric', 'paediatric', 'child', 'clinic', 'medical', 'health'],
  'pediatricians':         ['pediatrician', 'paediatrician', 'pediatric', 'paediatric', 'child', 'clinic', 'medical', 'health'],
  'cardiologist':          ['cardiologist', 'cardiology', 'heart', 'cardiovascular', 'clinic', 'hospital', 'medical', 'health'],
  'neurologist':           ['neurologist', 'neurology', 'clinic', 'hospital', 'medical', 'health', 'brain', 'spine'],
  'orthopedic surgeon':    ['orthopedic', 'orthopaedic', 'surgeon', 'surgery', 'bone', 'joint', 'spine', 'clinic', 'hospital', 'sports medicine'],
  'orthopedic surgeons':   ['orthopedic', 'orthopaedic', 'surgeon', 'surgery', 'bone', 'joint', 'spine', 'clinic', 'hospital', 'sports medicine'],
  'dermatologist':         ['dermatologist', 'dermatology', 'skin', 'skin care', 'clinic', 'medical', 'aesthetic', 'health'],
  'dermatologists':        ['dermatologist', 'dermatology', 'skin', 'skin care', 'clinic', 'medical', 'aesthetic', 'health'],
  'endocrinologist':       ['endocrinologist', 'endocrinology', 'diabetes', 'thyroid', 'hormone', 'clinic', 'hospital', 'medical'],
  'urologist':             ['urologist', 'urology', 'clinic', 'hospital', 'medical', 'health'],
  'psychiatrist':          ['psychiatrist', 'psychiatry', 'mental health', 'psychology', 'clinic', 'hospital', 'medical', 'health'],
  'psychiatrists':         ['psychiatrist', 'psychiatry', 'mental health', 'psychology', 'clinic', 'hospital', 'medical', 'health'],
  'psychologist':          ['psychologist', 'psychology', 'mental health', 'counseling', 'therapy', 'clinic', 'health'],
  'psychologists':         ['psychologist', 'psychology', 'mental health', 'counseling', 'therapy', 'clinic', 'health'],

  // Plastic surgery & cosmetic procedures
  'plastic surgeon':       ['plastic surgeon', 'plastic surgery', 'cosmetic surgery', 'aesthetic', 'clinic', 'hospital', 'medical'],
  'plastic surgeons':      ['plastic surgeon', 'plastic surgery', 'cosmetic surgery', 'aesthetic', 'clinic', 'hospital', 'medical'],
  'cosmetic surgeon':      ['cosmetic surgery', 'plastic surgeon', 'plastic surgery', 'aesthetic', 'clinic', 'hospital', 'medical'],
  'liposuction':           ['plastic surgeon', 'plastic surgery', 'cosmetic surgeon', 'cosmetic surgery', 'aesthetic', 'clinic', 'medical spa', 'body contouring', 'medical'],
  'rhinoplasty':           ['plastic surgeon', 'plastic surgery', 'cosmetic surgeon', 'cosmetic surgery', 'aesthetic', 'clinic', 'ent', 'hospital', 'medical'],
  'breast augmentation':   ['plastic surgeon', 'plastic surgery', 'cosmetic surgeon', 'cosmetic surgery', 'aesthetic', 'clinic', 'hospital', 'medical'],
  'tummy tuck':            ['plastic surgeon', 'plastic surgery', 'cosmetic surgeon', 'cosmetic surgery', 'aesthetic', 'clinic', 'hospital', 'medical'],
  'facelift':              ['plastic surgeon', 'plastic surgery', 'cosmetic surgeon', 'cosmetic surgery', 'aesthetic', 'clinic', 'medical spa', 'beauty', 'medical'],
  'breast lift':           ['plastic surgeon', 'plastic surgery', 'cosmetic surgeon', 'cosmetic surgery', 'aesthetic', 'clinic', 'medical spa', 'hospital', 'medical'],
  'chin filler':           ['plastic surgeon', 'plastic surgery', 'cosmetic surgeon', 'aesthetic', 'clinic', 'medical spa', 'skin care', 'cosmetic', 'beauty', 'medical'],
  'double chin removal':   ['plastic surgeon', 'plastic surgery', 'cosmetic surgeon', 'aesthetic', 'clinic', 'medical spa', 'skin care', 'cosmetic', 'beauty', 'medical'],
  'hifu':                  ['aesthetic', 'clinic', 'medical spa', 'skin care', 'skin', 'beauty', 'cosmetic', 'laser', 'medical'],
  'water heater repair':   ['plumb', 'plumber', 'hvac', 'heating', 'contractor', 'appliance', 'water heater', 'handyman'],
  'thyroid specialist':    ['endocrinologist', 'endocrinology', 'thyroid', 'hormone', 'internal medicine', 'clinic', 'hospital', 'medical'],
  'property lawyer':       ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'real estate', 'conveyancing', 'property'],
  'property lawyers':      ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'real estate', 'conveyancing', 'property'],
  'mold inspection':       ['inspection', 'inspector', 'environmental', 'asbestos', 'testing', 'remediation', 'mold', 'mould', 'restoration', 'contractor'],
  'gynaecologist':         ['gynecologist', 'gynaecologist', 'obstetrician', 'women', 'clinic', 'hospital', 'medical', 'health'],
  'gynaecologists':        ['gynecologist', 'gynaecologist', 'obstetrician', 'women', 'clinic', 'hospital', 'medical', 'health'],
  'blepharoplasty':        ['plastic surgery', 'cosmetic surgery', 'aesthetic', 'clinic', 'hospital', 'ophthalmology', 'medical'],
  'coolsculpting':         ['aesthetic', 'clinic', 'medical spa', 'body contouring', 'beauty', 'skin', 'cosmetic', 'plastic surgery'],
  'ultherapy':             ['aesthetic', 'clinic', 'medical spa', 'skin', 'beauty', 'cosmetic', 'plastic surgery', 'laser'],
  'thread lift':           ['aesthetic', 'clinic', 'medical spa', 'cosmetic', 'beauty', 'skin', 'plastic surgery'],
  'yoga studios':          ['yoga', 'pilates', 'studio', 'fitness', 'wellness', 'meditation'],
  'yoga studio':           ['yoga', 'pilates', 'studio', 'fitness', 'wellness', 'meditation'],

  // Professional services
  'translation service':   ['translation', 'interpreter', 'language', 'linguistic', 'localization', 'agency'],
  'company registration':  ['corporate', 'business', 'legal', 'law firm', 'consultant', 'accounting', 'advisory'],
  'payroll service':       ['payroll', 'accounting', 'hr', 'human resources', 'bookkeeping', 'financial', 'consultant'],
  'recruitment agency':    ['recruitment', 'staffing', 'employment', 'hr', 'human resources', 'agency', 'labor'],
  'digital marketing agency': ['marketing', 'digital', 'agency', 'advertising', 'seo', 'media', 'consultant'],
  'graphic designers':     ['graphic design', 'design', 'designer', 'studio', 'creative', 'agency', 'advertising'],
  'software developer':    ['software', 'technology', 'it', 'developer', 'tech', 'computer', 'development'],
  'driving school':        ['driving school', 'driving instructor', 'school', 'auto school', 'education'],
  'headshot':              ['photographer', 'photography', 'photo', 'studio', 'portrait', 'headshot'],
  'pr agency':             ['public relations', 'pr', 'marketing', 'agency', 'communications', 'media'],
  'career coach':          ['coach', 'coaching', 'consultant', 'career', 'counselor', 'training', 'advisor'],
  'law firm':              ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel'],
  'immigration attorney':  ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'immigration', 'visa'],
  'assault lawyer':        ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'criminal'],
  'dui lawyer':            ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'criminal'],
  'civil litigation lawyer':['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel'],
  'wills lawyer':          ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'notary', 'estate', 'probate', 'will'],
  'wills lawyers':         ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'notary', 'estate', 'probate', 'will'],
  'estate lawyer':         ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'notary', 'estate', 'probate'],
  'probate lawyer':        ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'notary', 'estate', 'probate', 'will'],
  'probate lawyers':       ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'notary', 'estate', 'probate', 'will'],
  'social media marketing':['marketing', 'digital marketing', 'agency', 'advertising', 'social media', 'seo', 'media'],
  'web hosting':           ['web hosting', 'hosting', 'technology', 'software', 'it', 'internet', 'server', 'cloud'],
  'private investigator':  ['private investigator', 'investigation', 'detective', 'security', 'surveillance'],
  'pharmacy':              ['pharmacy', 'pharmacist', 'drug store', 'chemist', 'dispensary', 'health'],
  'psychic':               ['psychic', 'spiritual', 'astrology', 'tarot', 'medium', 'clairvoyant', 'healing'],
  'immigration agency':    ['immigration', 'visa', 'legal', 'lawyer', 'attorney', 'consultant', 'travel', 'agency'],
  'tax consultant':        ['tax', 'accounting', 'accountant', 'bookkeeping', 'financial', 'consultant', 'advisory'],
  'tax consultants':       ['tax', 'accounting', 'accountant', 'bookkeeping', 'financial', 'consultant', 'advisory'],
  'bookkeeping':           ['accounting', 'accountant', 'bookkeeping', 'financial', 'tax', 'advisory'],
  'mortgage broker':       ['mortgage', 'finance', 'loan', 'broker', 'financial', 'bank', 'lending'],
  'life coach':            ['coach', 'coaching', 'counselor', 'therapist', 'wellness', 'consultant', 'training'],

  // Beauty & personal care
  'beauty salon':          ['beauty', 'salon', 'hair', 'spa', 'nail', 'aesthetics', 'skin care', 'cosmetic'],
  'pet grooming':          ['pet', 'grooming', 'dog', 'cat', 'animal', 'veterinary', 'kennel'],
  'cat grooming':          ['pet', 'grooming', 'cat', 'animal', 'veterinary', 'kennel'],
  'dog daycare':           ['dog', 'pet', 'daycare', 'boarding', 'kennel', 'animal', 'grooming'],
  'hair extensions':       ['hair', 'salon', 'beauty', 'hairdresser', 'extension', 'spa'],
  'massage school':        ['massage', 'school', 'academy', 'education', 'training', 'wellness', 'spa'],
  'hair salon':            ['hair', 'salon', 'beauty', 'barber', 'hairdresser', 'spa'],
  'barbershop':            ['barber', 'barbershop', 'hair', 'salon', 'grooming', 'men'],

  // Education & fitness
  'elementary school':     ['school', 'elementary', 'primary', 'education', 'academy', 'learning'],
  'kindergarten':          ['kindergarten', 'preschool', 'daycare', 'childcare', 'nursery', 'school', 'education'],
  'animal hospitals':      ['veterinary', 'vet', 'animal hospital', 'pet clinic', 'animal clinic', 'animal care'],
  'art school':            ['school', 'art school', 'art studio', 'education', 'academy', 'arts', 'college'],
  'art studio':            ['art', 'studio', 'gallery', 'school', 'arts', 'creative', 'academy'],
  'music school':          ['music', 'school', 'academy', 'studio', 'education', 'lesson', 'conservatory'],
  'piano lesson':          ['music', 'piano', 'school', 'lesson', 'academy', 'studio', 'teacher'],
  'singing lesson':        ['music', 'singing', 'vocal', 'school', 'lesson', 'academy', 'studio', 'teacher'],
  'singing lessons':       ['music', 'singing', 'vocal', 'school', 'lesson', 'academy', 'studio', 'teacher'],
  'guitar lesson':         ['music', 'guitar', 'school', 'lesson', 'academy', 'studio', 'teacher', 'instrument'],
  'guitar lessons':        ['music', 'guitar', 'school', 'lesson', 'academy', 'studio', 'teacher', 'instrument'],
  'violin lesson':         ['music', 'violin', 'school', 'lesson', 'academy', 'studio', 'teacher', 'instrument', 'orchestra'],
  'violin lessons':        ['music', 'violin', 'school', 'lesson', 'academy', 'studio', 'teacher', 'instrument', 'orchestra'],
  'math tutor':            ['tutor', 'tutoring', 'education', 'learning center', 'academic', 'school', 'teaching'],
  'coding class':          ['education', 'coding', 'programming', 'school', 'learning center', 'tech', 'academy'],
  'yoga class':            ['yoga', 'pilates', 'studio', 'fitness', 'wellness', 'meditation'],
  'muay thai gym':         ['gym', 'fitness', 'martial art', 'boxing', 'training', 'sports', 'muay thai'],
  'pilates studio':        ['pilates', 'yoga', 'studio', 'fitness', 'wellness', 'health'],
  '3d printing':           ['3d printing', 'printing', 'technology', 'manufacturing', 'fabrication', 'studio'],
  'golf coach':            ['golf', 'coach', 'instructor', 'sport', 'country club', 'training', 'academy'],
  'dance class':           ['dance', 'studio', 'school', 'fitness', 'arts', 'performing'],
  'dance classes':         ['dance', 'studio', 'school', 'fitness', 'arts', 'performing'],
  'ballet lesson':         ['ballet', 'dance school', 'dance studio', 'dance academy', 'performing arts', 'dance class', 'dance lessons'],
  'ballet lessons':        ['ballet', 'dance school', 'dance studio', 'dance academy', 'performing arts', 'dance class', 'dance lessons'],
  'latin dance':           ['dance school', 'dance studio', 'latin dance', 'salsa', 'dance class'],
  'online tutor':          ['tutor', 'tutoring', 'education center', 'educational', 'learning center', 'private tutor', 'teaching', 'academic'],
  'online tutors':         ['tutor', 'tutoring', 'education center', 'educational', 'learning center', 'private tutor', 'teaching', 'academic'],

  // Food & drink
  'pho restaurant':           ['vietnamese', 'pho', 'asian restaurant', 'restaurant'],
  'pho restaurants':          ['vietnamese', 'pho', 'asian restaurant', 'restaurant'],
  'vietnamese restaurant':    ['vietnamese', 'pho', 'asian restaurant', 'restaurant', 'cuisine'],
  'vietnamese restaurants':   ['vietnamese', 'pho', 'asian restaurant', 'restaurant', 'cuisine'],
  'cake shop':                ['bakery', 'cake', 'pastry', 'patisserie', 'confectionery', 'dessert', 'bake'],
  'cake shops':               ['bakery', 'cake', 'pastry', 'patisserie', 'confectionery', 'dessert', 'bake'],
  'catering services':        ['catering', 'caterer', 'event', 'food service', 'banquet', 'hospitality'],
  'catering service':         ['catering', 'caterer', 'event', 'food service', 'banquet', 'hospitality'],
  'catering':                 ['catering', 'caterer', 'event', 'food service', 'banquet', 'hospitality'],
  'caterer':                  ['catering', 'caterer', 'event', 'food service', 'banquet', 'hospitality'],

  // Technology
  'pos system':            ['software', 'technology', 'point of sale', 'retail', 'it', 'computer', 'tech', 'system'],

  // Legal
  'personal injury lawyer':   ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel'],
  'personal injury lawyers':  ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel'],
  'personal injury attorney': ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel'],
  'car accident lawyer':      ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel'],
  'car accident lawyers':     ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel'],
  'family lawyer':            ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'family law', 'mediation'],
  'family lawyers':           ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'family law', 'mediation'],
  'divorce lawyer':           ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'family law', 'mediation'],
  'divorce lawyers':          ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'family law', 'mediation'],
  'criminal defense lawyer':  ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'criminal'],
  'criminal defense lawyers': ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'criminal'],
  'criminal defence lawyer':  ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'criminal'],
  'criminal defence lawyers': ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'criminal'],
  'employment lawyer':        ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'employment', 'labor'],
  'employment lawyers':       ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'barrister', 'counsel', 'employment', 'labor'],
  'immigration lawyer':       ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'immigration', 'visa', 'counsel'],
  'immigration lawyers':      ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'immigration', 'visa', 'counsel'],
  'estate planning lawyer':   ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'notary', 'estate', 'probate', 'will'],
  'estate planning lawyers':  ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'notary', 'estate', 'probate', 'will'],
  'real estate lawyer':       ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'notary', 'real estate', 'conveyancing'],
  'real estate lawyers':      ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'notary', 'real estate', 'conveyancing'],
  'business lawyer':          ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'corporate', 'commercial', 'counsel'],
  'business lawyers':         ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'corporate', 'commercial', 'counsel'],
  'bankruptcy lawyer':        ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'bankruptcy', 'insolvency', 'debt'],
  'bankruptcy lawyers':       ['attorney', 'lawyer', 'law firm', 'legal', 'solicitor', 'bankruptcy', 'insolvency', 'debt'],

  // Events
  'wedding photographer':  ['photographer', 'photography', 'photo', 'studio', 'wedding', 'event'],
  'funeral service':       ['funeral', 'mortuary', 'cremation', 'burial', 'memorial', 'cemetery'],
  'magician':              ['magician', 'entertainer', 'magic', 'performer', 'entertainment', 'event', 'party'],
  'magicians':             ['magician', 'entertainer', 'magic', 'performer', 'entertainment', 'event', 'party'],
  'wedding planner':       ['wedding planner', 'wedding planning', 'event planner', 'event planning', 'wedding coordinator', 'wedding', 'bridal'],
  'wedding planners':      ['wedding planner', 'wedding planning', 'event planner', 'event planning', 'wedding coordinator', 'wedding', 'bridal'],
  'event planner':         ['event planner', 'event planning', 'event management', 'event organizer', 'corporate event', 'party planner', 'entertainment'],
  'event planners':        ['event planner', 'event planning', 'event management', 'event organizer', 'corporate event', 'party planner', 'entertainment'],
  'photography studio':    ['photographer', 'photography', 'photo', 'studio', 'portrait', 'headshot'],
  'gift delivery':         ['gift', 'florist', 'flower', 'delivery', 'hamper', 'balloon', 'souvenir'],
};

/**
 * Global exclusion keywords — applies to ALL verticals regardless of category match.
 * If a business category contains any of these, it is always discarded.
 */
const GLOBAL_CATEGORY_EXCLUSIONS: string[] = [
  // Crypto and digital assets
  'cryptocurrency', 'crypto', 'bitcoin', 'blockchain', 'hardware wallet',
  'digital asset', 'nft', 'token', 'exchange',
  // Real estate
  'real estate developer', 'property developer', 'housing developer', 'land developer',
  // Automotive
  'car dealer', 'auto dealer', 'car rental', 'vehicle rental',
  'auto repair', 'tyre shop', 'tire shop',
  // Food and hospitality
  'restaurant', 'cafe', 'coffee shop', 'hotel', 'resort', 'hostel',
  'food delivery', 'catering',
  // Retail
  'supermarket', 'grocery store', 'convenience store', 'department store',
  'electronics store', 'furniture store',
  // Financial products unrelated to advisory
  'pawnshop', 'money transfer', 'currency exchange',
  // Government and institutions
  'government office', 'embassy', 'consulate', 'courthouse',
  // Tourism
  'tourist attraction', 'theme park',
];

/**
 * Vertical-specific exclusion keywords — applies only to the named vertical.
 * Catches nuances within a vertical where the category word matches but the
 * specific type of business is wrong.
 */
const VERTICAL_EXCLUSIONS: Record<string, string[]> = {
  'mover': [
    'self-storage', 'self storage', 'storage facility', 'mini storage',
    'tour operator', 'travel agency', 'bus company', 'bus service',
    'good morning',
  ],
  'movers': [
    'self-storage', 'self storage', 'storage facility', 'mini storage',
    'tour operator', 'travel agency', 'bus company', 'bus service',
    'good morning',
  ],
  'security company': [
    'cyber', 'cybersecurity', 'it security', 'software', 'hardware',
    'wallet', 'locksmith', 'safe deposit', 'locker', 'storage',
  ],
  'naturopath': [
    'medical clinic', 'hospital', 'pharmacy', 'dental', 'dentist',
    'optical', 'veterinary', 'veterinarian',
  ],
  'physiotherapy': [
    'dental', 'dentist', 'optical', 'pharmacy', 'veterinary',
  ],
  'yoga studios': [
    'gym equipment', 'sports store', 'fitness equipment',
  ],
  'hair salon': [
    'wig', 'hair extension supplier', 'beauty supply',
  ],
  'immigration agency': [
    'airline', 'airport', 'shipping', 'freight',
  ],
  'tax consultants': [
    'bank', 'insurance', 'stockbroker', 'investment fund',
  ],
  'mortgage broker': [
    'insurance', 'real estate agency',
  ],
  'plumbing services': [
    'plumbing supply', 'hardware store', 'plumbing parts',
  ],
  'renovation contractor': [
    'architecture firm',
  ],
  'maid agency': [
    'hotel', 'resort', 'spa',
  ],
  'pos system': [
    'printer', 'electronics retail',
  ],
  'wedding planner': [
    'venue', 'banquet hall', 'event venue', 'hotel', 'resort', 'country club', 'florist', 'photographer', 'caterer',
  ],
  'wedding planners': [
    'venue', 'banquet hall', 'event venue', 'hotel', 'resort', 'country club', 'florist', 'photographer', 'caterer',
  ],
  'event planner': [
    'venue', 'banquet hall', 'event venue', 'hotel', 'resort', 'country club', 'caterer', 'florist',
  ],
  'event planners': [
    'venue', 'banquet hall', 'event venue', 'hotel', 'resort', 'country club', 'caterer', 'florist',
  ],
  'magician': [
    'restaurant', 'cafe', 'bar', 'venue', 'hotel', 'food',
  ],
  'magicians': [
    'restaurant', 'cafe', 'bar', 'venue', 'hotel', 'food',
  ],
  'cake shop': [
    'restaurant', 'cafe', 'coffee shop', 'hotel', 'catering',
  ],
  'cake shops': [
    'restaurant', 'cafe', 'coffee shop', 'hotel', 'catering',
  ],
  'deck builder': [
    'architecture firm', 'real estate', 'interior design',
    'renovation', 'painting', 'flooring', 'lumber', 'wood floor',
  ],
  'deck builders': [
    'architecture firm', 'real estate', 'interior design',
    'renovation', 'painting', 'flooring', 'lumber', 'wood floor',
  ],
  'waterproofing': [
    'architecture firm', 'real estate', 'interior design',
    'general contractor', 'renovation contractor', 'one stop renovation',
    'roofing contractor', 'roofing company', 'roofing service',
    'insulation contractor', 'insulation company',
  ],
  'chiropractor': [
    'dental', 'dentist', 'optical', 'pharmacy', 'veterinary',
  ],
  'chiropractors': [
    'dental', 'dentist', 'optical', 'pharmacy', 'veterinary',
  ],
  'acupuncture': [
    'dental', 'dentist', 'veterinary', 'pharmacy',
  ],
  'acupuncturist': [
    'dental', 'dentist', 'veterinary', 'pharmacy',
  ],
  'optometrist': [
    'dental', 'dentist', 'veterinary', 'pharmacy',
  ],
  'optometrists': [
    'dental', 'dentist', 'veterinary', 'pharmacy',
  ],
  'general practitioner': [
    'dental', 'dentist', 'optical', 'veterinary', 'pharmacy',
  ],
  'family doctor': [
    'dental', 'dentist', 'optical', 'veterinary', 'pharmacy',
  ],
  'plastic surgeon': [
    'dental', 'dentist', 'veterinary', 'pharmacy', 'optical',
  ],
  'plastic surgeons': [
    'dental', 'dentist', 'veterinary', 'pharmacy', 'optical',
  ],
  'dermatologist': [
    'dental', 'dentist', 'veterinary', 'pharmacy', 'optical',
  ],
  'dermatologists': [
    'dental', 'dentist', 'veterinary', 'pharmacy', 'optical',
  ],
  'breast lift': [
    'dental', 'dentist', 'veterinary', 'pharmacy', 'optical',
  ],
  'facelift': [
    'dental', 'dentist', 'veterinary', 'pharmacy', 'optical',
  ],
  'chin filler': [
    'dental', 'dentist', 'veterinary', 'pharmacy', 'optical',
  ],
  'double chin removal': [
    'dental', 'dentist', 'veterinary', 'pharmacy', 'optical',
  ],
  'gynaecologist': [
    'dental', 'dentist', 'veterinary', 'pharmacy', 'optical',
    'medical centre', 'medical center', 'general practice', 'urgent care',
  ],
  'gynaecologists': [
    'dental', 'dentist', 'veterinary', 'pharmacy', 'optical',
    'medical centre', 'medical center', 'general practice', 'urgent care',
  ],
  'thyroid specialist': [
    'dental', 'dentist', 'veterinary', 'pharmacy', 'optical',
  ],
  'hifu': [
    'dental', 'dentist', 'veterinary', 'pharmacy', 'optical',
  ],
  'mold inspection': [
    'construction', 'general contractor', 'renovation',
  ],
  'water heater repair': [
    'plumbing supply', 'hardware store',
  ],
  'pet sitter': [
    'pet boarding', 'boarding facility', 'kennel', 'dog daycare', 'pet hotel',
  ],
  'pet sitters': [
    'pet boarding', 'boarding facility', 'kennel', 'dog daycare', 'pet hotel',
  ],
  'dj': [
    'restaurant', 'bar', 'nightclub', 'club', 'lounge', 'hotel', 'venue',
  ],
  'mma gym': [
    'yoga studio', 'pilates studio', 'crossfit', 'fitness equipment', 'gym equipment',
  ],
  'door repair': [
    'garage door', 'roller door', 'shutter company',
  ],
  'catering': [
    'butcher shop', 'butchery', 'supermarket', 'grocery store',
  ],
  'caterer': [
    'butcher shop', 'butchery', 'supermarket', 'grocery store',
  ],
  'bike shop': [
    'motorbike', 'motorcycle', 'scooter', 'moped', 'bicycle rental', 'bike rental',
  ],
  'math tutor': [
    'school', 'university', 'college', 'institution',
  ],
  'math tutors': [
    'school', 'university', 'college', 'institution',
  ],
  'violin lesson': [
    'music store', 'instrument store', 'instrument shop', 'retail',
    'rock school', 'rock music',
  ],
  'violin lessons': [
    'music store', 'instrument store', 'instrument shop', 'retail',
    'rock school', 'rock music',
  ],
  'guitar lesson': [
    'instrument store', 'instrument shop', 'retail', 'music store',
  ],
  'guitar lessons': [
    'instrument store', 'instrument shop', 'retail', 'music store',
  ],
  'probate lawyer': [
    'conveyancing', 'family law firm', 'commercial law', 'litigation firm',
    'business law', 'corporate law', 'personal injury', 'criminal', 'immigration',
  ],
  'probate lawyers': [
    'conveyancing', 'family law firm', 'commercial law', 'litigation firm',
    'business law', 'corporate law', 'personal injury', 'criminal', 'immigration',
  ],
};

/**
 * Vertical-specific name-based exclusions — checked against the business name only,
 * not the Google Maps category label. Use when a category keyword legitimately
 * matches the vertical but the business name reveals it is a different discipline.
 */
const VERTICAL_NAME_EXCLUSIONS: Record<string, string[]> = {
  'ballet lesson': [
    'latin dance', 'salsa', 'flamenco', 'hip hop', 'hiphop', 'ballroom',
  ],
  'ballet lessons': [
    'latin dance', 'salsa', 'flamenco', 'hip hop', 'hiphop', 'ballroom',
  ],
  'wedding planner': [
    'restaurant', 'bistro', 'cafe', 'kitchen', 'dining', 'eatery', 'grill',
    'photography', 'photographer', 'photo studio',
    'palace', 'palazzo', 'villa', 'historic', 'teambuilding', 'team building',
    'bridal shop', 'bridal store', 'textiles', 'fabric', 'dress shop',
    'corporate event',
  ],
  'wedding planners': [
    'restaurant', 'bistro', 'cafe', 'kitchen', 'dining', 'eatery', 'grill',
    'photography', 'photographer', 'photo studio',
    'palace', 'palazzo', 'villa', 'historic', 'teambuilding', 'team building',
    'bridal shop', 'bridal store', 'textiles', 'fabric', 'dress shop',
    'corporate event',
  ],
  'deck builder': [
    'one stop renovation', 'renovation specialist', 'painting',
    'enclosure', 'screen', 'pergola',
    'siding', 'seawall', 'marine construction', 'dock', 'boat', 'waterfront',
    'handyman', 'home maintenance', 'home repair', 'honey do',
  ],
  'deck builders': [
    'one stop renovation', 'renovation specialist', 'painting',
    'enclosure', 'screen', 'pergola',
    'siding', 'seawall', 'marine construction', 'dock', 'boat', 'waterfront',
    'handyman', 'home maintenance', 'home repair', 'honey do',
  ],
  'waterproofing': [
    'one stop renovation', 'renovation specialist',
    'roofing', 'insulation',
  ],
  'facelift': [
    'eyelid', 'body contouring', 'body sculpt',
  ],
  'cake shop': [
    'donut', 'doughnut',
  ],
  'cake shops': [
    'donut', 'doughnut',
  ],
  'magician': [
    'waffle', 'donut', 'food', 'dessert', 'mirror hire', 'photo booth',
    'magic mirror', 'princess parties', 'character entertainment',
  ],
  'magicians': [
    'waffle', 'donut', 'food', 'dessert', 'mirror hire', 'photo booth',
    'magic mirror', 'princess parties', 'character entertainment',
  ],
  'catering services': [
    'butcher', 'metzgerei', 'butchery',
  ],
  'catering service': [
    'butcher', 'metzgerei', 'butchery',
  ],
  'vietnamese restaurant': [
    'sky bar', 'rooftop bar', 'cocktail bar',
  ],
  'vietnamese restaurants': [
    'sky bar', 'rooftop bar', 'cocktail bar',
  ],
  'property lawyer': [
    'elder law', 'bankruptcy', 'wills platform', 'online will', 'legalwills',
    'personal injury', 'family law', 'criminal', 'divorce', 'dwi', 'accident',
  ],
  'property lawyers': [
    'elder law', 'bankruptcy', 'wills platform', 'online will', 'legalwills',
    'personal injury', 'family law', 'criminal', 'divorce', 'dwi', 'accident',
  ],
  'gynaecologist': [
    'medcentres', 'medical centre', 'urgent care',
  ],
  'gynaecologists': [
    'medcentres', 'medical centre', 'urgent care',
  ],
  'breast lift': [
    'non-surgical', 'cosmetic consultations',
  ],
  'mold removal': [
    'pressure washing', 'power washing', 'restoration', 'painting',
  ],
  'event planner': [
    'venue', 'banquet hall', 'ballroom', 'hall hire', 'hall rental', 'space hire',
  ],
  'event planners': [
    'venue', 'banquet hall', 'ballroom', 'hall hire', 'hall rental', 'space hire',
  ],
  'pet sitter': [
    'boarding', 'kennel', 'daycare', 'grooming',
  ],
  'pet sitters': [
    'boarding', 'kennel', 'daycare', 'grooming',
  ],
  'dj': [
    'restaurant', 'bar', 'club', 'venue', 'nightclub', 'hotel',
  ],
  'mma gym': [
    'yoga', 'pilates', 'crossfit', 'weight', 'fitness center',
  ],
  'door repair': [
    'garage door', 'garage', 'roller door', 'shutter',
  ],
  'catering': [
    'butcher', 'metzgerei', 'butchery', 'supermarket', 'grocery',
  ],
  'caterer': [
    'butcher', 'metzgerei', 'butchery', 'supermarket', 'grocery',
  ],
  'violin lesson': [
    'quartet', 'quintet', 'trio', 'ensemble', 'orchestra', 'symphony', 'philharmonic',
    'performer', 'band', 'string band', 'school of rock',
  ],
  'violin lessons': [
    'quartet', 'quintet', 'trio', 'ensemble', 'orchestra', 'symphony', 'philharmonic',
    'performer', 'band', 'string band', 'school of rock',
  ],
  'guitar lesson': [
    'quartet', 'quintet', 'trio', 'ensemble', 'orchestra', 'symphony', 'philharmonic',
    'performer', 'band', 'string band', 'lutherie', 'luthier', 'violinist',
  ],
  'guitar lessons': [
    'quartet', 'quintet', 'trio', 'ensemble', 'orchestra', 'symphony', 'philharmonic',
    'performer', 'band', 'string band', 'lutherie', 'luthier', 'violinist',
  ],
};

function normaliseVertical(vertical: string): string {
  return vertical.toLowerCase().trim();
}

function isGloballyExcluded(category: string): boolean {
  const catLower = category.toLowerCase();
  return GLOBAL_CATEGORY_EXCLUSIONS.some(keyword => catLower.includes(keyword));
}

function isVerticalExcluded(category: string, vertical: string, name?: string): boolean {
  const key = normaliseVertical(vertical);
  const exclusions = VERTICAL_EXCLUSIONS[key];
  if (!exclusions) return false;
  const catLower = category.toLowerCase();
  const nameLower = (name ?? '').toLowerCase();
  return exclusions.some(keyword => catLower.includes(keyword) || nameLower.includes(keyword));
}

function isVerticalNameExcluded(name: string, vertical: string): boolean {
  const key = normaliseVertical(vertical);
  const exclusions = VERTICAL_NAME_EXCLUSIONS[key];
  if (!exclusions) return false;
  const nameLower = name.toLowerCase();
  return exclusions.some(keyword => nameLower.includes(keyword));
}

const BUSINESS_NAME_EXCLUSIONS: string[] = [
  'hardware wallet', 'ledger', 'trezor', 'safepal', 'yubikey',
  'bitcoin', 'crypto', 'blockchain', 'nft', 'forex trading',
];

function nameIsExcluded(name: string): boolean {
  const nameLower = name.toLowerCase();
  return BUSINESS_NAME_EXCLUSIONS.some(keyword => nameLower.includes(keyword));
}

/**
 * Returns true when the category label is a Google Maps price-range indicator
 * (e.g. "· £", "· ££", "· $$$", "· ฿฿") rather than a cuisine or business-type
 * label. Google Maps shows price ranges instead of cuisine labels for many
 * restaurants, so a price-range-only category must not trigger the category
 * filter — the listing should pass through as if no category were present.
 *
 * Matches the bullet separator (· or •) followed by one or more currency symbols
 * from the set: £ $ ฿ € ¥ ₩
 */
const PRICE_RANGE_RE = /[·•]\s*[£$฿€¥₩₫₱₴₸]+/;

function isPriceRangeCategory(category: string): boolean {
  return PRICE_RANGE_RE.test(category);
}

const _warnedVerticals = new Set<string>();

function categoryMatches(category: string | null, vertical: string, name?: string): boolean {
  const key = normaliseVertical(vertical);
  const allowed = VERTICAL_CATEGORY_MAP[key];

  // No category captured — give benefit of the doubt, but still enforce name exclusions
  if (!category) return !isVerticalNameExcluded(name ?? '', vertical);

  // Price-range category (e.g. "· £", "· $$", "· ฿฿") — Google Maps uses these
  // instead of cuisine labels for many restaurants. Treat identically to no category:
  // pass through without filtering so legitimate restaurants aren't dropped.
  if (isPriceRangeCategory(category)) return true;

  const catLower = category.toLowerCase();

  // Explicit inclusion check — runs BEFORE global exclusions.
  // When a vertical has an inclusion list and the category matches it, that is a
  // deliberate override: e.g. "pho restaurants" explicitly allows 'restaurant' even
  // though 'restaurant' is a global exclusion for every other vertical.
  if (allowed && allowed.some(keyword => catLower.includes(keyword))) return true;

  // Global exclusions — always discard (unless overridden by explicit inclusion above)
  if (isGloballyExcluded(category)) return false;

  // Vertical-specific exclusions
  if (isVerticalExcluded(category, vertical, name)) return false;

  // No inclusion rule defined — attempt direct vertical-term match as best-effort guard.
  // Splits the vertical into words (>3 chars) and requires at least one to appear in the
  // category. Falls back to true only when no meaningful words can be extracted (e.g. a
  // single-char vertical, which is unusual).
  if (!allowed) {
    const verticalWords = key.split(/\s+/).filter(w => w.length > 3);
    if (verticalWords.length === 0) return true;
    const matched = verticalWords.some(word => catLower.includes(word));
    if (!matched) {
      // Warn once per vertical so operators know to add it to the map.
      if (!_warnedVerticals.has(key)) {
        _warnedVerticals.add(key);
        console.warn(
          `  [filter] Vertical "${key}" not in VERTICAL_CATEGORY_MAP — using direct-term match. ` +
          `Consider adding it to categoryFilter.ts for precision.`
        );
      }
    }
    return matched;
  }

  // allowed list exists but category did not match it (handled above) — discard
  return false;
}

/**
 * Filter out listings whose Google Maps category does not match the vertical.
 * Decision order: price-range pass-through → explicit inclusion (overrides global
 * exclusions) → global exclusions → vertical exclusions → direct-term fallback.
 */
export function applyCategoryFilter(listings: ScoredListing[], vertical: string): ScoredListing[] {
  const filtered: ScoredListing[] = [];
  for (const listing of listings) {
    if (nameIsExcluded(listing.name)) {
      console.log(`  [filter] Excluded by name: "${listing.name}"`);
      logDiscard('Wrong category', listing.name, 'excluded by business name');
    } else if (isVerticalNameExcluded(listing.name, vertical)) {
      console.log(`  [filter] Excluded by vertical name rule: "${listing.name}" (vertical "${vertical}")`);
      logDiscard('Wrong category', listing.name, 'excluded by vertical name rule');
    } else if (categoryMatches(listing.category, vertical, listing.name)) {
      filtered.push(listing);
    } else {
      console.log(`  [filter] Wrong category: "${listing.name}" (${listing.category ?? 'no category'}) does not match vertical "${vertical}"`);
      logDiscard('Wrong category', listing.name, listing.listingUrl ?? listing.category ?? undefined);
    }
  }

  if (filtered.length < listings.length) {
    console.log(`  [filter] Category filter removed ${listings.length - filtered.length} wrong-category listing(s)`);
  }

  return filtered;
}

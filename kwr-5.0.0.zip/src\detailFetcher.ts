import { Page } from 'playwright';
import { ScoredListing, EnrichedListing } from './types';
import { resolveSelector, FALLBACK_CHAINS } from './selectors';
import { randomDelay, humanMove } from './humanize';
import { matchesCity } from './cityMatcher';
import { GEO_REGEX } from './geocoder';

const WEBSITE_SELECTORS = FALLBACK_CHAINS['websiteInDetail'];
const ADDRESS_SELECTORS = FALLBACK_CHAINS['addressInDetail'];

/** Strip Google redirect wrapper from URLs like /url?q=https://example.com */
const INVALID_WEBSITE_DOMAINS = [
  'google.com',
  'googleadservices.com',
];

function isInvalidWebsite(url: string): boolean {
  try {
    const domain = new URL(url).hostname.replace(/^www\./, '');
    return INVALID_WEBSITE_DOMAINS.some(d => domain === d || domain.endsWith('.' + d));
  } catch {
    return false;
  }
}

function stripGoogleRedirect(url: string): string {
  try {
    const parsed = new URL(url, 'https://www.google.com');
    const q = parsed.searchParams.get('q');
    if (q) return q;
  } catch {
    // Not a URL — return as-is
  }
  return url;
}

/** Try each website selector in the confirmed panel, return the first href found */
async function extractWebsiteFromPanel(page: Page, listingName: string): Promise<string | null> {
  for (const sel of WEBSITE_SELECTORS) {
    try {
      await page.waitForSelector(sel, { timeout: 4000, state: 'visible' });
      const href = await page.$eval(sel, (el) =>
        (el as HTMLAnchorElement).href ?? (el as HTMLAnchorElement).getAttribute('href') ?? null
      );
      if (href) return href;
    } catch {
      // try next selector
    }
  }
  console.warn(`  [detail] Website link not found for "${listingName}" (all selectors failed)`);
  return null;
}

/** Extract the full address text from the confirmed panel */
async function extractAddressFromPanel(page: Page): Promise<string | null> {
  for (const sel of ADDRESS_SELECTORS) {
    try {
      const text = await page.$eval(sel, (el) => {
        const aria = el.getAttribute('aria-label');
        if (aria && aria.length > 5) return aria.replace(/^Address:\s*/i, '').trim();
        return el.textContent?.trim() ?? null;
      });
      if (text) return text;
    } catch {
      // try next selector
    }
  }
  return null;
}

const SOCIAL_DOMAINS_DETAIL = ['instagram.com', 'facebook.com', 'twitter.com', 'x.com', 'fb.com', 'tiktok.com', 'linkedin.com'];

function isSocialUrl(url: string): boolean {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    return SOCIAL_DOMAINS_DETAIL.some(d => host === d || host.endsWith('.' + d));
  } catch {
    return false;
  }
}

interface DetailResult {
  websiteUrl: string | null;
  socialUrl: string | null;
  mapsUrl: string | null;
  address: string | null;
  cityMatch: boolean;
  lat?: number;
  lng?: number;
}

/** Click a listing card and extract website URL + address from the detail panel */
async function fetchDetailWebsite(
  page: Page,
  listing: ScoredListing,
  city: string,
  cardSel: string,
  anchorSel: string,
): Promise<DetailResult> {
  // Find the sidebar card containing this listing's name, then get its anchor.
  const anchorEl = await page.evaluateHandle(
    ({ name, cardSelector, anchorSelector }: { name: string; cardSelector: string; anchorSelector: string }) => {
      const cards = Array.from(document.querySelectorAll(cardSelector));
      for (const card of cards) {
        if (card.textContent?.includes(name)) {
          const a = card.querySelector(anchorSelector) ?? card.querySelector('a[href*="/maps/place/"]');
          if (a) return a;
        }
      }
      const byLabel = document.querySelector(`a[aria-label*="${name.slice(0, 30)}"]`);
      return byLabel ?? null;
    },
    { name: listing.name, cardSelector: cardSel, anchorSelector: anchorSel },
  ).catch(() => null);

  const resolvedAnchor = anchorEl ? await anchorEl.asElement() : null;

  if (!resolvedAnchor) {
    console.warn(`  [detail] Could not locate card for "${listing.name}" — skipping`);
    return { websiteUrl: null, socialUrl: null, mapsUrl: null, address: null, cityMatch: true };
  }

  // Scroll into view
  await resolvedAnchor.scrollIntoViewIfNeeded();
  await randomDelay(300, 600);

  // Human-like hover before click
  const box = await resolvedAnchor.boundingBox();
  if (box) {
    await humanMove(page, box.x + box.width / 2, box.y + box.height / 2);
  }

  const urlBefore = page.url();
  await resolvedAnchor.click();

  // Wait for SPA navigation
  try {
    await page.waitForFunction(
      (before: string) => window.location.href !== before,
      urlBefore,
      { timeout: 6000 }
    );
  } catch {
    // URL didn't change — proceed anyway
  }

  // Confirm h1 heading matches this listing before extracting anything.
  // If unconfirmed, return null — do NOT proceed with stale panel data.
  const nameFragment = listing.name.slice(0, 15).toLowerCase();
  const H1_SELECTORS = ['h1.DUwDvf', 'h1[class*="fontHeadlineLarge"]', 'h1'];
  let panelReady = false;
  for (const h1Sel of H1_SELECTORS) {
    try {
      await page.waitForFunction(
        ({ sel, fragment }: { sel: string; fragment: string }) => {
          const el = document.querySelector(sel);
          return !!el && el.textContent?.toLowerCase().includes(fragment);
        },
        { sel: h1Sel, fragment: nameFragment },
        { timeout: 6000 }
      );
      panelReady = true;
      break;
    } catch {
      // try next h1 selector
    }
  }

  if (!panelReady) {
    console.warn(`  [detail] Panel heading did not confirm "${listing.name}" — skipping (stale panel guard)`);
    return { websiteUrl: null, socialUrl: null, mapsUrl: null, address: null, cityMatch: true };
  }

  const pageUrl = page.url();
  const coordMatch = GEO_REGEX.exec(pageUrl);
  const lat = coordMatch ? parseFloat(coordMatch[1]) : undefined;
  const lng = coordMatch ? parseFloat(coordMatch[2]) : undefined;

  // Capture the Google Maps place URL as a last-resort reference
  const mapsUrl = pageUrl.includes('/maps/place/') ? pageUrl : null;

  await randomDelay(200, 400);

  // Extract address and check city match using alias-aware matcher
  const address = await extractAddressFromPanel(page);
  const cityMatch = matchesCity(address, city);
  if (!cityMatch) {
    console.warn(`  [detail] City mismatch: "${listing.name}" → "${address}" (expected "${city}")`);
  }

  // Extract website URL — split social media into its own field
  const rawHref = await extractWebsiteFromPanel(page, listing.name);
  const stripped = rawHref ? stripGoogleRedirect(rawHref) : null;
  const resolvedUrl = stripped && !isInvalidWebsite(stripped) ? stripped : null;

  let websiteUrl: string | null = null;
  let socialUrl: string | null = null;
  if (resolvedUrl) {
    if (isSocialUrl(resolvedUrl)) {
      socialUrl = resolvedUrl;
      console.log(`  [detail] Social media URL captured as fallback for "${listing.name}": ${resolvedUrl}`);
    } else {
      websiteUrl = resolvedUrl;
    }
  }

  return { websiteUrl, socialUrl, mapsUrl, address, cityMatch, lat, lng };
}

/** Phase 2: click each candidate and extract website URLs + addresses */
export async function fetchWebsiteUrls(
  page: Page,
  candidates: ScoredListing[],
  city: string,
): Promise<EnrichedListing[]> {
  const cardSel = await resolveSelector(page, 'listingCard');
  const anchorSel = await resolveSelector(page, 'listingAnchor');

  const results: EnrichedListing[] = [];

  for (let i = 0; i < candidates.length; i++) {
    const listing = candidates[i];
    console.log(`  [detail] ${i + 1}/${candidates.length}: "${listing.name}"`);

    const { websiteUrl, socialUrl, mapsUrl, address, cityMatch, lat, lng } = await fetchDetailWebsite(page, listing, city, cardSel, anchorSel);

    results.push({
      ...listing,
      websiteUrl,
      websiteVerified: false,
      address,
      cityMatch,
      lat,
      lng,
      socialUrl,
      mapsUrl,
    });

    await randomDelay(800, 1800);
  }

  return results;
}

import { EnrichedListing } from './types';
import { logDiscard } from './discardLog';
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

/**
 * Optional on-disk cache for page-body fetches, enabled by KWR_HTTP_CACHE=<dir>.
 * Used by the offline replay runner so repeated gate evaluations (e.g. comparing
 * the language-aware gate against the old behavior) read identical page content
 * instead of re-fetching — making the before/after comparison deterministic.
 */
function httpCachePath(url: string): string | null {
  const dir = process.env.KWR_HTTP_CACHE;
  if (!dir) return null;
  const key = crypto.createHash('sha1').update(url).digest('hex');
  return path.join(dir, key);
}

const VERIFY_TIMEOUT_MS = 15000;
const SPAM_GET_TIMEOUT_MS = 6000;
const THIN_LINK_THRESHOLD = 3;
const FETCH_MAX_BYTES = 100 * 1024; // 100 KB for link counting

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

const SOCIAL_DOMAINS = ['instagram.com', 'facebook.com', 'twitter.com', 'x.com', 'fb.com', 'tiktok.com'];
const SPAM_KEYWORDS = /casino|betting|gambling|slots|poker|roulette|sportsbook|togel|judi|viagra|cialis|payday loan|crypto investment|escort|xxx/i;
/** Parked / for-sale / expired domain pages — the original business site is gone */
const PARKED_KEYWORDS = /domain (is )?for sale|buy this domain|this domain has expired|domain parking|parked free|sedoparking|hugedomains|afternic|dan\.com\/buy|godaddy auctions|related searches/i;

/** Known URL shortener domains that should be resolved to their final destination */
const URL_SHORTENER_DOMAINS = new Set([
  'bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'ow.ly', 'short.io',
  'buff.ly', 'rebrand.ly', 'tiny.cc', 'is.gd', 'bl.ink', 'cutt.ly',
]);

/** Registrable domain approximation: last two labels (last three for ccTLD pairs like .co.uk) */
function registrableDomain(url: string): string | null {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '').toLowerCase();
    const parts = host.split('.');
    if (parts.length <= 2) return host;
    const ccSecond = new Set(['co', 'com', 'net', 'org', 'gov', 'edu', 'ac']);
    const takeThree = parts[parts.length - 1].length === 2 && ccSecond.has(parts[parts.length - 2]);
    return parts.slice(takeThree ? -3 : -2).join('.');
  } catch {
    return null;
  }
}

/**
 * SSRF guard: block private, loopback, and link-local hosts so a scraped/redirected
 * URL can't make the tool fetch internal services or cloud metadata (169.254.169.254).
 * Unparseable input is blocked too (fail closed).
 */
function isBlockedHost(url: string): boolean {
  try {
    const host = new URL(url).hostname.toLowerCase().replace(/^\[|\]$/g, '');
    if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local')) return true;
    if (host === '::1' || host.startsWith('fe80:') || host.startsWith('fc') || host.startsWith('fd')) return true;
    const m = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
    if (m) {
      const a = +m[1], b = +m[2];
      if (a === 0 || a === 10 || a === 127) return true;          // this-host / private / loopback
      if (a === 169 && b === 254) return true;                    // link-local + cloud metadata
      if (a === 192 && b === 168) return true;                    // private
      if (a === 172 && b >= 16 && b <= 31) return true;           // private
      if (a >= 224) return true;                                  // multicast / reserved
    }
    return false;
  } catch {
    return true;
  }
}

/**
 * Read up to maxBytes of a response body with a hard time cap, cancelling the stream
 * when either limit is hit. Prevents a slow-drip or multi-hundred-MB hostile page
 * (parked domains, bot traps) from hanging or OOM-ing the whole run — res.text()
 * would read the entire body with no bound.
 */
async function readCapped(res: Response, maxBytes: number, timeoutMs: number): Promise<string> {
  const body = res.body as ReadableStream<Uint8Array> | null;
  if (!body || typeof body.getReader !== 'function') {
    const t = await res.text();
    return t.slice(0, maxBytes);
  }
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let received = 0;
  let out = '';
  const timer = setTimeout(() => { reader.cancel().catch(() => {}); }, timeoutMs);
  try {
    while (received < maxBytes) {
      const { done, value } = await reader.read();
      if (done) break;
      received += value.length;
      out += decoder.decode(value, { stream: true });
    }
  } catch {
    /* cancelled or aborted — return whatever we managed to read */
  } finally {
    clearTimeout(timer);
    reader.cancel().catch(() => {});
  }
  return out.slice(0, maxBytes);
}

function isSocialMedia(url: string): boolean {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    return SOCIAL_DOMAINS.some((d) => host === d || host.endsWith('.' + d));
  } catch {
    return false;
  }
}

function isUrlShortener(url: string): boolean {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    return URL_SHORTENER_DOMAINS.has(host);
  } catch {
    return false;
  }
}

/** Follow a shortened URL to its final destination */
async function resolveShortUrl(url: string): Promise<string> {
  if (isBlockedHost(url)) return url;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), VERIFY_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      method: 'HEAD',
      signal: controller.signal,
      redirect: 'follow',
      headers: { 'User-Agent': UA },
    });
    clearTimeout(timer);
    const finalUrl = response.url;
    if (finalUrl && isBlockedHost(finalUrl)) return url; // don't resolve to a private host
    if (finalUrl && finalUrl !== url) {
      console.log(`  [verify] Resolved short URL: ${url} → ${finalUrl}`);
      return finalUrl;
    }
    return url;
  } catch {
    clearTimeout(timer);
    return url;
  }
}

const BLOCKED_SENTINEL = '__BLOCKED__';
const RETRY_ATTEMPTS = 3;

/** Strip UTM and common tracking parameters so redirect chains resolve cleanly */
function stripTrackingParams(url: string): string {
  try {
    const u = new URL(url);
    const trackingKeys = [...u.searchParams.keys()].filter(
      k => k.startsWith('utm_') || ['fbclid', 'gclid', 'msclkid', 'mc_eid', 'ref'].includes(k)
    );
    trackingKeys.forEach(k => u.searchParams.delete(k));
    return u.toString();
  } catch {
    return url;
  }
}

/** fetch with automatic retry on transient network errors (not HTTP 4xx/5xx) */
async function fetchWithRetry(url: string, options: RequestInit, timeoutMs: number): Promise<Response> {
  let lastErr: unknown;
  for (let attempt = 0; attempt < RETRY_ATTEMPTS; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, { ...options, signal: controller.signal });
      clearTimeout(timer);
      return res;
    } catch (err) {
      clearTimeout(timer);
      lastErr = err;
      if (attempt < RETRY_ATTEMPTS - 1) {
        await new Promise(r => setTimeout(r, 400 * Math.pow(2, attempt)));
      }
    }
  }
  throw lastErr;
}

/** Fetch up to 100 KB of a page for spam + thin-content checks.
 *  Returns BLOCKED_SENTINEL if the server blocks automated GET requests (403/401/406).
 *  Returns empty string on network error or timeout.
 */
async function fetchPageSnippet(url: string): Promise<string> {
  const cachePath = httpCachePath(url);
  if (cachePath && fs.existsSync(cachePath)) {
    return fs.readFileSync(cachePath, 'utf8');
  }

  let result: string;
  if (isBlockedHost(url)) {
    result = '';
  } else {
    try {
      const res = await fetchWithRetry(url, { method: 'GET', headers: { 'User-Agent': UA }, redirect: 'follow' }, SPAM_GET_TIMEOUT_MS);
      if (isBlockedHost(res.url || url)) {
        result = '';
      } else if (res.status === 403 || res.status === 401 || res.status === 406) {
        result = BLOCKED_SENTINEL;
      } else {
        // Bounded, time-capped read — never read an unbounded body (hang/OOM guard).
        result = await readCapped(res, FETCH_MAX_BYTES, SPAM_GET_TIMEOUT_MS);
      }
    } catch {
      result = '';
    }
  }

  if (cachePath) {
    try {
      fs.mkdirSync(path.dirname(cachePath), { recursive: true });
      fs.writeFileSync(cachePath, result);
    } catch { /* cache is best-effort */ }
  }
  return result;
}

/** Classify one href/data-href value and add it to the seen set if internal */
function addInternalLink(href: string, baseDomain: string, seen: Set<string>): void {
  if (!href || href.startsWith('mailto:') || href.startsWith('tel:') || href.startsWith('javascript:')) return;
  if (href.startsWith('/') && !href.startsWith('//')) {
    seen.add(href.split('?')[0]);
  } else {
    try {
      const u = new URL(href);
      if (u.hostname.replace(/^www\./, '') === baseDomain) {
        seen.add(u.pathname);
      }
    } catch { /* not a URL — skip */ }
  }
}

/**
 * Count distinct internal link paths in fetched HTML.
 * Scans both standard `href` attributes and `data-href` attributes — the latter
 * is used by Wix and similar JS site builders where the `href` on <a> tags is
 * left blank and the real destination is stored in `data-href`.
 */
function countInternalLinks(html: string, baseUrl: string): number {
  let baseDomain: string;
  try {
    baseDomain = new URL(baseUrl).hostname.replace(/^www\./, '');
  } catch {
    return 0;
  }
  const seen = new Set<string>();
  let match;

  // Standard href attributes
  const hrefRegex = /\bhref=["']([^"'#][^"']*?)["']/gi;
  while ((match = hrefRegex.exec(html)) !== null) {
    addInternalLink(match[1], baseDomain, seen);
  }

  // data-href attributes (Wix, Weebly, and similar builders)
  const dataHrefRegex = /\bdata-href=["']([^"']+)["']/gi;
  while ((match = dataHrefRegex.exec(html)) !== null) {
    addInternalLink(match[1], baseDomain, seen);
  }

  return seen.size;
}

/**
 * Detect WordPress sites — their <head> sections are often so large (inline CSS,
 * image preloads, plugin scripts) that the 100 KB fetch cap is exhausted before
 * any <a> nav tags appear in the <body>, causing false thin-content failures.
 */
function isWordPressSite(html: string): boolean {
  return html.includes('/wp-content/') || html.includes('/wp-includes/');
}

/**
 * Detect JS site builders (Wix, Squarespace, Webflow) as a fallback safety net
 * for cases where data-href counting still yields too few links.
 */
function isJsBuilderSite(html: string): boolean {
  return (
    html.includes('static.wixstatic.com') ||
    html.includes('squarespace-cdn.com') ||
    html.includes('assets.squarespace.com') ||
    html.includes('assets.website-files.com') ||  // Webflow
    html.includes('cdn.builder.io')                // Builder.io
  );
}

/**
 * Returns true when the page contains enough business signals to be trusted as a
 * legitimate simple site even if it has fewer than THIN_LINK_THRESHOLD internal links.
 *
 * ALL three of the following must be present:
 *   1. A non-empty <title> tag with more than 10 characters of meaningful text.
 *   2. A <meta name="description"> tag with a non-empty content attribute.
 *   3. At least one of: a phone number pattern, an email address, or a contact-form indicator.
 *
 * Typical cases: small tutoring/service businesses with a single-page or
 * minimal-nav site that is otherwise fully legitimate.
 */
export function isSimpleLegitSite(html: string): boolean {
  // 1. Non-empty <title> with more than 10 meaningful characters
  const titleMatch = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html);
  const titleText = (titleMatch?.[1] ?? '').trim();
  if (titleText.length <= 10) return false;

  // 2. <meta name="description"> with non-empty content (attribute order-independent)
  const descMatch =
    /<meta[^>]*name=["']description["'][^>]*content=["']([^"']+)/i.exec(html) ??
    /<meta[^>]*content=["']([^"']+)["'][^>]*name=["']description["']/i.exec(html);
  if (!descMatch || !descMatch[1].trim()) return false;

  // 3. At least one contact signal
  const PHONE_RE    = /(\+?\d[\d\s\-(). ]{6,}\d)/;
  const EMAIL_RE    = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/;
  const FORM_RE     = /<form\b|<input[^>]+type=["']submit["']|name=["']contact/i;
  return PHONE_RE.test(html) || EMAIL_RE.test(html) || FORM_RE.test(html);
}

/** Detect bot-challenge pages that return HTTP 200 with minimal JS-only content */
function isBotChallengePage(html: string): boolean {
  return (
    html.includes('cf_chl_opt') ||
    html.includes('cf-browser-verification') ||
    html.includes('challenge-platform') ||
    (html.includes('Just a moment') && html.length < 15000)
  );
}

/** Strip tags/scripts and return visible text from an HTML chunk */
function visibleText(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ');
}

/** Function words unique to non-English Latin-script languages (French, German,
 *  Spanish, Italian, Portuguese). None are English words, so their presence is
 *  positive evidence the page is not English. */
const NON_ENGLISH_STOPWORDS = [
  // French
  ' le ', ' la ', ' les ', ' des ', ' du ', ' une ', ' nous ', ' vous ', ' pour ',
  ' avec ', ' est ', ' sont ', ' qui ', ' nos ', ' votre ', ' notre ', ' aux ',
  ' et ', ' de ', ' à ', ' en ', ' sur ', ' ce ', ' ces ', ' sans ',
  // German
  ' der ', ' die ', ' das ', ' und ', ' für ', ' mit ', ' wir ', ' nicht ', ' ist ', ' auch ', ' sie ',
  // Spanish / Italian / Portuguese
  ' los ', ' las ', ' por ', ' para ', ' con ', ' una ', ' che ', ' per ', ' não ', ' você ', ' são ', ' com ',
];

/** Accented Latin letters (French/German/Spanish/Portuguese/Italian). English
 *  uses almost none, so a meaningful count is positive non-English evidence. */
const ACCENTED_LATIN = /[À-ÿĀ-ž]/g;

/** Vietnamese-specific letters (đ ơ ư + stacked tone marks) that French/German
 *  accents do not use — a reliable Vietnamese signal. */
const VIETNAMESE_CHARS = /[đơưăạảấầẩẫậắằẳẵặẹẻẽếềểễệịỉọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]/gi;

/** Non-Latin scripts: Thai, CJK, Hiragana/Katakana, Hangul, Cyrillic, Arabic. */
const NON_LATIN_SCRIPT = /[฀-๿一-鿿぀-ヿ가-힯Ѐ-ӿ؀-ۿ]/g;

/**
 * Positive non-English detection: returns true only when the page shows concrete
 * evidence of another language. Used to decide whether the English-only keyword
 * gate can fairly be applied (see missingRequiredKeyword).
 *
 * This is deliberately "guilty only on positive evidence": a sparse English page
 * (few function words, lots of image/gallery markup) must NOT be mistaken for
 * non-English, or the gate would be skipped and wrong-category businesses would
 * slip through. Earlier an "absence of English markers" heuristic did exactly
 * that — a 70 KB English photographer site with one stray marker was treated as
 * non-English and kept in a videographer search. Input is expected lower-cased.
 */
function isProbablyNonEnglish(lowerText: string): boolean {
  // 1. Non-Latin script (Thai/CJK/etc.) — a handful of real glyphs is conclusive.
  if ((lowerText.match(NON_LATIN_SCRIPT) ?? []).length >= 6) return true;
  // 2. Vietnamese diacritics — these appear densely in real Vietnamese copy.
  if ((lowerText.match(VIETNAMESE_CHARS) ?? []).length >= 5) return true;
  // 3. Accented Latin letters — French/German/Spanish/etc. pages carry many;
  //    English carries almost none (the odd "café" won't reach this count).
  if ((lowerText.match(ACCENTED_LATIN) ?? []).length >= 10) return true;
  // 4. French/German/Spanish/etc. function words — several distinct hits.
  const padded = ` ${lowerText} `;
  let distinct = 0;
  for (const w of NON_ENGLISH_STOPWORDS) {
    if (padded.includes(w)) distinct++;
    if (distinct >= 4) return true;
  }
  return false;
}

/**
 * Required-page-keyword verticals: a "vertical" whose Google Maps category is
 * ambiguous because many business types share it, so the category filter cannot
 * tell who actually does the thing the user searched for. The only reliable signal
 * is the business's own website.
 *
 *  - A *procedure* named as a vertical (e.g. "HIFU"): every med spa matches the
 *    category, but only some offer the procedure.
 *  - A *legal specialty* (e.g. "property lawyer"): every firm matches "law firm" /
 *    "attorney", but estate-planning, family-law and PI firms are not property law.
 *
 * For these verticals, a readable page that never mentions any accepted keyword is
 * dropped. Unreadable pages (bot-blocked, JS-rendered) keep the existing
 * benefit-of-the-doubt — this gate only acts on positive evidence of absence,
 * never on inability to read. A keyword present in the business name/GMB listing
 * is also accepted (covers JS-rendered sites whose copy can't be read).
 */

/**
 * Language-agnostic required keywords: checked even when isProbablyNonEnglish is
 * true. Only use terms that are genuinely universal — the same word (or close
 * cognate) appears in Vietnamese, French, Thai, etc. pages for the real business.
 *
 * "ballet" is a French loanword used verbatim worldwide.
 * "epoxy" / "époxy" is a technical trade term used in every language.
 * "vinyl" / "spc" are used as-is in French, Vietnamese, and Thai flooring copy.
 * "spray foam" appears in English on most international insulation contractor sites;
 *   "mousse" and "polyurethane" cover French-only pages.
 * "climbing" / "bouldering" are used verbatim or nearly so in most markets.
 */
const LANGUAGE_AGNOSTIC_KEYWORDS: Record<string, string[]> = {
  'ballet lesson':          ['ballet'],
  'ballet lessons':         ['ballet'],
  'ballet school':          ['ballet'],
  'epoxy flooring':         ['epoxy', 'époxy', 'epoxid', 'epossid'],
  'epoxy floors':           ['epoxy', 'époxy', 'epoxid', 'epossid'],
  'spray foam insulation':  ['spray foam', 'mousse', 'polyurethane', 'polyuréthane', 'pu foam'],
  'vinyl flooring':         ['vinyl', 'spc', 'lvp'],
  'vinyl floors':           ['vinyl', 'spc', 'lvp'],
  'rock climbing gym':      ['climbing', 'bouldering', 'rock climb'],
  'rock climbing':          ['climbing', 'bouldering'],
};

/**
 * When a page matches one of these patterns we treat it as a wrong-category result
 * for that vertical, even if the required keyword is present. Used to catch
 * multi-sport institutional pages (university rec centres, community recreation
 * departments) that legitimately mention climbing/ballet/etc. as one of many
 * activities but are not dedicated providers.
 */
const VERTICAL_PAGE_DENY_PATTERNS: Record<string, RegExp> = {
  'rock climbing gym': /\brecreation services\b/i,
};

const REQUIRED_PAGE_KEYWORDS: Record<string, string[]> = {
  // --- Procedures / cosmetic ---
  'hifu': [
    'hifu', 'high-intensity focused ultrasound', 'high intensity focused ultrasound',
    'ultherapy', 'ultraformer', 'ultracel', 'sygmalift',
  ],
  'dermal filler': ['dermal filler', 'lip filler', 'injectable', 'filler'],
  'dental implant': ['dental implant', 'implant'],

  // --- Legal specialties (every firm is "law firm"; require the specialty) ---
  'property lawyer': ['real estate', 'real property', 'property law', 'conveyancing', 'real estate closing'],
  'property lawyers': ['real estate', 'real property', 'property law', 'conveyancing', 'real estate closing'],
  'real estate lawyer': ['real estate', 'real property', 'property law', 'conveyancing', 'real estate closing'],
  'personal injury lawyer': ['personal injury', 'injury claim', 'accident claim', 'injury lawyer', 'injury attorney'],
  'wills lawyer': ['wills', 'will writing', 'last will', 'estate planning', 'probate', 'testament'],
  'estate lawyer': ['estate planning', 'wills', 'probate', 'estate administration', 'inheritance'],
  'probate lawyer': ['probate', 'estate administration', 'wills', 'estate planning'],
  'bankruptcy lawyer': ['bankruptcy', 'insolvency', 'debt relief', 'chapter 7', 'chapter 11', 'chapter 13'],
  'bankruptcy lawyers': ['bankruptcy', 'insolvency', 'debt relief', 'chapter 7', 'chapter 11', 'chapter 13'],

  // --- Trades / home services (general contractors share the category) ---
  // epoxy: require "epoxy floor" or "epoxy coat" — not just "epoxy" which matches
  // "epoxy-look vinyl" and "epoxy finish" used by general flooring companies.
  'epoxy flooring': ['epoxy floor', 'epoxy coat', 'epoxy paint', 'epoxy screed', 'epoxy resin floor'],
  'epoxy floors': ['epoxy floor', 'epoxy coat', 'epoxy paint', 'epoxy screed', 'epoxy resin floor'],
  'spray foam insulation': ['spray foam'],
  'roofing company': ['roofing', 'roof repair', 're-roof', 'shingle', 'reroof'],
  'roof repair': ['roofing', 'roof repair', 're-roof', 'shingle', 'reroof'],
  'asphalt paving': ['asphalt', 'paving', 'tarmac', 'blacktop'],
  'asphalt paving contractor': ['asphalt', 'paving', 'tarmac', 'blacktop'],
  'stucco contractor': ['stucco', 'render', 'plastering', 'hardicoat'],
  'stucco contractors': ['stucco', 'render', 'plastering', 'hardicoat'],
  'mold removal': ['mold removal', 'mold remediation', 'mould removal', 'mould remediation'],
  'mold remediation': ['mold removal', 'mold remediation', 'mould removal', 'mould remediation'],
  'metal fabrication': ['metal fabrication', 'metal fab', 'welding', 'fabrication'],
  'window washer': ['window cleaning', 'window washing'],
  'window washers': ['window cleaning', 'window washing'],
  'dryer vent cleaning': ['dryer vent'],
  'basement renovation': ['basement renovation', 'basement remodel', 'basement finishing', 'basement suite', 'basement develop', 'basement convert', 'basement transform', 'basement living'],
  'basement renovations': ['basement renovation', 'basement remodel', 'basement finishing', 'basement suite', 'basement develop', 'basement convert', 'basement transform', 'basement living'],

  // --- Video / media (photographers and venues share wedding category) ---
  'wedding videographer': ['video', 'film', 'videograph', 'cinematograph', 'footage'],
  'wedding videographers': ['video', 'film', 'videograph', 'cinematograph', 'footage'],
  'videographer': ['video', 'film', 'videograph', 'cinematograph'],
  'videographers': ['video', 'film', 'videograph', 'cinematograph'],

  // --- Lessons / schools (compound: require the subject, not just the venue) ---
  // ballet: require "ballet" on the page — not just any dance studio.
  'ballet lessons': ['ballet'],
  'ballet lesson': ['ballet'],
  'ballet school': ['ballet'],
  'violin lesson': ['violin'],
  'violin lessons': ['violin'],
  'guitar lesson': ['guitar'],
  'guitar lessons': ['guitar'],
  'singing lesson': ['singing', 'vocal', 'voice lesson'],
  'singing lessons': ['singing', 'vocal', 'voice lesson'],
  'piano lesson': ['piano'],
  'piano lessons': ['piano'],
  'swimming lesson': ['swimming', 'swim lesson', 'swim class'],
  'swimming lessons': ['swimming', 'swim lesson', 'swim class'],
  'massage school': ['massage school', 'massage therapy school', 'massage course', 'massage training',
    'massage certification', 'massage academy', 'massage diploma', 'school of massage'],
  'math tutor': ['math', 'maths', 'mathematics'],
  'math tutors': ['math', 'maths', 'mathematics'],
  'kindergarten': ['kindergarten', 'preschool', 'early learning', 'early childhood'],

  // --- Professional services ---
  'environmental consulting agency': ['environmental consult', 'environmental assessment',
    'environmental impact', 'environmental management', 'contaminated land', 'environmental science'],
  'drug and alcohol rehab center': ['rehab', 'rehabilitation', 'addiction', 'detox',
    'substance abuse', 'recovery program', 'treatment center', 'treatment centre'],
  'life coach': ['life coach', 'coaching'],
  'dog trainer': ['dog train', 'dog obedience', 'puppy train', 'k9 train', 'canine train'],
  'dog trainers': ['dog train', 'dog obedience', 'puppy train', 'k9 train', 'canine train'],
  'recruitment agency': ['recruitment', 'staffing', 'recruiting', 'talent acquisition', 'headhunt'],
  'business insurance broker': ['business insurance', 'commercial insurance', 'insurance broker'],
  'translation service': ['translation', 'translator', 'interpreting'],
  'tax consultant': ['tax'],
  'hypnotherapy': ['hypnotherap', 'hypnosis'],
  'osteopath': ['osteopath', 'osteopathy'],
  'kinesiologist': ['kinesiolog'],
  'kinesiologists': ['kinesiolog'],
  'personal trainer': ['personal train', 'fitness train', 'strength coach'],
  'personal trainers': ['personal train', 'fitness train', 'strength coach'],

  // --- Home services (specific enough to warrant evidence) ---
  'home inspection': ['home inspection', 'property inspection', 'building inspection', 'house inspection'],
  'home inspector': ['home inspection', 'property inspection', 'building inspection', 'house inspection'],
  'home inspectors': ['home inspection', 'property inspection', 'building inspection', 'house inspection'],
  'home office furniture': ['office furniture', 'home office', 'desk', 'workstation'],

  // --- Creative / digital services ---
  'graphic designer': ['graphic design', 'branding', 'logo design', 'visual design', 'creative design'],
  'graphic designers': ['graphic design', 'branding', 'logo design', 'visual design', 'creative design'],
  'software developer': ['software', 'development', 'app development', 'web development', 'programming'],
  'software developers': ['software', 'development', 'app development', 'web development', 'programming'],
  'software company': ['software', 'development', 'technology', 'tech solutions', 'it solutions'],

  // --- Freight / logistics ---
  'freight forwarder': ['freight', 'forwarding', 'logistics', 'shipping', 'cargo', 'customs'],
  'freight forwarders': ['freight', 'forwarding', 'logistics', 'shipping', 'cargo', 'customs'],

  // --- Food / retail (cuisine and product specificity) ---
  'german restaurant': ['german', 'schnitzel', 'bratwurst', 'biergarten', 'spatzle'],
  'japanese restaurant': ['japanese', 'sushi', 'ramen', 'izakaya', 'teppanyaki'],
  'distillery': ['distillery', 'distilled', 'spirits', 'whisky', 'whiskey', 'gin', 'vodka', 'rum'],
  'watch store': ['watch'],
  'watch stores': ['watch'],
  'bike shop': ['bike', 'bicycle', 'cycling'],
  'motorcycle dealer': ['motorcycle', 'motorbike'],
  'tailor': ['tailor', 'tailoring', 'bespoke', 'alterations'],
  'rock climbing': ['climbing', 'bouldering'],
  'rock climbing gym': ['climbing', 'bouldering', 'rock climb'],
  'vinyl flooring': ['vinyl', 'lvp', 'spc', 'luxury vinyl', 'vinyle'],
  'vinyl floors': ['vinyl', 'lvp', 'spc', 'luxury vinyl', 'vinyle'],
  'commercial real estate agent':  ['commercial real estate', 'commercial property', 'commercial lease', 'commercial sales', 'commercial premises'],
  'commercial real estate agents': ['commercial real estate', 'commercial property', 'commercial lease', 'commercial sales', 'commercial premises'],
  'limousine service': ['limousine', 'limo'],

  // --- 5.2.1: verticals whose Google category label is too generic to decide on its own ---
  // (a "Law firm" may be corporate or personal injury; a "Massage therapist" may or may not do
  // reflexology; a "Spa" may or may not have a sauna). The business's own site must evidence it.
  'corporate lawyer': ['corporate', 'commercial law', 'business law', 'mergers', 'm&a', 'shareholder', 'incorporation'],
  'reflexology': ['reflexology', 'reflexologist', 'foot massage', 'foot reflex', 'zone therapy'],
  'chemical peel': ['chemical peel', 'skin peel', 'peels', 'glycolic', 'salicylic', 'tca peel'],
  'sauna': ['sauna', 'steam room', 'infrared', 'banya', 'thermal', 'bathhouse', 'bath house', 'hot spring', 'onsen', 'hammam', 'hydrotherapy', 'hot tub', 'cold plunge'],
};

function requiredKeywordsFor(vertical: string): string[] | undefined {
  return REQUIRED_PAGE_KEYWORDS[vertical.toLowerCase().trim()];
}

/**
 * Returns true when the page is readable AND none of the required keywords appear
 * in its visible text or the business name. Callers must pass HTML that was
 * actually read (not a blocked/empty sentinel) — this returns false ("do not
 * drop") for any empty input so unreadable pages are unaffected.
 */
export function missingRequiredKeyword(fullHtml: string, vertical: string, listingName = ''): boolean {
  const keywords = requiredKeywordsFor(vertical);
  if (!keywords || !fullHtml) return false;
  // A business that advertises the specialty in its own name (or GMB-derived name)
  // is a positive signal even when its site is JS-rendered and the static fetch
  // can't see the page copy — never drop those.
  const name = listingName.toLowerCase();
  if (keywords.some(kw => name.includes(kw))) return false;
  const text = visibleText(fullHtml).toLowerCase();

  const langGuardActive = process.env.KWR_GATE_LANG_GUARD !== 'off';
  const nonEnglish = langGuardActive && isProbablyNonEnglish(text);

  if (nonEnglish) {
    // For most verticals we trust GMB when the page is non-English — the English
    // keyword list cannot fairly judge a page in another language. But some terms
    // are genuinely universal: "ballet" is a French loanword used verbatim
    // worldwide; "epoxy" / "vinyl" / "spc" are trade terms copied as-is into
    // Vietnamese and French copy. For these, even a non-English page must contain
    // the term or its close cognate — an epoxy flooring site will always say
    // "epoxy" regardless of language.
    const agnosticKws = LANGUAGE_AGNOSTIC_KEYWORDS[vertical.toLowerCase().trim()];
    if (!agnosticKws) return false; // no agnostic gate → trust GMB
    if (agnosticKws.some(kw => name.includes(kw))) return false;
    return !agnosticKws.some(kw => text.includes(kw));
  }

  if (!keywords.some(kw => text.includes(kw))) return true;

  // Even when the required keyword is present, drop institutional/multi-sport pages
  // that only offer the service as one of many activities (e.g. university rec centres).
  const denyPattern = VERTICAL_PAGE_DENY_PATTERNS[vertical.toLowerCase().trim()];
  if (denyPattern && denyPattern.test(text)) return true;

  return false;
}

const FETCH_LARGE_BYTES = 1536 * 1024; // 1.5 MB, only used to re-check the evidence gate

/** Re-read a page with a much larger cap. Not cached; returns '' on any failure. */
async function fetchPageLarge(url: string): Promise<string> {
  if (isBlockedHost(url)) return '';
  try {
    const res = await fetchWithRetry(url, { method: 'GET', headers: { 'User-Agent': UA }, redirect: 'follow' }, SPAM_GET_TIMEOUT_MS);
    if (isBlockedHost(res.url || url) || !res.ok) return '';
    return await readCapped(res, FETCH_LARGE_BYTES, SPAM_GET_TIMEOUT_MS);
  } catch {
    return '';
  }
}

/**
 * Evidence-gate decision with a truncation guard. The normal fetch stops at 100 KB, and on large
 * sites (heavy scripts and styles first) the service wording often sits past that point, so a real
 * provider looked like it had no evidence (med spas with "chemical peel" at byte 200,000 were being
 * dropped). When the keyword is missing AND the page was cut off, read the page again with a larger
 * cap before dropping. If that re-read fails, the page is unreadable evidence, so the business is kept.
 */
export async function gateDrops(fullHtml: string, vertical: string, listingName: string, url: string,
                                readLarge: (u: string) => Promise<string> = fetchPageLarge): Promise<boolean> {
  if (!missingRequiredKeyword(fullHtml, vertical, listingName)) return false;
  if (Buffer.byteLength(fullHtml) < FETCH_MAX_BYTES * 0.9) return true;   // page was read in full
  const bigger = await readLarge(url);
  if (!bigger) return false;                                              // could not re-read: do not drop
  return missingRequiredKeyword(bigger, vertical, listingName);
}

function isSpam(snippet: string): boolean {
  const titleMatch = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(snippet);
  const metaMatch =
    /<meta[^>]*name=["']description["'][^>]*content=["']([^"']*)/i.exec(snippet) ??
    /<meta[^>]*content=["']([^"']*?)["'][^>]*name=["']description["']/i.exec(snippet);
  const headText = `${titleMatch?.[1] ?? ''} ${metaMatch?.[1] ?? ''}`;
  if (SPAM_KEYWORDS.test(headText) || PARKED_KEYWORDS.test(headText)) return true;
  // Also scan visible body text — hijacked/parked pages rarely flag themselves in the
  // title. Parked phrases are unambiguous (single hit); spam keywords need 3+ distinct
  // matches so a legit business mentioning e.g. "casino night events" isn't discarded.
  const bodyText = visibleText(snippet.slice(0, 40 * 1024));
  if (PARKED_KEYWORDS.test(bodyText)) return true;
  const spamHits = new Set((bodyText.match(new RegExp(SPAM_KEYWORDS.source, 'gi')) ?? []).map(m => m.toLowerCase()));
  return spamHits.size >= 3;
}

/** Verify a single URL: returns { verified, nullifyUrl, gmbTrust, finalUrl } */
async function verifyUrl(url: string, listingName: string, vertical: string): Promise<{ verified: boolean; nullifyUrl: boolean; gmbTrust: boolean; finalUrl: string; drop?: boolean }> {
  // 0. Strip tracking/UTM parameters — these create spurious redirect chains
  url = stripTrackingParams(url);

  // 1. Resolve shortened URLs to their final destination before any checks
  if (isUrlShortener(url)) {
    url = await resolveShortUrl(url);
  }

  // 2. Social media check (no network request needed)
  if (isSocialMedia(url)) {
    logDiscard('Social media', listingName);
    return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl: url };
  }

  // 2b. SSRF guard: never fetch a private/loopback/link-local host.
  if (isBlockedHost(url)) {
    logDiscard('Blocked host', listingName, url);
    return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl: url };
  }

  // 3. HEAD request with retry; fall back to GET when HEAD is rejected outright
  let headOk = false;
  let finalUrl = url;

  try {
    const response = await fetchWithRetry(url, {
      method: 'HEAD',
      redirect: 'follow',
      headers: { 'User-Agent': UA },
    }, VERIFY_TIMEOUT_MS);
    finalUrl = response.url || url;
    // If the URL redirected to a private/internal host, drop it (SSRF + hijack guard).
    if (isBlockedHost(finalUrl)) {
      logDiscard('Blocked host', listingName, `${url} → ${finalUrl}`);
      return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl };
    }
    headOk = response.status < 400 || response.status === 405 || response.status === 403;

    // Some JS-rendered / redirect-chain sites reject HEAD but accept GET — try GET fallback
    if (!headOk && (response.status === 405 || response.status === 404)) {
      try {
        const getResp = await fetchWithRetry(url, {
          method: 'GET',
          redirect: 'follow',
          headers: { 'User-Agent': UA },
        }, VERIFY_TIMEOUT_MS);
        finalUrl = getResp.url || url;
        headOk = getResp.status < 400;
        if (headOk) console.log(`  [verify] HEAD failed but GET succeeded for: ${url}`);
      } catch { /* ignore GET fallback error */ }
    }

    if (!headOk) {
      console.warn(`  [verify] ${url} → HTTP ${response.status}`);
      return { verified: false, nullifyUrl: false, gmbTrust: false, finalUrl };
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    // Hard failures mean the site is gone (DNS dead, nothing listening) — a dead
    // link must not ship in output. Timeouts/resets may just be a slow or
    // bot-hostile server, so those keep the GMB benefit of the doubt.
    const cause = (err as { cause?: { code?: string } })?.cause?.code ?? '';
    const isHardFailure = /ENOTFOUND|ECONNREFUSED|ERR_NAME_NOT_RESOLVED|CERT_HAS_EXPIRED|DEPTH_ZERO_SELF_SIGNED/i.test(cause + ' ' + message);
    if (isHardFailure) {
      console.warn(`  [verify] Site unreachable (${cause || message}) — dropping URL for: ${url}`);
      logDiscard('Dead website', listingName, url);
      return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl: url };
    }
    console.warn(`  [verify] ${url} → ${message}`);
    return { verified: false, nullifyUrl: false, gmbTrust: true, finalUrl: url };
  }

  // 3b. Off-domain redirect guard: an expired or hijacked domain often redirects to
  // an unrelated live site, which would otherwise pass every check below. A redirect
  // to a different registrable domain forfeits all GMB-trust shortcuts — the page
  // must positively pass the content checks to keep the URL.
  const origDomain = registrableDomain(url);
  const offDomain = origDomain !== null && registrableDomain(finalUrl) !== null && registrableDomain(finalUrl) !== origDomain;
  if (offDomain) {
    console.warn(`  [verify] Off-domain redirect: ${origDomain} → ${registrableDomain(finalUrl)} for "${listingName}"`);
  }

  // 4. Spam/gambling GET check + thin-content check (use finalUrl after redirects)
  const fullHtml = await fetchPageSnippet(finalUrl);
  if (fullHtml && isSpam(fullHtml.slice(0, 4096))) {
    logDiscard('Spam content', listingName);
    return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl };
  }

  if (fullHtml === BLOCKED_SENTINEL) {
    if (offDomain) {
      console.warn(`  [verify] Off-domain redirect target blocks access — dropping URL for: ${listingName}`);
      logDiscard('Off-domain redirect', listingName, `${url} → ${finalUrl}`);
      return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl };
    }
    console.log(`  [network] Site blocks automated access but HEAD passed — trusting GMB listing for: ${finalUrl}`);
    return { verified: false, nullifyUrl: false, gmbTrust: true, finalUrl };
  }

  if (!fullHtml && offDomain) {
    // Couldn't read the redirect target at all — can't prove it's the same business
    console.warn(`  [verify] Off-domain redirect target unreadable — dropping URL for: ${listingName}`);
    logDiscard('Off-domain redirect', listingName, `${url} → ${finalUrl}`);
    return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl };
  }

  if (fullHtml) {
    // A bot-challenge page (Cloudflare etc.) returns 200 with minimal JS — HEAD
    // passed so the real site is up; trust GMB rather than discard.
    if (!offDomain && isBotChallengePage(fullHtml)) {
      console.log(`  [network] Bot challenge page detected — trusting GMB listing for: ${finalUrl}`);
      return { verified: false, nullifyUrl: false, gmbTrust: true, finalUrl };
    }

    const linkCount = countInternalLinks(fullHtml, finalUrl);
    if (linkCount < THIN_LINK_THRESHOLD) {
      // WordPress: large <head> sections push nav links beyond the 100 KB cap.
      // JS builders (Wix, Squarespace, Webflow): data-href already counted above,
      // but detect as a safety net in case the HTML structure is unusual.
      // In both cases the HEAD check passed, so the site is real — trust GMB.
      // An off-domain redirect forfeits these shortcuts: the page must stand on
      // its own, since "real site" no longer implies "this business's site".
      if (!offDomain && (isWordPressSite(fullHtml) || isJsBuilderSite(fullHtml))) {
        // Even on WordPress/JS-builder sites the <title> and visible headings are
        // in the static HTML. That's enough to verify required-keyword verticals —
        // a real ballet school will always have "ballet" in its title even on Wix.
        if (await gateDrops(fullHtml, vertical, listingName, finalUrl)) {
          console.warn(`  [verify] "${vertical}" signal not found on page — dropping: ${listingName}`);
          logDiscard('Wrong category', listingName, `${vertical} not evidenced on site`);
          return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl, drop: true };
        }
        console.log(`  [network] Known platform detected (${isWordPressSite(fullHtml) ? 'WordPress' : 'JS builder'}) — trusting GMB for: ${finalUrl}`);
        return { verified: false, nullifyUrl: false, gmbTrust: true, finalUrl };
      }
      if (!offDomain && isSimpleLegitSite(fullHtml)) {
        if (await gateDrops(fullHtml, vertical, listingName, finalUrl)) {
          console.warn(`  [verify] "${vertical}" signal not found on page — dropping: ${listingName}`);
          logDiscard('Wrong category', listingName, `${vertical} not evidenced on site`);
          return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl, drop: true };
        }
        console.log(`  [network] Simple legitimate site detected — trusting GMB for: ${finalUrl}`);
        return { verified: false, nullifyUrl: false, gmbTrust: true, finalUrl };
      }
      console.warn(`  [verify] Thin content (${linkCount} internal links): ${finalUrl}`);
      logDiscard(offDomain ? 'Off-domain redirect' : 'Thin content', listingName);
      return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl };
    }

    // Treatment gate (conservative): only fires on a fully readable page that
    // passed spam + thin-content checks. If the named procedure never appears,
    // this business does not offer it — drop it entirely. Unreadable pages never
    // reach here (handled by the GMB-trust shortcuts above), so legitimate
    // providers on bot-blocked / JS-rendered sites are never penalised.
    if (await gateDrops(fullHtml, vertical, listingName, finalUrl)) {
      console.warn(`  [verify] "${vertical}" signal not found on page — dropping: ${listingName}`);
      logDiscard('Wrong category', listingName, `${vertical} not evidenced on site`);
      return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl, drop: true };
    }
  }

  return { verified: true, nullifyUrl: false, gmbTrust: false, finalUrl };
}

/** Verify all website URLs in parallel, discarding social/spam URLs entirely */
export async function verifyWebsites(
  listings: EnrichedListing[],
  vertical: string
): Promise<EnrichedListing[]> {
  const results = await Promise.all(
    listings.map(async (listing) => {
      if (!listing.websiteUrl) {
        return { ...listing, websiteVerified: false };
      }

      const { verified, nullifyUrl, gmbTrust, finalUrl, drop } = await verifyUrl(listing.websiteUrl, listing.name, vertical);

      // Treatment gate fired: the page is real but does not offer the named
      // procedure — remove the listing from results entirely.
      if (drop) return null;

      if (verified) {
        console.log(`  [verify] ✓ ${listing.name}: ${finalUrl}`);
      } else if (gmbTrust) {
        console.log(`  [network] URL check failed but trusting GMB listing for: ${finalUrl}`);
      } else if (!nullifyUrl) {
        console.log(`  [verify] ✗ ${listing.name}: ${finalUrl}`);
      }

      return {
        ...listing,
        websiteUrl: nullifyUrl ? null : finalUrl,
        websiteVerified: verified || gmbTrust,
      };
    })
  );

  return results.filter((l): l is EnrichedListing => l !== null);
}

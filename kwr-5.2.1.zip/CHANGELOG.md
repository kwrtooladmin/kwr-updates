# KWR Selector - Changelog

## Version 5.2.1 - Wrong-country and wrong-business fixes (November 2026)

Fixes two problems the KWR team reported: businesses from the wrong country (for
example the Philippines appearing for a Canadian site) and businesses that do not
offer the service that was searched.

### Also in 5.2.1
- Photographers listed on Maps as "Photography studio" or "Photography service" are no longer dropped as the wrong category: the category fallback now matches the root of agent words (photographer / photography, videographer / videography).
- Added category entries for voice lesson, waxing, brunch, videographer, steakhouse, cupcake, boiler repair, chimney sweep, junk removal, mole removal and serviced apartment, based on the real Google Maps labels these searches returned (found from the team diagnostic reports).
- The Results Checker now reads German, French, Spanish, Italian and Portuguese pages for about 25 common services (handyman, photographer, plumber, electrician and more), so Zurich-style searches no longer end with an empty Verified file. German epoxy pages ("Epoxidharz") are no longer dropped by the epoxy check.
- Searches for verticals without a hand-written category entry no longer come back empty: the fallback now tolerates compound spelling (bookstore / book store), plural forms, doughnut / donut and shop vs store, and a lone word like "shop" no longer admits unrelated businesses. Added entries for manicure, pedicure, nail salon, pasta, windshield replacement, ear wax removal and dietitian.

- Sauna: real bathhouses and hot-spring venues are no longer rejected by the evidence check.
- Country guard: a pin within about 1 degree of the site's own country is never treated as
  "wrong country" (11 real Singapore firms were being dropped).
- New "Report a problem" button: saves one small file to the Desktop (results of the chosen
  search, discard log, versions; never any password) to send to the maintainer.
- Security: the web page now listens on this computer only and rejects requests addressed
  elsewhere; searches run without a shell so search text can never run as a command; error
  pages no longer show file paths; vulnerable packages updated.
- Updates are now signed. The tool only installs an update signed by the maintainer's key and
  downloaded from the official update repository.
- New one-click Windows installer (KWR-Setup): progress window, retries, up-front checks, and
  a patched Node.js (22.23.5) when the installed one is out of date.
- The daily email report is retired. The tool no longer registers a scheduled task, and removes the
  old "KWR Daily Email Report" task if an earlier version created it.
- Setup tidies up older copies of KWR: it copies their results, baseline and history into the new
  install, retires their launchers and shortcuts, and leaves a note. Nothing is deleted.
- New Details window on each search: summary tiles (checked, kept, dropped, needs a look), the reasons
  businesses were dropped in plain language, and a filterable list of every business with its reason.
- Evidence gate: real providers were being dropped when their service wording sat past the first
  100 KB of a large page (for example med spas listing chemical peels deep in the page). The gate now
  re-reads a cut-off page with a larger limit before dropping, and keeps the business if it cannot re-read.

### Fixed: businesses from the wrong country

A bare city name such as "Halifax", "Hamilton" or "Perth" can mean several places,
and Google Maps decided which one using the location of the computer running the
tool. From the Philippines, "Halifax" resolved to Manila, so the tool collected
Philippine businesses for a Canadian site. Two things made it worse: the tool only
corrected the city when Google's answer was obviously wrong in a certain way, and it
assumed every `.com` site was in the United States.

The tool now knows which country each publication site covers (`src/siteMarkets.ts`)
and always searches for the city together with that country, for example
"Halifax, Canada". Before it scrapes anything it also checks that the resolved
location is actually inside that country, and stops with a clear message instead of
collecting businesses from the wrong country. As a second safety net, any individual
business whose own map pin is clearly in a different country (for example Halifax,
England for the Canadian Halifax site, which passes the address-text match because it
also says "Halifax") is now rejected and recorded in the discards log as "Geo mismatch".
Pins that fall in no known country, such as open ocean, are kept, because Google
sometimes places a pin oddly for a business with no street address. In a review of
1,821 past results this caught 2 genuine wrong-country businesses and wrongly dropped
1 real one whose Google pin was misplaced; a dropped business is replaced by the next
candidate, whereas a wrong-country business would reach the team.
A site that is not in the list and is
not on a country-specific domain gets a warning instead of a guess. To add a new site,
add one line to `src/siteMarkets.ts`. Typing the city with its country (for example
"Halifax, Canada") still works and is always respected.

### Fixed: businesses that do not offer the service (introduced in 5.2.0)

Several of the verticals added in 5.2.0 matched on generic words and let in the wrong
kind of business: a driving school for Private School, a dental clinic for Eye Clinic,
a Thai massage parlour or an Asian grocery store for Restaurant, a personal injury
attorney for Corporate Lawyer. These entries now require labels that are specific to
the service. Affected verticals: Restaurant, Landscaping, Private School, Eye Clinic,
Orthopaedic Specialist, ENT Specialist, Wisdom Tooth Removal, Printing Service,
Dumpster Rental, Welding, Corporate Lawyer, Foundation Repair, Reflexology, Couple
Spa, Sauna, Chemical Peel, Wallpaper Installation, Eyewear. Web Hosting had the same
problem from before 5.2.0 (its category list contained the bare word "it", which
matches any category containing those two letters) and is fixed too.

Corporate Lawyer, Reflexology, Chemical Peel and Sauna now also check the business's
own website for the service, because Google's category label for these is often too
generic to decide on its own.

Expect these verticals to return fewer results than 5.2.0 did. The extra results were
the wrong businesses.

### Known follow-up (not in this release)

Some category lists from earlier versions also use very short words that can match
unrelated categories by accident (for example "ent" for Rhinoplasty, "men" for
Barbershop, "cat" for Pet Grooming). They have not been changed in this release
because they have working history; they are queued for a separate, tested clean-up.
Mosquito Control and Web Hosting still return some generic pest control or web design
businesses in markets where Google's own labels blur them.

---

## Version 5.2.0 - Results Checker + accuracy fixes (July 2026)

Adds an automatic results checker to every search, fixes 33 verticals that were
returning blank or unreliable results, and fixes a language-detection bug.

### Results Checker (new)

Every search now automatically sorts its output into two files, no setup and
no extra step required:

- **`...-Verified.csv`** - the service was confirmed on the business's own
  website; ready to use.
- **`...-For-Review.csv`** - could not be confirmed (site down, unsupported
  language, thin page); take a quick look before using.

This runs for free after every search (terminal or Web UI) by reading each
website and checking it actually evidences the searched service. Nothing to
configure; set the environment variable `KWR_SKIP_CHECK=1` to skip it if you
ever want the old, faster behavior. You can also run it manually on an
existing output file with `npm run check-results -- --input <file>`.

### Fixed: 18 verticals that returned blank or thin lists

Google Maps often does not label a business with the exact word you searched
(a restaurant is labelled by its cuisine, not "Restaurant"; a landscaper is
labelled "Landscaper", not "Landscaping"). These verticals previously came
back empty and now return real results:

Restaurant, Landscaping, Orthopaedic Specialist, Eye Clinic, Wisdom Tooth
Removal, Printing Service, ENT Specialist, Dumpster Rental, Welding, Private
School, Corporate Lawyer, Foundation Repair, Reflexology, Couple Spa, Chemical
Peel, Wallpaper Installation, Eyewear, Sauna.

### Fixed: 15 verticals with unreliable verification

The following verticals were being checked too loosely, sometimes confirming
the wrong type of business: Mosquito Control, Web Hosting, Dog Daycare, Cat
Grooming, Janitorial, Courier, Wedding Caterer, Bed Bug Exterminator, SEO,
Structural Engineer, Window Tinting, Furniture Mover, Gynaecologist,
Photography Studio, Prenatal Massage.

### Fixed: French-language pages misread as Vietnamese

The Results Checker's language detector could mistake a French business page
for Vietnamese (both use accented letters like a-circumflex and e-circumflex),
which could produce a false "wrong business" result instead of safely
flagging the page for review. Vietnamese detection now requires letters that
do not occur in French, so French pages are correctly set aside for review
instead of being misjudged.

### Known follow-up (not in this release)

Three verticals - Mosquito Control, Web Hosting, and Reflexology - still
return some incorrect matches in markets where Google Maps' own category
labels blur adjacent business types (e.g. general pest control vs.
mosquito-specific). Flagged for a future release rather than left silent.

---

## Version 5.1.2 - Mac compatibility patch (June 2026)

Fixes Mac-specific issues that prevented the UI and daily email report from working on macOS.

### Mac email scheduler

The daily email report was Windows-only. On Mac, the scheduler registration was silently skipped and no report was ever sent. The scheduler now registers a crontab entry (`0 7 * * *`) on first UI launch, mirroring the Windows Task Scheduler behavior. Output is logged to `/tmp/kwr-email.log` for easy debugging. No manual setup required.

### Mac UI fixes

- **Express crash on Node 24:** The UI server failed to start on Node 24 due to a breaking change in Express 5's body-parser dependency. Downgraded to Express 4.21 which is stable across Node 18-22 LTS. Node engine requirement updated to reflect that Node 24 is not yet supported (`>=18.0.0 <25.0.0`). Mac users should use Node 22 LTS.
- **Shell quoting for searches:** Multi-word verticals and city names with spaces were mishandled on Mac due to Windows-style shell quoting. Mac now uses single-quote escaping (bash convention) so searches run correctly on both platforms.
- **Update banner hidden on Mac:** The "Update now" button was visible on Mac but would fail because the auto-updater uses Windows-only tools (robocopy). The button is now suppressed on Mac. New version availability is still reported in the console.

### Upgrading

**Windows users:** Auto-update will apply this patch automatically.

**Mac users:** Delete `node_modules` and `package-lock.json`, then run `npm install` followed by `npm run ui`. The email scheduler registers on first launch.

---

## Version 5.1.1 - Accuracy and reliability (June 2026)

The first full improvement release after V5 (it supersedes an early 5.1.0 build). Driven by independent verification of two standardized 100-vertical test panels, measured on work the tool had not been tuned to. Combined Verified Accuracy rose from 65.3% to 74.5%, and wrong-business results were cut 40%.

### Website-evidence gate (the headline change)

Some verticals name a service that many business types share, so the Google Maps category cannot tell who actually offers it (a procedure like HIFU; a legal specialty like property law). The verifier now reads the business's own website and keeps it only when the searched service is actually evidenced there. This replaces endless per-business blocklists with a positive check that works in any city.

Covered verticals include:

- **Procedures:** HIFU and related.
- **Legal specialties:** personal injury, wills, estate, probate, real estate, bankruptcy.
- **Trades:** epoxy flooring, spray foam insulation, roofing, asphalt paving, stucco, mold removal, metal fabrication, dryer vent and window cleaning, basement renovation.
- **Lessons and schools:** ballet, violin, massage school, math tutor, kindergarten. Compound verticals require the qualifier, not just the subject (a "massage school" must evidence training, so spas are dropped).
- **Professional services:** environmental consulting, drug and alcohol rehab, recruitment, business insurance, translation, hypnotherapy, osteopath, kinesiologist, personal trainer, life coach.
- **Food and retail:** german and japanese restaurants (cuisine specific), distillery, watch store, bike shop, motorcycle dealer, tailor, rock climbing, limousine.

The gate is conservative: it only drops a business when its page is readable and the service is genuinely absent. Bot-blocked or JS-rendered sites keep the benefit of the doubt, and a match in the business name or Google listing is also accepted. Adding a new vertical is a one-line entry, no code change.

### Geocoder reliability

Valid cities such as "Liverpool" and "Columbus" sometimes resolved to a world-level view in the wrong country, which both aborted the run and could pull in wrong-region results. The geocoder now reads the most specific reading as the map settles and, when a city still comes back country-level, automatically retries with the site's country appended (for example "Liverpool, UK"). Valid cities no longer need to be typed with a country by hand.

### Category and name filter tuning

Name and category exclusions added so these stop appearing in results:

- **Property and probate lawyer:** personal-injury, estate-planning, wills, civil-litigation, conveyancing and trial firms
- **Violin / Guitar Lesson:** music/instrument stores, voice/piano studios, luthiers, performer-only acts
- **Mold Inspection:** remediation, water-damage and restoration firms (they do the work but are not inspectors)
- **Thyroid Specialist:** hospital-system listings (health systems, urgent care, family practice)
- **Deep Cleaning:** carpet/upholstery-only and commercial/office-only cleaners
- **Yoga Studios:** meditation/mindfulness-only studios
- **Singing Lesson:** speech/drama coaching, instrument-only schools
- **Cremation:** pet cremation and will-writing/funeral-plan services
- **Furnace Repair:** AC-only contractors
- **Barbershops:** plural and spacing variants now map to the barber category (the plural form previously dropped all results)

### Fix: name exclusions were being bypassed for mapped verticals

Vertical exclusions placed in the category-exclusion list were skipped whenever a business's Google Maps category matched the vertical's inclusion list (e.g. a med spa under HIFU). Business-name exclusions are now evaluated before the category-inclusion shortcut, so they apply regardless of category match.

### Known follow-ups (not in this release)

- A small residual of "right business type, wrong location" results (a global firm that Google pins in local results) is left to human review, since an automatic filter there risks dropping legitimate local businesses.
- Verticals that barely exist in a market (e.g. basement renovation in Singapore) should be flagged rather than forced.
- Selector drift: Google changed the review-count selector; refresh the selectors and confirm review counts are captured.

---

## Version 5.0.0 - V5 (June 2026)

The V5 release - everything since V4 in one update, plus a new self-update system. This is the **last manual install**: from here on, updates are delivered automatically and applied with one click. V5 also incorporates a full independent code audit (correctness + security fixes below).

### Correctness & security (from the V5 code audit)

- **Geographic filtering now actually works.** The city filter previously passed every listing, so the `--radius` distance check never ran and out-of-city businesses could ship. The coordinate-based radius check is now the real gate.
- **Non-Latin markets no longer gutted.** Business names in Thai, Vietnamese, Chinese, etc. were being stripped to nothing, grouped together, and discarded as a fake "franchise." Names of every script are now preserved, so Bangkok/Hanoi/HCMC runs keep their real businesses.
- **Freely-typed verticals work.** A vertical not in the built-in map (e.g. "italian restaurant") was reproducibly failing because global exclusions ran anyway. A direct term match now runs first.
- **Broken-layout runs fail loudly.** If Google changes its page layout, the run now reports FAIL and logs it (reaching the daily email) instead of silently looking like a successful empty run.
- **Spreadsheet formula injection blocked.** A malicious business name like `=cmd|...` can no longer execute when the CSV/Excel output is opened.
- **Network safety.** The verifier can no longer hang or run out of memory on a hostile page (reads are size- and time-capped), won't fetch internal/private addresses (SSRF guard), and the local web UI rejects cross-site commands.
- **Reliability.** Browser processes always close after an error (no orphaned Chrome), mid-scrape CAPTCHAs are detected, listings with quotes in their name are no longer skipped, concurrent batches are rejected, and the daily email parses cities containing commas correctly.

### Automatic updates (new)

- On launch the tool checks for a newer version and shows an **"Update now"** banner when one exists. One click downloads the update, verifies its checksum, backs up the current install, swaps in the new files, and restarts - your `.env`, results, and history are preserved. If anything fails mid-update, it rolls back automatically to the previous version.
- Updates never run during an active scrape, never overwrite your settings, and skip reinstalling dependencies when they haven't changed (so most updates apply in seconds).

### QA / reporting isolation (new)

- A machine carrying a `.qa-mode` marker file never sends the daily email report, keeping a tester's runs out of the real reporting. The marker is excluded from published builds, so distributed copies always report normally.

### Website verification hardening (all verticals)

- **Dead sites no longer count as verified.** A site whose domain no longer resolves or refuses connections is dropped (`Dead website` in the discard log) instead of being trusted on the strength of its Google Maps listing. Timeouts still get the benefit of the doubt, since a slow site is not a dead one.
- **Hijacked-domain protection.** If a business URL redirects to a *different* domain (common when a domain expires and is bought by spammers), the destination must positively pass content checks - all trust shortcuts are forfeited. Failures are dropped as `Off-domain redirect`.
- **Parked-domain and broader spam detection.** The spam check now catches "domain for sale" / expired-domain parking pages (HugeDomains, Sedo, GoDaddy auctions) and scans visible page text, not just the title. Legitimate businesses mentioning e.g. "casino night events" are unaffected - body-text spam requires 3+ distinct keyword hits.

### Vertical filter tuning (from verifier mismatch data)

Name exclusions added so these no longer appear in results:

- **Deck Builder:** handyman/home-maintenance outfits, marine construction, docks, seawalls, enclosures/pergolas
- **Magician:** food businesses ("Magic Waffle"), photo booth / magic mirror hire, princess-party character entertainment
- **Property Lawyer:** elder law, personal injury, family law, criminal, divorce, DWI, accident firms, online wills platforms
- **Probate Lawyer:** conveyancing, business/corporate law, litigation, personal injury, criminal, immigration firms
- **Wedding Planners:** palazzo/palace/villa venues (venues are not planners)
- **Violin/Guitar Lesson:** performers (quartets, orchestras, symphonies), luthiers, school-of-rock-style band programs

---

## Version 5.0 foundation - Web UI & reporting (June 2026)

These capabilities are part of the V5.0.0 release above. They introduced the full web UI and reporting infrastructure, making the tool accessible to non-technical users and giving the admin team daily visibility into run results without manual checking.

---

### Web UI

The tool now has a browser-based interface. Non-technical users can run searches, watch live progress, download results, and view run history - all without opening a terminal.

- Double-click **`Launch KWR.vbs`** to start. The browser opens automatically.
- Fill in Site, City, and Vertical for each search. Queue multiple runs and start them all at once.
- Live Log tab streams real-time output as the tool works.
- Results tab shows a card for each completed run with its status badge (Pass, Partial, Thin Market, Fail, Stopped), verified result count, top discard reason, and download buttons for CSV and discard log.
- Run History is saved locally and persists between sessions.
- Shut Down button closes the server cleanly when done.

---

### Daily email report

A scheduled task runs silently at 7AM every day and emails a summary of the previous day's runs to the admin. The email includes pass rate, week-over-week comparison, a per-run breakdown, and four CSV attachments (baseline report, summary, discards, and verified results).

- If the machine was off at 7AM, the report sends automatically on next login.
- No action required from the user - the task is registered on first launch.

---

### Run result summary line

At the end of every run, the tool prints a plain-English result line in the live log:

- Green for Pass: `[RESULT] PASS - 7 verified results. Ready to use.`
- Amber for Partial/Thin Market: `[RESULT] PARTIAL - Only 3 verified results found. Top discard reason: Wrong category (12). Check the category filter for this vertical.`
- Red for Fail: `[RESULT] FAIL - No verified results found. Top discard reason: No website (8). Most businesses in this vertical may not have a website.`

---

### Category filter - medical and cosmetic verticals

30+ new medical and cosmetic verticals added with precision category rules:

- Allied health: chiropractor, acupuncture, optometrist, audiologist, podiatrist, orthopedic surgeon
- General medicine: GP / family doctor, pediatrician, cardiologist, neurologist, dermatologist, endocrinologist, urologist, psychiatrist, psychologist
- Cosmetic and plastic surgery: plastic surgeon, liposuction, rhinoplasty, breast augmentation, tummy tuck, facelift, blepharoplasty, CoolSculpting, ultherapy, thread lift

Each vertical has exclusion rules to prevent dental, veterinary, and unrelated medical clinics from slipping through.

---

### Bug fixes

**Multi-word vertical truncation** - vertical names containing a space (e.g. "General Practitioner", "Personal Injury Lawyer") were being truncated to the first word only due to a Windows shell quoting issue. Fixed - all multi-word verticals now pass through correctly.

**Batch stops after 2 runs** - related to the multi-word truncation bug. A malformed argument on the 3rd run caused the process to exit immediately, breaking the batch loop. Fixed alongside the quoting fix.

---

### Upgrading from V4

1. Replace your existing project folder with the new V5 folder.
2. Open PowerShell in the new folder and run: `npm install`
3. Run the browser installer again: `npx playwright install chromium`
4. Your existing `.env` settings carry over - no changes needed.

---

## Version 4.0 - June 2026

This update closes all remaining failures identified in the V3 independent review conducted by Madelline Ann. If you are upgrading from V3 or V3.1, this version addresses the specific businesses that were previously missing or returning blank fields.

---

### What was fixed

**Businesses with active websites being silently discarded (WordPress and Wix)**
4 businesses with real websites were not appearing in results at all. The root cause was two distinct issues. WordPress sites have very large page headers that exceed the tool's content fetch limit, so navigation links in the page body were never reached and the site was incorrectly flagged as empty. Wix sites store navigation links in a non-standard attribute called data-href instead of the standard href - the tool was not scanning this and counting zero links. Both are now detected and handled correctly. Genuinely empty or spam sites are unaffected.

Affected businesses now confirmed working: Dals (Manchester), NTIS UK (Manchester), Sworn Translator Edyta (Manchester), Appliance Technician (Ottawa).

**Businesses with no website returning blank fields**
When a business had no website the tool was leaving the website field completely blank. The content team had no link to reference at all. The tool now checks the Google Maps listing for a social media URL or Google Maps link and outputs that instead, so the content team always has something to work with. A Website Status column and Reference URL column have been added to the CSV output.

Affected businesses now confirmed working: Latin Dance Edinburgh (Instagram URL output), Saigon Memoire Edinburgh (Google Maps URL output).

**Business skipped due to name mismatch between Google Maps and website**
One business was being skipped because its name on Google Maps did not match the name displayed on its website. The tool was relying on name string matching to confirm a business - when the names differed it skipped the business entirely. The tool now checks whether the website is real and working by looking for a real page title, meta description, and contact information. If all three are present the business passes regardless of name difference.

Affected business now confirmed working: Maths Vella Bonello Private Lessons (Malta).

**Vietnam and Thailand language support**
Flagged as the next major challenge in the V3 review. Confirmed already working through prior testing across multiple Vietnam and Thailand verticals. No additional fix was required.

---

### New CSV columns

Two new columns have been added to the output spreadsheet:

| Column | Values | What it means |
|--------|--------|---------------|
| `Website Status` | verified, unverified, social_only, maps_only, none | Where the link in Reference URL came from |
| `Reference URL` | URL | Best available link - website first, then social media, then Google Maps |

---

### Web UI

A browser-based interface has been added so non-technical users can run the tool without touching the terminal.

- Double-click **`Launch KWR.vbs`** (Windows) or **`Launch KWR (Mac).command`** (Mac) to start
- Fill in Site, City, and Vertical - type freely or pick from the dropdown suggestions
- Queue multiple searches and run them all in sequence with a 5-minute cooldown between each
- Live log streams real-time output from the tool as it runs
- Results appear as cards with **↓ CSV** and **↓ Excel** download buttons when each run completes
- Run history is saved locally and persists between sessions
- Filter history by vertical or city
- Dark and light mode toggle - preference remembered between sessions
- Sound notification when a batch completes - mute toggle available

---

### Category filter improvements

Two verticals that previously returned zero results have been fixed:

**Vietnamese Restaurant** - Google Maps displays Vietnamese dong price ranges (`· ₫100-200K`) instead of a category label for restaurants in Vietnam. The `₫` symbol was not recognised as a price range indicator, causing all listings to be discarded as wrong category. Fixed. The `₫` symbol (and several other regional currency symbols) is now handled correctly.

**Furnace Repair** - Google Maps categorises all furnace and heating businesses as `HVAC contractor`, not `Furnace Repair`. The tool's direct-term match found no category match and discarded every result. Fixed by adding `furnace repair` to the category map with HVAC-related keywords.

---

### Baseline reporting

Every run now automatically appends a row to `baseline/baseline-report.csv` with the date, version, site, city, vertical, result count, pass/fail classification, and top discard reason. A summary file (`baseline/baseline-summary.csv`) is rebuilt after every run showing pass rates per vertical over time. This requires no action from the team - logging happens automatically in the background.

---

### Upgrading from V3 or V3.1

If you already have V3 or V3.1 installed, you do not need to reinstall Node.js or set up your settings file again. To upgrade:

1. Replace your existing project folder with the new V4 folder.
2. Open PowerShell in the new folder and run: `npm install`
3. Run the browser installer again: `npx playwright install chromium`
4. Your existing `.env` settings carry over - no changes needed.

---

## Version 3.1 - May 2026

This update focuses on improving result accuracy and removing false positives that were
causing legitimate businesses to be missed and wrong businesses to appear in results.

---

### What was fixed

**Wrong businesses appearing in results**
The tool now checks the business type of every result against what was searched. Before
this fix, searches were returning completely unrelated businesses - a security company
search returned a crypto hardware wallet seller, a mattress search returned hostels, and
naturopath searches returned dental clinics. The tool now reads the Google Maps business
category label and removes anything that does not match the vertical being searched.

**Legitimate businesses being wrongly removed**
Some real business websites block automated access as a security measure. The tool was
treating these blocked pages as empty sites and discarding the business. A well-known
Vietnamese law firm was being removed for this reason. Fixed - the tool now recognises
when a site is blocking automated access and keeps the business using the Google listing
as confirmation instead.

**Wrong business type slipping through by name**
Businesses were passing the category filter even when their name made it obvious they
were the wrong type. Fixed - the filter now checks the business name as well as the
Google Maps category label.

**Category scraper reading wrong text**
The tool was sometimes reading the star rating or review count off a business card
instead of the actual business type. Fixed - it now correctly identifies the business
type before deciding whether to include it.

**False broken selector warning every run**
Every run was logging a warning saying two parts of the tool were broken. They were never
actually broken - the tool was checking for them before the page they belong to had even
loaded. Fixed - the false warning is gone.

**Moving company searches returning wrong businesses**
Searches for movers were returning self-storage facilities, tourist bus operators, and
tour companies. Fixed - storage facilities, tour operators, and bus companies are now
excluded from mover searches. Legitimate movers including businesses listed as moving
and storage services are allowed through.

---


---

### Known behaviour to be aware of

**Filter tier not shown in output**
The CSV output labels all results as either `primary` (top 5) or `backup` (next 3).
However not all primary listings meet the top-tier quality threshold. When a search
returns fewer high-quality results than needed, the tool automatically accepts lower-rated
businesses to fill the list. A primary listing could therefore come from one of three
quality levels:

| Quality Level | Rating | Reviews | What it means |
|---------------|--------|---------|---------------|
| Top rated | ≥4.5 stars | ≥100 reviews | Best available - highest confidence |
| Good rated | ≥4.0 stars | ≥30 reviews | Solid but fewer reviews - check before publishing |
| Best available | Any | Any | Thin market - limited options, manual review recommended |

**How to check:** The Rating and Review Count columns are always included in the CSV.
Check these columns before publishing - if a primary listing has a rating below 4.5 or
fewer than 100 reviews, it came from the fallback tier and should be reviewed carefully.

This will be addressed in a future version by adding a Quality Level column to the output
so the tier is visible at a glance.

### Known limitations

- **Painting Service** - this vertical name is too broad. Google Maps returns art
  galleries, pottery studios, and nail bars instead of trade painters. A more specific
  vertical name such as "House Painter" or "Exterior Painting Contractor" is recommended.

- **Home Inspection in Vietnam** - home inspection does not exist as a formal
  professional service in Vietnam. Searches return zero results. This vertical is not
  suitable for the Vietnamese market.

- **Shortened links on Google listings** - shortened URLs such as bit.ly are now automatically resolved to the real website address before verification. This was fixed in V3.1.

- **Niche verticals** - for highly specialised verticals such as medical sub-specialties
  or specific legal niches, Google Maps may return related but not identical business
  types. A manual review of results is recommended for these verticals.

- **Thin markets** - in cities or markets where very few businesses exist for a given
  vertical, the tool may return only one or two results or none at all. This is expected
  behaviour and reflects the reality of the market.

---

### Tested markets in this version

Batch testing completed across Vietnam (Hanoi, Ho Chi Minh), Thailand (Bangkok),
Australia (Sydney, Melbourne, Brisbane, Canberra), UK (Edinburgh, Liverpool),
Canada (Montreal, Halifax, Toronto), USA (Phoenix, Dallas), Hong Kong, Winnipeg,
Malta, and El Paso / Philadelphia (on hold pending site confirmation).

---

### How to run

```
npm run dev -- --site YOURSITE.com --city "Your City" --vertical "business type"
```

See README.md for full setup and usage instructions.

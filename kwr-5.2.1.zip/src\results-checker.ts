/**
 * results-checker.ts
 *
 * User-facing results checker. Free — no API, no LLM, runs locally.
 *
 * Takes a KWR tool output CSV and sorts every business into two files:
 *   <name>-Verified.csv    — service confirmed on the website; ready to use
 *   <name>-For-Review.csv  — could not confirm; a person should take a look
 *
 * It visits each business's website, reads the page (and a service/about page
 * if the homepage is thin), and checks that the searched service is actually
 * there. It never makes the final call — it just removes the obvious ones from
 * the person's plate so they only review the uncertain few.
 *
 * Usage:
 *   npx ts-node src/results-checker.ts --input <path-to-output.csv> [--concurrency 2]
 */

import * as fs from 'fs';
import * as path from 'path';
import { parse } from 'csv-parse/sync';
import { stringify } from 'csv-stringify/sync';
import { checkBusiness } from './serviceCheck';

interface Row {
  'Business Name': string;
  'Vertical': string;
  'Website URL': string;
  [key: string]: string;
}

/**
 * Check every business in an output CSV and write two files next to it:
 *   <base>-Verified.csv    — service confirmed; ready to use
 *   <base>-For-Review.csv  — could not confirm; needs a human look
 * Returns the counts. Safe to call after a scrape or on its own.
 */
export async function checkResultsFile(inputPath: string, concurrency = 2): Promise<{ verified: number; review: number; verifiedPath?: string; reviewPath?: string }> {
  const raw = fs.readFileSync(inputPath, 'utf-8');
  const rows: Row[] = parse(raw, { columns: true, skip_empty_lines: true, bom: true });

  const dir = path.dirname(inputPath);
  const base = path.basename(inputPath).replace(/\.csv$/i, '');
  const verifiedPath = path.join(dir, `${base}-Verified.csv`);
  const reviewPath = path.join(dir, `${base}-For-Review.csv`);

  const verified: Record<string, string>[] = [];
  const review: Record<string, string>[] = [];

  for (let i = 0; i < rows.length; i += concurrency) {
    const batch = rows.slice(i, i + concurrency);
    const judged = await Promise.all(batch.map(async (row) => {
      const url = (row['Website URL'] || row['Reference URL'] || '').trim();
      const vertical = row['Vertical'] || '';
      const { verdict, notes } = await checkBusiness(url, vertical);
      return { row, verdict, notes };
    }));

    for (const { row, verdict, notes } of judged) {
      if (verdict === 'CONFIRMED') {
        verified.push({ ...row, 'Status': 'Verified', 'Why': notes });
      } else {
        review.push({ ...row, 'Status': 'For Review', 'Why': notes });
      }
    }
  }

  if (verified.length > 0) fs.writeFileSync(verifiedPath, stringify(verified, { header: true }), 'utf-8');
  if (review.length > 0) fs.writeFileSync(reviewPath, stringify(review, { header: true }), 'utf-8');

  return {
    verified: verified.length,
    review: review.length,
    verifiedPath: verified.length > 0 ? verifiedPath : undefined,
    reviewPath: review.length > 0 ? reviewPath : undefined,
  };
}

async function runCli(): Promise<void> {
  const args = process.argv.slice(2);
  const inputIdx = args.indexOf('--input');
  const concurrencyIdx = args.indexOf('--concurrency');

  if (inputIdx === -1 || !args[inputIdx + 1]) {
    console.error('Usage: npx ts-node src/results-checker.ts --input <path-to-output.csv> [--concurrency 2]');
    process.exit(1);
  }

  const inputPath = args[inputIdx + 1];
  const concurrency = concurrencyIdx !== -1 ? parseInt(args[concurrencyIdx + 1], 10) : 2;

  if (!fs.existsSync(inputPath)) {
    console.error(`File not found: ${inputPath}`);
    process.exit(1);
  }

  console.log(`\nResults Checker (no API, runs locally)`);
  console.log(`Input: ${inputPath}\n`);
  const r = await checkResultsFile(inputPath, concurrency);

  console.log('\n========================================');
  console.log('  RESULTS CHECK COMPLETE');
  console.log('========================================');
  console.log(`  Verified (ready to use): ${r.verified}`);
  console.log(`  For Review (take a look): ${r.review}`);
  console.log('  ----------------------------------------');
  if (r.verifiedPath) console.log(`  Verified list:   ${r.verifiedPath}`);
  if (r.reviewPath)   console.log(`  For-Review list: ${r.reviewPath}`);
  console.log('========================================\n');
}

// Only run the CLI when invoked directly, not when imported by the scraper.
if (require.main === module) {
  runCli().catch(err => {
    console.error('Error:', err);
    process.exit(1);
  });
}

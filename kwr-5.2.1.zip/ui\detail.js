// GET /run-detail/:id : a plain-language breakdown of one finished search for the Details window.
// Reads only that run's own result CSV and discard log from the output folder.
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');

const MAX_ROWS = 400;

// Friendly wording for the reasons the scraper records in the discard log.
function friendly(reason, detail) {
  const d = String(detail || '').trim();
  const isUrl = /^https?:\/\//i.test(d);
  switch (reason) {
    case 'Rating too low': return { text: d ? `Below the rating or review minimum (${d.replace('★', ' stars')})` : 'Below the rating or review minimum', flag: false };
    case 'Wrong category': return { text: isUrl || !d ? 'Not the right type of business on Google Maps' : d.replace(/^Sauna not evidenced on site$/i, 'No sign of this service on its website'), flag: false };
    case 'Geo mismatch': return { text: 'Map pin is in a different country', flag: true };
    case 'Wrong location': return { text: 'Not in the searched area', flag: true };
    case 'Domain chain': return { text: 'Part of a chain or franchise (same website as another result)', flag: false };
    case 'Name chain': return { text: 'Part of a chain or franchise (same name as another result)', flag: false };
    case 'Franchise (name)': return { text: 'Looks like a franchise', flag: false };
    case 'Spam content': return { text: 'Website looks like spam', flag: false };
    case 'Thin content': return { text: 'Website has too little content to confirm the service', flag: false };
    case 'Dead website': return { text: 'Website did not load', flag: false };
    case 'Off-domain redirect': return { text: 'Website redirects somewhere else', flag: false };
    case 'Entity (no website)': return { text: 'No website listed on Google Maps', flag: false };
    default: return { text: reason + (d && !isUrl ? ` (${d})` : ''), flag: false };
  }
}

function register(app, ctx) {
  const { OUTPUT_DIR, loadHistory } = ctx;

  app.get('/run-detail/:id', (req, res) => {
    const entry = loadHistory().find((r) => r.id === req.params.id);
    if (!entry) return res.status(404).json({ error: 'Run not found' });

    const rows = [];
    const reasons = {};

    if (entry.csvFile) {
      try {
        const f = path.join(OUTPUT_DIR, path.basename(entry.csvFile));
        const recs = parse(fs.readFileSync(f, 'utf8'), { columns: true, skip_empty_lines: true, relax_quotes: true, relax_column_count: true, bom: true });
        for (const r of recs) {
          rows.push({
            name: r['Business Name'] || '', result: 'kept',
            reason: r['Website Status'] === 'verified' ? 'Website matches the service' : 'Kept, website not confirmed',
            rating: r['Rating'] || '', reviews: r['Review Count'] || '', url: r['Website URL'] || '',
          });
        }
      } catch { /* the file may have been cleared; show what we have */ }
    }
    const kept = rows.length;

    let dropped = 0;
    if (entry.discardLogFile) {
      try {
        const f = path.join(OUTPUT_DIR, path.basename(entry.discardLogFile));
        const lines = fs.readFileSync(f, 'utf8').split(/\r?\n/);
        for (const line of lines) {
          const m = line.match(/^\[DISCARDED:\s*([^\]]+)\]\s+"(.*)"\s*(?:→|->)?\s*(.*)$/);
          if (!m) continue;
          dropped++;
          const fr = friendly(m[1].trim(), m[3]);
          reasons[fr.text.replace(/\s*\(.*\)$/, '')] = (reasons[fr.text.replace(/\s*\(.*\)$/, '')] || 0) + 1;
          if (rows.length < MAX_ROWS) rows.push({ name: m[2], result: fr.flag ? 'check' : 'dropped', reason: fr.text, rating: '', reviews: '', url: '' });
        }
      } catch { /* no discard log */ }
    }

    const byReason = Object.entries(reasons).sort((a, b) => b[1] - a[1]).map(([text, count]) => ({ text, count }));
    res.json({
      run: { site: entry.site, city: entry.city, vertical: entry.vertical, status: entry.status, completedAt: entry.completedAt },
      summary: { checked: kept + dropped, kept, dropped, check: rows.filter((r) => r.result === 'check').length },
      byReason,
      rows,
    });
  });
}

module.exports = { register, friendly };

/**
 * langDetect.ts
 *
 * Zero-dependency language detector for the accuracy verifier. No npm install,
 * no API, no network. Runs on text we have already extracted, so it adds no
 * measurable time to a check.
 *
 * Purpose (Option 2 — "skip what we cannot read"): the verifier only keyword-
 * judges pages written in a language we have loaded keywords for. Any page in a
 * language we have NOT loaded is set aside as UNCLEAR for manual/AI review,
 * instead of risking a wrong MISMATCH from running English keywords on, say, a
 * Korean or German page.
 *
 * To support a new language later: add its code to SUPPORTED_LANGS and add that
 * language's service keywords into the vertical keyword map. Nothing else.
 */

// Languages we have loaded keywords for somewhere in the vertical keyword map.
// Grow this list (plus the keyword map) as new markets keep appearing in review.
export const SUPPORTED_LANGS = new Set(['en', 'nl', 'th', 'vi']);

// Distinctive stopwords per Latin-script language. The language whose stopwords
// appear most in the page text wins. Used only to tell Latin languages apart
// (English/Dutch = loaded; German/French/Spanish/etc = not loaded).
const STOPWORDS: Record<string, string[]> = {
  en: ['the', 'and', 'of', 'to', 'in', 'for', 'with', 'our', 'we', 'your', 'is', 'are', 'you', 'services'],
  nl: ['de', 'het', 'een', 'van', 'en', 'wij', 'onze', 'voor', 'met', 'je', 'uw', 'ook', 'niet', 'zijn', 'aan'],
  es: ['el', 'la', 'los', 'las', 'de', 'y', 'para', 'con', 'nuestro', 'nuestra', 'que', 'una', 'servicios', 'por'],
  fr: ['le', 'la', 'les', 'de', 'et', 'pour', 'avec', 'notre', 'nos', 'vous', 'votre', 'des', 'une', 'est'],
  de: ['der', 'die', 'das', 'und', 'von', 'für', 'mit', 'unsere', 'wir', 'ihre', 'auch', 'nicht', 'sind', 'ein'],
  it: ['il', 'la', 'di', 'e', 'per', 'con', 'nostro', 'nostra', 'che', 'una', 'sono', 'tuo', 'servizi', 'del'],
  pt: ['o', 'a', 'os', 'de', 'e', 'para', 'com', 'nosso', 'nossa', 'que', 'uma', 'voce', 'servicos', 'do'],
};

function countScript(text: string, re: RegExp): number {
  const m = text.match(re);
  return m ? m.length : 0;
}

/**
 * Detect the dominant language of a page. Returns a 2-letter code. Non-Latin
 * scripts are detected by Unicode range; Latin languages by stopword frequency.
 */
export function detectLanguage(text: string): string {
  // Need a handful of characters, not a stray symbol, to call a script.
  const MIN_SCRIPT_CHARS = 6;

  if (countScript(text, /[฀-๿]/g) >= MIN_SCRIPT_CHARS) return 'th'; // Thai
  if (countScript(text, /[가-힣]/g) >= MIN_SCRIPT_CHARS) return 'ko'; // Korean
  if (countScript(text, /[぀-ヿ]/g) >= MIN_SCRIPT_CHARS) return 'ja'; // Japanese kana
  if (countScript(text, /[一-鿿]/g) >= MIN_SCRIPT_CHARS) return 'zh'; // CJK Han
  if (countScript(text, /[Ѐ-ӿ]/g) >= MIN_SCRIPT_CHARS) return 'ru'; // Cyrillic
  if (countScript(text, /[؀-ۿ]/g) >= MIN_SCRIPT_CHARS) return 'ar'; // Arabic
  if (countScript(text, /[ऀ-ॿ]/g) >= MIN_SCRIPT_CHARS) return 'hi'; // Devanagari

  // Vietnamese: Latin script, but distinctive diacritics give it away. Note: â
  // and ê are NOT included here — both are ordinary French letters ("être",
  // "château", "fenêtre"), so using them alone previously misdetected French
  // pages as Vietnamese. ă/đ/ơ/ư and the combining tone-mark range (Ạ-ỹ, e.g.
  // ạ/ệ/ộ/ừ) do not occur in French and are safe, exclusive Vietnamese signals.
  if (countScript(text, /[ăđơưĂĐƠƯ]/g) >= 3 ||
      countScript(text, /[Ạ-ỹ]/g) >= 3) return 'vi';

  // Latin script: vote by stopword frequency.
  const words = text.toLowerCase().split(/[^a-zà-ÿ]+/).filter(Boolean);
  const wordSet = new Set(words);
  let best = 'en';
  let bestScore = -1;
  for (const [lang, stops] of Object.entries(STOPWORDS)) {
    let score = 0;
    for (const s of stops) if (wordSet.has(s)) score++;
    if (score > bestScore) { bestScore = score; best = lang; }
  }
  // If essentially no stopwords matched, the text is too thin to tell — default
  // to English so the page still gets keyword-judged (same as before this change).
  if (bestScore <= 1) return 'en';
  return best;
}

/**
 * Decide whether a page should be keyword-judged. Returns the detected language
 * and whether it is one we have loaded keywords for.
 */
export function languageGate(text: string): { lang: string; supported: boolean } {
  const lang = detectLanguage(text);
  return { lang, supported: SUPPORTED_LANGS.has(lang) };
}

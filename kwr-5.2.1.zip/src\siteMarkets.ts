/**
 * siteMarkets.ts
 *
 * Which country each publication site covers, plus coarse country bounding boxes.
 *
 * Why this exists: a bare city name like "Halifax" or "Hamilton" is ambiguous, and
 * Google Maps resolves it using the IP address of whoever runs the tool. A team in
 * the Philippines therefore got Manila for "Halifax" and scraped Philippine
 * businesses for a Canadian site. The tool now always qualifies the city with the
 * site's own country ("Halifax, Canada"), and checks the resolved coordinates
 * actually fall inside that country before it scrapes anything.
 *
 * Adding a new site: add one line to SITE_MARKETS. Sites on a country-specific
 * domain (.co.uk, .ca, .com.au ...) are recognised automatically and need no entry.
 * A generic .com site that is NOT listed here gets no country guess; the tool then
 * prints a warning instead of guessing wrong.
 *
 * Adding a new country: add its name to SITE_MARKETS entries and a bounding box to
 * COUNTRY_BOUNDS. A country with no box is simply not bounds-checked.
 */

export const SITE_MARKETS: Record<string, string> = {
  'allrightbirmingham.co.uk': 'UK',
  'amazingzurich.com': 'Switzerland',
  'amsterdamdoneright.com': 'Netherlands',
  'aucklandmagazine.com': 'New Zealand',
  'avenueperth.com': 'Australia',
  'balidoneright.com': 'Indonesia',
  'bestinedmonton.com': 'Canada',
  'bestinireland.com': 'Ireland',
  'bestinmtl.com': 'Canada',
  'bestinwinnipeg.com': 'Canada',
  'blueskycalgary.com': 'Canada',
  'cleveraussie.com': 'Australia',
  'clevercanadian.ca': 'Canada',
  'cleverthai.com': 'Thailand',
  'columbusuncovered.com': 'United States',
  'happyhongkonger.com': 'Hong Kong',
  'sharpscot.co.uk': 'UK',
  'smartbrit.co.uk': 'UK',
  'smartsinga.com': 'Singapore',
  'sunnyedmonton.com': 'Canada',
  'thebestcalgary.com': 'Canada',
  'thebestcanberra.com': 'Australia',
  'thebestedmonton.com': 'Canada',
  'thebestgoldcoast.com': 'Australia',
  'thebesthalifax.com': 'Canada',
  'thebestmalta.com': 'Malta',
  'thebestmelbourne.com': 'Australia',
  'thebestsydney.com': 'Australia',
  'thebesttoronto.com': 'Canada',
  'thephoenixreview.com': 'United States',
  'totallysandiego.com': 'United States',
  'vietnamdoneright.com': 'Vietnam',
  'waterviewvancouver.com': 'Canada',
  'wowwinnipeg.com': 'Canada',
  'wunderlustlondon.co.uk': 'UK',
  // README examples
  'bestinsingapore.co': 'Singapore',
  'bestinchicago.com': 'United States',
};

/** Country-specific domain endings. Generic .com is deliberately absent: it says nothing about the market. */
const TLD_COUNTRY_MAP: Record<string, string> = {
  'co.uk': 'UK',
  'com.au': 'Australia',
  'ca': 'Canada',
  'sg': 'Singapore',
  'co.nz': 'New Zealand',
  'ie': 'Ireland',
  'co.za': 'South Africa',
  'in': 'India',
  'co.in': 'India',
};

function normaliseSite(site: string): string {
  return site
    .toLowerCase()
    .trim()
    .replace(/^https?:\/\//, '')
    .replace(/^www\./, '')
    .split('/')[0];
}

/** The country a site covers, or null when it cannot be determined (never guesses for generic .com). */
export function siteToCountry(site: string): string | null {
  const host = normaliseSite(site);
  if (SITE_MARKETS[host]) return SITE_MARKETS[host];
  // Subdomain of a listed site, e.g. blog.thebesthalifax.com
  for (const [listed, country] of Object.entries(SITE_MARKETS)) {
    if (host.endsWith('.' + listed)) return country;
  }
  for (const [tld, country] of Object.entries(TLD_COUNTRY_MAP)) {
    if (host.endsWith('.' + tld) || host === tld) return country;
  }
  return null;
}

type Box = [minLat: number, maxLat: number, minLng: number, maxLng: number];

/** Deliberately generous boxes (about half a degree of margin): they exist to catch "wrong country", not to trace borders. */
const COUNTRY_BOUNDS: Record<string, Box[]> = {
  // Two boxes, not one: a single rectangle spanning 41-83N would include open Pacific
  // south-west of Vancouver Island (where Google sometimes drops a pin for a business with
  // no street address) and would misclassify those pins as Canadian.
  'Canada': [
    [41.6, 49.2, -95.5, -52.0],      // southern Ontario, Quebec, Maritimes
    [48.2, 83.5, -141.5, -52.0],     // everything north of the southern BC coast
  ],
  'United States': [
    [24.0, 49.9, -125.5, -66.0],     // contiguous
    [51.0, 72.0, -170.0, -129.5],    // Alaska
    [18.5, 22.5, -160.8, -154.5],    // Hawaii
  ],
  'Australia': [[-44.5, -9.0, 112.0, 154.5]],
  'UK': [[49.5, 61.0, -9.0, 2.2]],
  'Ireland': [[51.0, 55.8, -11.0, -5.5]],
  'Singapore': [[1.1, 1.55, 103.5, 104.2]],
  'Thailand': [[5.4, 20.6, 97.2, 105.8]],
  'Vietnam': [[8.2, 23.6, 102.0, 109.7]],
  'Hong Kong': [[22.0, 22.7, 113.7, 114.6]],
  'Malta': [[35.6, 36.3, 14.0, 14.7]],
  'Switzerland': [[45.7, 48.0, 5.8, 10.7]],
  'Netherlands': [[50.6, 53.7, 3.2, 7.4]],
  'New Zealand': [[-47.6, -33.9, 165.9, 178.8]],
  'Indonesia': [[-11.2, 6.2, 94.9, 141.1]],
  // Watch-only: no site covers this country, but the team's computers are located there, so
  // a wrong Google answer can land here (Manila). Listed so a Philippine pin is recognised
  // as "clearly another country".
  'Philippines': [[4.4, 21.5, 116.0, 127.0]],
};

/**
 * True only when a business pin is clearly in a DIFFERENT known country than the site's
 * (e.g. a Halifax, England business for the Canadian Halifax site). Pins that fall inside
 * no known country (open ocean, or a place we have no box for) are given the benefit of
 * the doubt and return false: Google sometimes places a pin for a business with no street
 * address in the middle of an ocean, and dropping those would remove real businesses.
 */
const BORDER_MARGIN = 1.0;

export function isInWrongCountry(country: string, lat: number, lng: number): boolean {
  if (isInsideCountry(country, lat, lng) !== false) return false;   // inside own country, or no box to compare
  // Rectangles are coarse near borders (a Singapore pin at 103.47E fell inside Indonesia's box and
  // 11 real Singapore firms were dropped), so a pin within ~1 degree of the own country is never "wrong".
  const near = (COUNTRY_BOUNDS[country] || []).some(([minLat, maxLat, minLng, maxLng]) =>
    lat >= minLat - BORDER_MARGIN && lat <= maxLat + BORDER_MARGIN && lng >= minLng - BORDER_MARGIN && lng <= maxLng + BORDER_MARGIN);
  if (near) return false;
  return Object.keys(COUNTRY_BOUNDS).some(other => other !== country && isInsideCountry(other, lat, lng) === true);
}

/** true/false when the country has a known box, null when it does not (no check possible). */
export function isInsideCountry(country: string, lat: number, lng: number): boolean | null {
  const boxes = COUNTRY_BOUNDS[country];
  if (!boxes) return null;
  return boxes.some(([minLat, maxLat, minLng, maxLng]) =>
    lat >= minLat && lat <= maxLat && lng >= minLng && lng <= maxLng);
}

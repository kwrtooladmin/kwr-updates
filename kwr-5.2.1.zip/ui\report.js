// "Report a problem": builds a small diagnostics file for one chosen run and saves it to the Desktop.
// The user sends that one file to the maintainer (for example on WhatsApp). Nothing is uploaded anywhere,
// so there is no outside address to maintain or abuse.
//
// Safety: only a fixed set of files is ever read (the chosen run's result/discard files, the tail of
// update.log and one run-history entry). .env is never read, and any line that looks like a secret
// is removed before anything is written.
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const MAX_FILE_BYTES = 400 * 1024;       // per file
const MAX_TOTAL_BYTES = 2 * 1024 * 1024; // whole report
const SECRET_LINE = /(pass(word)?|passwd|secret|token|api[_-]?key|gmail_|smtp|authorization)\s*[=:]/i;

function scrub(text) {
  return String(text).split(/\r?\n/).filter((l) => !SECRET_LINE.test(l)).join('\n');
}

function readSafe(file, tailLines) {
  try {
    let t = fs.readFileSync(file, 'utf8');
    if (tailLines) t = t.split(/\r?\n/).slice(-tailLines).join('\n');
    if (Buffer.byteLength(t) > MAX_FILE_BYTES) t = t.slice(0, MAX_FILE_BYTES) + '\n[truncated]';
    return scrub(t);
  } catch { return null; }
}

function desktopDir() {
  const d = path.join(os.homedir(), 'Desktop');
  return fs.existsSync(d) ? d : os.homedir();
}

function register(app, ctx) {
  const { ROOT, OUTPUT_DIR, LOCAL_VERSION, isLocalRequest, loadHistory } = ctx;

  // Recent runs to choose from (newest first, the last 30).
  app.get('/report/recent', (req, res) => {
    const h = loadHistory().slice(0, 30).map((r) => ({
      id: r.id, site: r.site, city: r.city, vertical: r.vertical,
      status: r.status, verified: r.verified, completedAt: r.completedAt,
    }));
    res.json({ runs: h });
  });

  app.post('/report', async (req, res) => {
    if (!isLocalRequest(req)) return res.status(403).json({ error: 'Forbidden' });
    const { runId, reason, note } = req.body || {};
    const allowedReasons = ['wrong location', 'wrong service', 'too few results', 'other'];
    const why = allowedReasons.includes(reason) ? reason : 'other';
    const entry = loadHistory().find((r) => r.id === runId) || null;

    const files = [];
    let total = 0;
    const add = (name, content) => {
      if (content == null) return;
      const size = Buffer.byteLength(content);
      if (total + size > MAX_TOTAL_BYTES) return;
      total += size; files.push({ name, content });
    };
    if (entry) {
      for (const key of ['csvFile', 'discardLogFile', 'verifiedFile', 'reviewFile']) {
        const f = entry[key];
        if (f) add(path.basename(f), readSafe(path.join(OUTPUT_DIR, path.basename(f))));
      }
    }
    add('update.log.tail', readSafe(path.join(__dirname, 'update.log'), 150));

    const report = {
      kind: 'kwr-problem-report',
      createdAt: new Date().toISOString(),
      meta: {
        toolVersion: LOCAL_VERSION, node: process.version, platform: process.platform,
        computer: os.hostname(), timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        inOneDrive: /onedrive/i.test(ROOT),
      },
      reason: why,
      note: String(note || '').slice(0, 500),
      run: entry,
      files,
    };

    try {
      const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const out = path.join(desktopDir(), `KWR-report-${stamp}.json`);
      fs.writeFileSync(out, JSON.stringify(report, null, 2), 'utf8');
      // Show the new file in its folder so the user can attach it straight away.
      try {
        if (process.platform === 'win32') spawn('explorer.exe', [`/select,${out}`], { detached: true, stdio: 'ignore' }).unref();
        else if (process.platform === 'darwin') spawn('open', ['-R', out], { detached: true, stdio: 'ignore' }).unref();
      } catch { /* the message below still tells them where the file is */ }
      return res.json({ ok: true, savedTo: out });
    } catch (e) {
      return res.status(500).json({ ok: false, error: 'Could not save the report.' });
    }
  });
}

module.exports = { register, scrub };

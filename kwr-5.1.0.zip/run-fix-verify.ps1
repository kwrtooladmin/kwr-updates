﻿Set-Location 'C:\Users\User\Desktop\KWR_Tool_WORK HERE'
$runs = @(
  @('thebestsydney.com', 'Sydney', 'Cremation'),
  @('columbusuncovered.com', 'Columbus', 'Chin Filler'),
  @('blueskycalgary.com', 'Calgary', 'Hifu'),
  @('toronto-travel-guide.com', 'Toronto', 'Mold Inspection'),
  @('charlotteuncovered.com', 'Charlotte', 'Property Lawyer'),
  @('daslokalottawa.com', 'Ottawa', 'Property Lawyer'),
  @('jacksonvilletribune.co', 'Jacksonville', 'Deck Builder'),
  @('jacksonvilletribune.co', 'Jacksonville', 'Furnace Repair'),
  @('allrightbirmingham.co.uk', 'Birmingham', 'Deep Cleaning Services'),
  @('londonjourney.co.uk', 'London', 'Singing Lesson'),
  @('thebestmelbourne.com', 'Melbourne', 'Probate Lawyer'),
  @('wowwinnipeg.com', 'Winnipeg', 'Violin Lesson'),
  @('wowwinnipeg.com', 'Winnipeg', 'Guitar Lesson'),
  @('cleveraussie.com', 'melbourne', 'Yoga Studios'))
$total = $runs.Count
$i = 0
foreach ($r in $runs) {
  $i++
  $site = $r[0]; $city = $r[1]; $vertical = $r[2]
  Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-fix-verify.log' "[$(Get-Date -f 'HH:mm:ss')] RUN $i/$total - $site | $city | $vertical"
  npm run dev -- --site $site --city "$city" --vertical "$vertical"
  Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-fix-verify.log' "[$(Get-Date -f 'HH:mm:ss')] DONE $i/$total"
}
Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-fix-verify.log' "ALL DONE $(Get-Date)"

﻿Set-Location 'C:\Users\User\Desktop\KWR_Tool_WORK HERE'
$runs = @(
  @('blueskycalgary.com', 'Calgary', 'Hifu'),
  @('toronto-travel-guide.com', 'Toronto', 'Mold Inspection'))
$total = $runs.Count
$i = 0
foreach ($r in $runs) {
  $i++
  $site = $r[0]; $city = $r[1]; $vertical = $r[2]
  Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-fix3-verify.log' "[$(Get-Date -f 'HH:mm:ss')] RUN $i/$total - $site | $city | $vertical"
  npm run dev -- --site $site --city "$city" --vertical "$vertical"
  Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-fix3-verify.log' "[$(Get-Date -f 'HH:mm:ss')] DONE $i/$total"
}
Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-fix3-verify.log' "ALL DONE $(Get-Date)"

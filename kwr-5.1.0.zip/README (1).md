# KWR Selector v5.0 (V5) — Setup & Usage Guide

## What this tool does

This tool opens Google Maps, searches for a type of business in a city, collects the
best-rated results, filters out wrong matches and dead websites, and saves the final
list to a spreadsheet. You give it a website domain, a city, and a business type —
it does the rest and hands you a ready-to-use CSV file.

**Example:** you ask for *plumbers in Singapore for bestinsingapore.co* → you get a
spreadsheet of the 5 best plumbers (plus 3 backups), each with a confirmed-working
website, rating, and review count.

---

## Contents

1. [Quick start (already installed?)](#quick-start)
2. [Fresh install — first time setup](#fresh-install)
3. [Upgrading from any previous version](#upgrading)
4. [Running the tool — Web UI](#web-ui)
5. [Running the tool — command line](#command-line)
6. [Settings explained](#settings)
7. [Understanding your results](#results)
8. [Pass / Partial / Fail — what the statuses mean](#statuses)
9. [Background processes](#background)
10. [Troubleshooting](#troubleshooting)

---

## 1. Quick start

Already installed? This is all you need:

- **Easiest:** double-click **`Launch KWR.vbs`** (Windows) or **`Launch KWR (Mac).command`** (Mac). Your browser opens with the tool ready to use.
- Fill in **Site**, **City**, and **Vertical** → click **▶ Run all** → download your CSV from the **Results** tab.

Not installed yet? Continue to the next section.

---

## 2. Fresh install — first time setup

You only do this once. Allow about 10 minutes. You need an internet connection.

### Step 1 — Install Node.js

Node.js is the engine that runs this tool.

1. Go to: https://nodejs.org/en/download
2. Download the version labelled **LTS** ("Recommended for most users").
3. Run the installer. Click **Next** on every screen and accept all defaults.
4. When it finishes, click **Finish**.

**Check that it worked:**

1. Press the **Windows key**, type `PowerShell`, press **Enter**.
2. In the window that opens, type this and press **Enter**:
   ```
   node --version
   ```
3. You should see a version number like `v20.x.x`. If you see an error instead,
   restart your computer and try again — the installer sometimes needs a restart
   to finish setting up.

### Step 2 — Get the project folder

The person who sent you this tool provided it as a `.zip` file or shared drive link.

- If it is a `.zip`, right-click it → **Extract All** → choose somewhere easy to find
  (your Desktop is fine).
- Remember where the folder ended up.

### Step 3 — Open PowerShell inside the project folder

1. Open the project folder in File Explorer.
2. Click the **address bar** at the top of the window (where the folder path is shown).
3. Type `powershell` and press **Enter**.

A PowerShell window opens already pointed at the right folder. (You can also
right-click an empty area inside the folder and choose **"Open in Terminal"**.)

### Step 4 — Install dependencies

In the PowerShell window, type this and press **Enter**:

```
npm install
```

This downloads the supporting software the tool needs. It takes a minute or two.
When the prompt returns, it is done.

### Step 5 — Install the browser

The tool uses its own built-in browser to open Google Maps behind the scenes:

```
npx playwright install chromium
```

This takes a couple of minutes the first time.

### Step 6 — Create your settings file

The tool reads its settings from a file called `.env`. A ready-made template is
included — copy it with this command (in the same PowerShell window):

```
cp .env.example .env
```

> **Important:** do not create or rename this file in File Explorer. Windows hides
> file extensions, so what looks like `.env` may secretly be `.env.txt`, which breaks
> the tool. The PowerShell command above is always safe.

The default settings work well — you do not need to change anything to start.
See [Settings explained](#settings) if you want to adjust them later.

### Step 7 — Run it

Double-click **`Launch KWR.vbs`**. Your browser opens with the tool ready.
That's it — you're installed. See [Running the tool](#web-ui) for how to use it.

---

## 3. Upgrading from any previous version

Follow these steps if you already have an older KWR version (V3, V4, or an earlier V5)
on your machine.

**Step 0 — Save what you need.** If your old `output` folder has CSV files you still
want, copy that folder somewhere safe first. If you customised your `.env` settings,
copy that file out too.

1. **Delete the old project folder** entirely.
2. **Extract the new folder** to the same location.
3. **Open PowerShell in the new folder** (click the File Explorer address bar, type
   `powershell`, press Enter).
4. **Install dependencies:**
   ```
   npm install
   ```
5. **Reinstall the browser** — required even if you installed it before; a version
   mismatch makes the tool fail silently:
   ```
   npx playwright install chromium
   ```
6. **Restore your settings (optional):** copy your saved `.env` into the new folder.
   If you used the defaults, run `cp .env.example .env` instead.

Done. Launch the tool as normal.

**What is new in V5** (see CHANGELOG.md for full details):

- **Automatic updates** — this is the **last manual install**. From now on, when a
  new version is available the tool shows an "Update now" button; one click updates
  everything and keeps your settings and data. See [Automatic updates](#auto-update).
- Dead websites are no longer included in results — if a business's site is gone,
  the link is dropped instead of shipped.
- Hijacked-domain protection — URLs that secretly redirect to an unrelated site are
  caught and removed.
- Parked / "domain for sale" pages are now detected and rejected.
- Smarter filters for lawyers, deck builders, magicians, wedding planners,
  waterproofing, and music lessons — far fewer wrong-business results.

---


## 4. Running the tool — Web UI (recommended)

The Web UI lets you fill in a form and click a button instead of typing commands.
It shows live progress, keeps history, and gives you download buttons.

### Starting it

**Windows:** double-click **`Launch KWR.vbs`** in the project folder. The browser
opens automatically; no terminal window appears.

> Tip: right-click `Launch KWR.vbs` → **Send to → Desktop (create shortcut)** for a
> one-click Desktop launcher.

**Mac (first time only):** make the launcher executable:
1. Open **Terminal** (Cmd + Space, type `Terminal`, Enter).
2. Type `chmod +x ` (with a trailing space), then drag **`Launch KWR (Mac).command`**
   into the Terminal window, and press **Enter**.

After that, just double-click **`Launch KWR (Mac).command`** any time.

**Alternative (any platform):** open PowerShell/Terminal in the folder and run
`npm run ui`.

> If port 3000 is busy, the tool automatically picks a free port and opens the
> browser at the right address — nothing for you to do.

### Using it

The interface has three tabs: **Queue**, **Live Log**, and **Results**.

**Queue tab — set up your searches**

1. Fill in the first row:
   - **Site** — the website domain you are collecting listings for (e.g. `smartsinga.com`)
   - **City** — the city to search (e.g. `Singapore`)
   - **Vertical** — the business type (e.g. `Yoga Studios`)
2. Click **+ Add row** for more searches; **✕** removes a row.
3. Click **▶ Run all**.

Searches run one at a time with an automatic 2-minute pause between them. This pause
is intentional — it keeps Google from showing a CAPTCHA block. A batch of 5 searches
takes roughly 20–30 minutes.

**Live Log tab — watch progress**

Opens automatically when a run starts. Key messages:

| Message | Meaning |
|---|---|
| `[Step 3/6] Scraping sidebar listings...` | Collecting raw results from Google Maps |
| `[Step 5/6] Fetching website URLs...` | Opening each listing to find its website |
| `[Step 6/6] Verifying website URLs...` | Checking each website is live and genuine |
| `[baseline] Run logged → (PASS)` | 5 or more verified results — ready to use |
| `[baseline] Run logged → (PARTIAL)` | Fewer than 5 results found |
| `[CAPTCHA]` | Google showed a robot check — wait 15 minutes, then retry |

**Results tab — get your files**

Each completed search shows a card with a status badge, the top discard reason, and:

- **↓ CSV** — the results spreadsheet
- **↓ Excel** — the same results as an Excel file
- **↓ Discards** — a log of every business that was filtered out and why
- **↻ Retry** — re-run a failed or partial search

All runs are also kept in **Run History** below, and survive closing the browser.

**Other controls:** Light/Dark theme toggle, completion-sound mute, and **⏻ Shut Down**
(closes the tool server cleanly when you are done).

---


## 5. Running the tool — command line (advanced)

In a PowerShell window opened in the project folder:

```
npm start -- --site YOURSITE.com --city "Your City" --vertical "business type"
```

- `--site` — your website domain (no `https://`, just the domain)
- `--city` — the city to search (quotes needed if it contains a space)
- `--vertical` — the business type (quotes needed if it contains a space)

**Copy-paste examples:**

```
npm start -- --site bestinsingapore.co --city "Singapore" --vertical "plumber"
npm start -- --site bestinlondon.co.uk --city "London" --vertical "dentist"
npm start -- --site bestinchicago.com --city "Chicago" --vertical "electrician"
```

**Useful extra options:**

| Option | What it does |
|---|---|
| `--lang th` | Use a localized Google Maps language (e.g. Thai) for local-language results |
| `--radius 50` | Widen the search area to 50 km from the city centre (default 30) |
| `--allow-country` | Permit a country name in `--city` (normally blocked as too broad) |

Results land in the `output` folder, named like
`kwr-chicago-electrician-2026-06-11T12-00-00.csv`. Double-click to open in Excel.

---

<a name="settings"></a>
## 6. Settings explained

Settings live in the `.env` file. To edit it: open **Notepad** → **File → Open** →
navigate to the project folder → change the file-type dropdown to **All Files (*.*)**
→ open `.env`.

| Setting | Default | What it does |
|---|---|---|
| `KWR_MIN_RATING` | `4.5` | Only include businesses rated this high or above |
| `KWR_MIN_REVIEWS` | `100` | Only include businesses with at least this many reviews |
| `KWR_FALLBACK_RATING` | `4.0` | If too few results, retry accepting this rating |
| `KWR_FALLBACK_REVIEWS` | `30` | Review minimum used in the fallback pass |
| `KWR_MAX_SCROLL` | `15` | How far to scroll for more businesses (higher = slower, more thorough) |
| `KWR_TARGET_COUNT` | `30` | How many businesses to collect before stopping |
| `KWR_DISCOVERY_COUNT` | `60` | Raw listings to scan before filtering (increase if results seem thin) |
| `KWR_HEADLESS` | `true` | `true` = run invisibly; `false` = show the browser working |
| `KWR_OUTPUT_DIR` | `./output` | Where result files are saved |

The defaults work well for most searches. The most common change: if a niche vertical
returns too few results, lower `KWR_MIN_RATING` to `4.0` or `KWR_MIN_REVIEWS` to `50`.

---

<a name="results"></a>
## 7. Understanding your results

The spreadsheet columns:

| Column | Meaning |
|---|---|
| `Rank` | Position in the results (1 = best) |
| `Tier` | `primary` = top 5 recommended; `backup` = reserve options |
| `Business Name` | Name as shown on Google Maps |
| `Rating` | Google star rating |
| `Review Count` | Number of Google reviews |
| `Website URL` | The business's website |
| `Website Status` | `verified` = confirmed working · `social_only` = social page only · `maps_only` = Google Maps link only · `none` = no link found |
| `Reference URL` | Best available link — website, social, or Maps |
| `City` / `Vertical` | What you searched |

**Quality tiers — check before publishing.** Not every primary listing meets the same
bar. When a market is thin, the tool accepts lower-rated businesses to fill the list:

| Rating | Reviews | Confidence |
|---|---|---|
| 4.5+ | 100+ | Top rated — highest confidence |
| 4.0–4.4 | 30+ | Good — review before publishing |
| Below 4.0 | any | Best available — manual review recommended |

**The 30-second manual check.** The tool verifies that websites are live, genuine, and
not hijacked — but it cannot always tell from a name whether "Smith & Partners" does
property law or personal injury law. Before publishing, glance at each website to
confirm the business actually offers the service. This takes about 30 seconds per
listing and catches the small number of wrong matches that no filter can.

**The discards log** (`-discards.log` in the output folder) lists every business that
was rejected and why — "Wrong category", "Dead website", "Off-domain redirect",
"rating too low", etc. You don't need it, but it is useful when you wonder why a
business you expected is missing.

---

<a name="statuses"></a>
## 8. Pass / Partial / Fail — what the statuses mean

Every run gets one of four results, based on how many **verified** businesses were found:

| Status | Meaning | What to do |
|---|---|---|
| **PASS** (green) | 5 or more verified results | Ready to use |
| **PARTIAL** (amber) | 2–4 verified results | Usable, but the list is short — consider widening `--radius` or lowering thresholds |
| **THIN MARKET** (amber) | 1 result, in a market the tool detected as genuinely small | The city simply has few of these businesses |
| **FAIL** (red) | 0–1 results | Wrong vertical name, tiny market, or a CAPTCHA interrupted the run — retry first |

"Verified" means the business passed **every** check: right category, right city,
rating/review thresholds, not a chain or duplicate, and a confirmed-working website.

---

<a name="background"></a>
## 9. Background processes

On first launch the tool registers a Windows scheduled task called
**"KWR Daily Email Report"**. It runs silently at 7AM daily and emails the admin a
summary of the previous day's runs (site, city, vertical, pass/fail — nothing else).
If the machine was off at 7AM, it sends on next login. You can see it in Windows
Task Scheduler.

Every run is also logged to the `baseline` folder (local CSVs) for trend tracking.

---

<a name="troubleshooting"></a>
## 10. Troubleshooting

**"npm is not recognized..."**
Node.js is not installed or needs a restart. Re-run the Node.js installer
(Step 1 of Fresh Install), then restart your computer.

**CAPTCHA / robot-check error**
Google asked the tool to prove it is not a robot. Wait 10–15 minutes and retry.
This happens when many searches run in a short time — the Web UI's automatic
2-minute pause between queued runs exists to prevent it.

**"Geocode" error**
The city name was not recognised. Add the country:
```
--city "London, UK"
```

**Very few results / PARTIAL on a vertical you expected to be big**
Check the discards log first — it tells you exactly what was filtered out and why.
If many were dropped for low ratings, lower `KWR_MIN_RATING` to `4.0` or
`KWR_MIN_REVIEWS` to `50` in `.env`. If many were "Wrong category", the city may
genuinely have few dedicated businesses of that type.

**A business is missing that you expected to see**
Search for its name in the `-discards.log` file — the reason it was rejected is
listed there (wrong category, chain, low rating, dead website, etc.).

**The tool ran but the `.env` settings seem ignored**
Your settings file is probably named `.env.txt`. Delete it and re-create it with
the PowerShell command: `cp .env.example .env`

**"SelectorBrokenError"**
Google changed their page layout in a way that broke the tool. This needs a code
fix — contact the person who maintains the tool.

**Web UI won't open / blank page**
Close the browser tab, then double-click the launcher again. If it persists, open
PowerShell in the folder and run `npm run ui` to see the error message, and pass
it on to the maintainer.

﻿Set-Location 'C:\Users\User\Desktop\KWR_Tool_WORK HERE'
$runs = @(
  @('jacksonvilletribune.co', 'Jacksonville', 'Waterproofing'),
  @('jacksonvilletribune.co', 'Jacksonville', 'Magician'),
  @('jacksonvilletribune.co', 'Jacksonville', 'Photography Studio'),
  @('vietnamdoneright.com', 'Hanoi', 'Vietnamese Restaurant'),
  @('amazingzurich.com', 'Zurich', 'Catering Services'),
  @('allrightbirmingham.co.uk', 'Birmingham', 'Deep Cleaning Services'),
  @('smartbrit.co.uk', 'Manchester', 'Magicians'),
  @('thebestmalta.com', 'Malta', 'Wedding Planners'),
  @('londonjourney.co.uk', 'London', 'Event Planner'),
  @('londonjourney.co.uk', 'London', 'Singing Lesson'),
  @('londonjourney.co.uk', 'London', 'Dermal Filler'),
  @('thebestmelbourne.com', 'Melbourne', 'Probate Lawyer'),
  @('wowwinnipeg.com', 'Winnipeg', 'Violin Lesson'),
  @('wowwinnipeg.com', 'Winnipeg', 'Guitar Lesson'),
  @('amazingzurich.com', 'Zurich', 'Catering'),
  @('showmemalaysia.com', 'Kuala Lumpur', 'Wills Lawyer'),
  @('amsterdamdoneright.com', 'Amsterdam', 'Lip Filler'),
  @('jacksonvilletribune.co', 'Jacksonville', 'Magician'),
  @('thebestmalta.com', 'Malta', 'Wedding Planners'),
  @('londonjourney.co.uk', 'London', 'Event Planner'),
  @('jacksonvilletribune.co', 'Jacksonville', 'Deck Builder'),
  @('thebestmelbourne.com', 'Melbourne', 'Probate Lawyer'),
  @('wowwinnipeg.com', 'Winnipeg', 'Violin Lesson'),
  @('wowwinnipeg.com', 'Winnipeg', 'Guitar Lesson'),
  @('thebestmalta.com', 'Malta', 'Wedding Planners'),
  @('jacksonvilletribune.co', 'Jacksonville', 'Deck Builder'),
  @('wowwinnipeg.com', 'Winnipeg', 'Violin Lesson'),
  @('wowwinnipeg.com', 'Winnipeg', 'Guitar Lesson'),
  @('wowwinnipeg.com', 'Winnipeg', 'Violin Lesson'),
  @('wowwinnipeg.com', 'Winnipeg', 'Guitar Lesson'),
  @('wowwinnipeg.com', 'Winnipeg', 'Violin Lesson'),
  @('wowwinnipeg.com', 'Winnipeg', 'Guitar Lesson'),
  @('cleveraussie.com', 'melbourne', 'Yoga Studios'),
  @('jacksonvilletribune.co', 'Jacksonville', 'deck builder'),
  @('jacksonvilletribune.co', 'Jacksonville', 'magician'),
  @('smartbrit.co.uk', 'Manchester', 'magicians'),
  @('charlotteuncovered.com', 'Charlotte', 'property lawyer'),
  @('daslokalottawa.com', 'Ottawa', 'property lawyer'),
  @('thebestmelbourne.com', 'Melbourne', 'probate lawyer'),
  @('thebestmalta.com', 'Malta', 'wedding planners'),
  @('jacksonvilletribune.co', 'Jacksonville', 'waterproofing'))
$total = $runs.Count
$i = 17
foreach ($r in $runs) {
  $i++
  $site = $r[0]; $city = $r[1]; $vertical = $r[2]
  Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-rerun.log' "[$(Get-Date -f 'HH:mm:ss')] RUN $i/58 - $site | $city | $vertical"
  npm run dev -- --site $site --city "$city" --vertical "$vertical"
  Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-rerun.log' "[$(Get-Date -f 'HH:mm:ss')] DONE $i/58"
}
Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-rerun.log' "ALL DONE $(Get-Date)"

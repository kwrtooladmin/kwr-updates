import { EnrichedListing } from './types';
import { logDiscard } from './discardLog';

const VERIFY_TIMEOUT_MS = 15000;
const SPAM_GET_TIMEOUT_MS = 6000;
const THIN_LINK_THRESHOLD = 3;
const FETCH_MAX_BYTES = 100 * 1024; // 100 KB for link counting

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

const SOCIAL_DOMAINS = ['instagram.com', 'facebook.com', 'twitter.com', 'x.com', 'fb.com', 'tiktok.com'];
const SPAM_KEYWORDS = /casino|betting|gambling|slots|poker|roulette|sportsbook|togel|judi|viagra|cialis|payday loan|crypto investment|escort|xxx/i;
/** Parked / for-sale / expired domain pages — the original business site is gone */
const PARKED_KEYWORDS = /domain (is )?for sale|buy this domain|this domain has expired|domain parking|parked free|sedoparking|hugedomains|afternic|dan\.com\/buy|godaddy auctions|related searches/i;

/** Known URL shortener domains that should be resolved to their final destination */
const URL_SHORTENER_DOMAINS = new Set([
  'bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'ow.ly', 'short.io',
  'buff.ly', 'rebrand.ly', 'tiny.cc', 'is.gd', 'bl.ink', 'cutt.ly',
]);

/** Registrable domain approximation: last two labels (last three for ccTLD pairs like .co.uk) */
function registrableDomain(url: string): string | null {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '').toLowerCase();
    const parts = host.split('.');
    if (parts.length <= 2) return host;
    const ccSecond = new Set(['co', 'com', 'net', 'org', 'gov', 'edu', 'ac']);
    const takeThree = parts[parts.length - 1].length === 2 && ccSecond.has(parts[parts.length - 2]);
    return parts.slice(takeThree ? -3 : -2).join('.');
  } catch {
    return null;
  }
}

/**
 * SSRF guard: block private, loopback, and link-local hosts so a scraped/redirected
 * URL can't make the tool fetch internal services or cloud metadata (169.254.169.254).
 * Unparseable input is blocked too (fail closed).
 */
function isBlockedHost(url: string): boolean {
  try {
    const host = new URL(url).hostname.toLowerCase().replace(/^\[|\]$/g, '');
    if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local')) return true;
    if (host === '::1' || host.startsWith('fe80:') || host.startsWith('fc') || host.startsWith('fd')) return true;
    const m = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
    if (m) {
      const a = +m[1], b = +m[2];
      if (a === 0 || a === 10 || a === 127) return true;          // this-host / private / loopback
      if (a === 169 && b === 254) return true;                    // link-local + cloud metadata
      if (a === 192 && b === 168) return true;                    // private
      if (a === 172 && b >= 16 && b <= 31) return true;           // private
      if (a >= 224) return true;                                  // multicast / reserved
    }
    return false;
  } catch {
    return true;
  }
}

/**
 * Read up to maxBytes of a response body with a hard time cap, cancelling the stream
 * when either limit is hit. Prevents a slow-drip or multi-hundred-MB hostile page
 * (parked domains, bot traps) from hanging or OOM-ing the whole run — res.text()
 * would read the entire body with no bound.
 */
async function readCapped(res: Response, maxBytes: number, timeoutMs: number): Promise<string> {
  const body = res.body as ReadableStream<Uint8Array> | null;
  if (!body || typeof body.getReader !== 'function') {
    const t = await res.text();
    return t.slice(0, maxBytes);
  }
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let received = 0;
  let out = '';
  const timer = setTimeout(() => { reader.cancel().catch(() => {}); }, timeoutMs);
  try {
    while (received < maxBytes) {
      const { done, value } = await reader.read();
      if (done) break;
      received += value.length;
      out += decoder.decode(value, { stream: true });
    }
  } catch {
    /* cancelled or aborted — return whatever we managed to read */
  } finally {
    clearTimeout(timer);
    reader.cancel().catch(() => {});
  }
  return out.slice(0, maxBytes);
}

function isSocialMedia(url: string): boolean {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    return SOCIAL_DOMAINS.some((d) => host === d || host.endsWith('.' + d));
  } catch {
    return false;
  }
}

function isUrlShortener(url: string): boolean {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    return URL_SHORTENER_DOMAINS.has(host);
  } catch {
    return false;
  }
}

/** Follow a shortened URL to its final destination */
async function resolveShortUrl(url: string): Promise<string> {
  if (isBlockedHost(url)) return url;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), VERIFY_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      method: 'HEAD',
      signal: controller.signal,
      redirect: 'follow',
      headers: { 'User-Agent': UA },
    });
    clearTimeout(timer);
    const finalUrl = response.url;
    if (finalUrl && isBlockedHost(finalUrl)) return url; // don't resolve to a private host
    if (finalUrl && finalUrl !== url) {
      console.log(`  [verify] Resolved short URL: ${url} → ${finalUrl}`);
      return finalUrl;
    }
    return url;
  } catch {
    clearTimeout(timer);
    return url;
  }
}

const BLOCKED_SENTINEL = '__BLOCKED__';
const RETRY_ATTEMPTS = 3;

/** Strip UTM and common tracking parameters so redirect chains resolve cleanly */
function stripTrackingParams(url: string): string {
  try {
    const u = new URL(url);
    const trackingKeys = [...u.searchParams.keys()].filter(
      k => k.startsWith('utm_') || ['fbclid', 'gclid', 'msclkid', 'mc_eid', 'ref'].includes(k)
    );
    trackingKeys.forEach(k => u.searchParams.delete(k));
    return u.toString();
  } catch {
    return url;
  }
}

/** fetch with automatic retry on transient network errors (not HTTP 4xx/5xx) */
async function fetchWithRetry(url: string, options: RequestInit, timeoutMs: number): Promise<Response> {
  let lastErr: unknown;
  for (let attempt = 0; attempt < RETRY_ATTEMPTS; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, { ...options, signal: controller.signal });
      clearTimeout(timer);
      return res;
    } catch (err) {
      clearTimeout(timer);
      lastErr = err;
      if (attempt < RETRY_ATTEMPTS - 1) {
        await new Promise(r => setTimeout(r, 400 * Math.pow(2, attempt)));
      }
    }
  }
  throw lastErr;
}

/** Fetch up to 100 KB of a page for spam + thin-content checks.
 *  Returns BLOCKED_SENTINEL if the server blocks automated GET requests (403/401/406).
 *  Returns empty string on network error or timeout.
 */
async function fetchPageSnippet(url: string): Promise<string> {
  if (isBlockedHost(url)) return '';
  try {
    const res = await fetchWithRetry(url, { method: 'GET', headers: { 'User-Agent': UA }, redirect: 'follow' }, SPAM_GET_TIMEOUT_MS);
    if (isBlockedHost(res.url || url)) return '';
    if (res.status === 403 || res.status === 401 || res.status === 406) {
      return BLOCKED_SENTINEL;
    }
    // Bounded, time-capped read — never read an unbounded body (hang/OOM guard).
    return await readCapped(res, FETCH_MAX_BYTES, SPAM_GET_TIMEOUT_MS);
  } catch {
    return '';
  }
}

/** Classify one href/data-href value and add it to the seen set if internal */
function addInternalLink(href: string, baseDomain: string, seen: Set<string>): void {
  if (!href || href.startsWith('mailto:') || href.startsWith('tel:') || href.startsWith('javascript:')) return;
  if (href.startsWith('/') && !href.startsWith('//')) {
    seen.add(href.split('?')[0]);
  } else {
    try {
      const u = new URL(href);
      if (u.hostname.replace(/^www\./, '') === baseDomain) {
        seen.add(u.pathname);
      }
    } catch { /* not a URL — skip */ }
  }
}

/**
 * Count distinct internal link paths in fetched HTML.
 * Scans both standard `href` attributes and `data-href` attributes — the latter
 * is used by Wix and similar JS site builders where the `href` on <a> tags is
 * left blank and the real destination is stored in `data-href`.
 */
function countInternalLinks(html: string, baseUrl: string): number {
  let baseDomain: string;
  try {
    baseDomain = new URL(baseUrl).hostname.replace(/^www\./, '');
  } catch {
    return 0;
  }
  const seen = new Set<string>();
  let match;

  // Standard href attributes
  const hrefRegex = /\bhref=["']([^"'#][^"']*?)["']/gi;
  while ((match = hrefRegex.exec(html)) !== null) {
    addInternalLink(match[1], baseDomain, seen);
  }

  // data-href attributes (Wix, Weebly, and similar builders)
  const dataHrefRegex = /\bdata-href=["']([^"']+)["']/gi;
  while ((match = dataHrefRegex.exec(html)) !== null) {
    addInternalLink(match[1], baseDomain, seen);
  }

  return seen.size;
}

/**
 * Detect WordPress sites — their <head> sections are often so large (inline CSS,
 * image preloads, plugin scripts) that the 100 KB fetch cap is exhausted before
 * any <a> nav tags appear in the <body>, causing false thin-content failures.
 */
function isWordPressSite(html: string): boolean {
  return html.includes('/wp-content/') || html.includes('/wp-includes/');
}

/**
 * Detect JS site builders (Wix, Squarespace, Webflow) as a fallback safety net
 * for cases where data-href counting still yields too few links.
 */
function isJsBuilderSite(html: string): boolean {
  return (
    html.includes('static.wixstatic.com') ||
    html.includes('squarespace-cdn.com') ||
    html.includes('assets.squarespace.com') ||
    html.includes('assets.website-files.com') ||  // Webflow
    html.includes('cdn.builder.io')                // Builder.io
  );
}

/**
 * Returns true when the page contains enough business signals to be trusted as a
 * legitimate simple site even if it has fewer than THIN_LINK_THRESHOLD internal links.
 *
 * ALL three of the following must be present:
 *   1. A non-empty <title> tag with more than 10 characters of meaningful text.
 *   2. A <meta name="description"> tag with a non-empty content attribute.
 *   3. At least one of: a phone number pattern, an email address, or a contact-form indicator.
 *
 * Typical cases: small tutoring/service businesses with a single-page or
 * minimal-nav site that is otherwise fully legitimate.
 */
export function isSimpleLegitSite(html: string): boolean {
  // 1. Non-empty <title> with more than 10 meaningful characters
  const titleMatch = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html);
  const titleText = (titleMatch?.[1] ?? '').trim();
  if (titleText.length <= 10) return false;

  // 2. <meta name="description"> with non-empty content (attribute order-independent)
  const descMatch =
    /<meta[^>]*name=["']description["'][^>]*content=["']([^"']+)/i.exec(html) ??
    /<meta[^>]*content=["']([^"']+)["'][^>]*name=["']description["']/i.exec(html);
  if (!descMatch || !descMatch[1].trim()) return false;

  // 3. At least one contact signal
  const PHONE_RE    = /(\+?\d[\d\s\-(). ]{6,}\d)/;
  const EMAIL_RE    = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/;
  const FORM_RE     = /<form\b|<input[^>]+type=["']submit["']|name=["']contact/i;
  return PHONE_RE.test(html) || EMAIL_RE.test(html) || FORM_RE.test(html);
}

/** Detect bot-challenge pages that return HTTP 200 with minimal JS-only content */
function isBotChallengePage(html: string): boolean {
  return (
    html.includes('cf_chl_opt') ||
    html.includes('cf-browser-verification') ||
    html.includes('challenge-platform') ||
    (html.includes('Just a moment') && html.length < 15000)
  );
}

/** Strip tags/scripts and return visible text from an HTML chunk */
function visibleText(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ');
}

function isSpam(snippet: string): boolean {
  const titleMatch = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(snippet);
  const metaMatch =
    /<meta[^>]*name=["']description["'][^>]*content=["']([^"']*)/i.exec(snippet) ??
    /<meta[^>]*content=["']([^"']*?)["'][^>]*name=["']description["']/i.exec(snippet);
  const headText = `${titleMatch?.[1] ?? ''} ${metaMatch?.[1] ?? ''}`;
  if (SPAM_KEYWORDS.test(headText) || PARKED_KEYWORDS.test(headText)) return true;
  // Also scan visible body text — hijacked/parked pages rarely flag themselves in the
  // title. Parked phrases are unambiguous (single hit); spam keywords need 3+ distinct
  // matches so a legit business mentioning e.g. "casino night events" isn't discarded.
  const bodyText = visibleText(snippet.slice(0, 40 * 1024));
  if (PARKED_KEYWORDS.test(bodyText)) return true;
  const spamHits = new Set((bodyText.match(new RegExp(SPAM_KEYWORDS.source, 'gi')) ?? []).map(m => m.toLowerCase()));
  return spamHits.size >= 3;
}

/** Verify a single URL: returns { verified, nullifyUrl, gmbTrust, finalUrl } */
async function verifyUrl(url: string, listingName: string): Promise<{ verified: boolean; nullifyUrl: boolean; gmbTrust: boolean; finalUrl: string }> {
  // 0. Strip tracking/UTM parameters — these create spurious redirect chains
  url = stripTrackingParams(url);

  // 1. Resolve shortened URLs to their final destination before any checks
  if (isUrlShortener(url)) {
    url = await resolveShortUrl(url);
  }

  // 2. Social media check (no network request needed)
  if (isSocialMedia(url)) {
    logDiscard('Social media', listingName);
    return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl: url };
  }

  // 2b. SSRF guard: never fetch a private/loopback/link-local host.
  if (isBlockedHost(url)) {
    logDiscard('Blocked host', listingName, url);
    return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl: url };
  }

  // 3. HEAD request with retry; fall back to GET when HEAD is rejected outright
  let headOk = false;
  let finalUrl = url;

  try {
    const response = await fetchWithRetry(url, {
      method: 'HEAD',
      redirect: 'follow',
      headers: { 'User-Agent': UA },
    }, VERIFY_TIMEOUT_MS);
    finalUrl = response.url || url;
    // If the URL redirected to a private/internal host, drop it (SSRF + hijack guard).
    if (isBlockedHost(finalUrl)) {
      logDiscard('Blocked host', listingName, `${url} → ${finalUrl}`);
      return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl };
    }
    headOk = response.status < 400 || response.status === 405 || response.status === 403;

    // Some JS-rendered / redirect-chain sites reject HEAD but accept GET — try GET fallback
    if (!headOk && (response.status === 405 || response.status === 404)) {
      try {
        const getResp = await fetchWithRetry(url, {
          method: 'GET',
          redirect: 'follow',
          headers: { 'User-Agent': UA },
        }, VERIFY_TIMEOUT_MS);
        finalUrl = getResp.url || url;
        headOk = getResp.status < 400;
        if (headOk) console.log(`  [verify] HEAD failed but GET succeeded for: ${url}`);
      } catch { /* ignore GET fallback error */ }
    }

    if (!headOk) {
      console.warn(`  [verify] ${url} → HTTP ${response.status}`);
      return { verified: false, nullifyUrl: false, gmbTrust: false, finalUrl };
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    // Hard failures mean the site is gone (DNS dead, nothing listening) — a dead
    // link must not ship in output. Timeouts/resets may just be a slow or
    // bot-hostile server, so those keep the GMB benefit of the doubt.
    const cause = (err as { cause?: { code?: string } })?.cause?.code ?? '';
    const isHardFailure = /ENOTFOUND|ECONNREFUSED|ERR_NAME_NOT_RESOLVED|CERT_HAS_EXPIRED|DEPTH_ZERO_SELF_SIGNED/i.test(cause + ' ' + message);
    if (isHardFailure) {
      console.warn(`  [verify] Site unreachable (${cause || message}) — dropping URL for: ${url}`);
      logDiscard('Dead website', listingName, url);
      return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl: url };
    }
    console.warn(`  [verify] ${url} → ${message}`);
    return { verified: false, nullifyUrl: false, gmbTrust: true, finalUrl: url };
  }

  // 3b. Off-domain redirect guard: an expired or hijacked domain often redirects to
  // an unrelated live site, which would otherwise pass every check below. A redirect
  // to a different registrable domain forfeits all GMB-trust shortcuts — the page
  // must positively pass the content checks to keep the URL.
  const origDomain = registrableDomain(url);
  const offDomain = origDomain !== null && registrableDomain(finalUrl) !== null && registrableDomain(finalUrl) !== origDomain;
  if (offDomain) {
    console.warn(`  [verify] Off-domain redirect: ${origDomain} → ${registrableDomain(finalUrl)} for "${listingName}"`);
  }

  // 4. Spam/gambling GET check + thin-content check (use finalUrl after redirects)
  const fullHtml = await fetchPageSnippet(finalUrl);
  if (fullHtml && isSpam(fullHtml.slice(0, 4096))) {
    logDiscard('Spam content', listingName);
    return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl };
  }

  if (fullHtml === BLOCKED_SENTINEL) {
    if (offDomain) {
      console.warn(`  [verify] Off-domain redirect target blocks access — dropping URL for: ${listingName}`);
      logDiscard('Off-domain redirect', listingName, `${url} → ${finalUrl}`);
      return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl };
    }
    console.log(`  [network] Site blocks automated access but HEAD passed — trusting GMB listing for: ${finalUrl}`);
    return { verified: false, nullifyUrl: false, gmbTrust: true, finalUrl };
  }

  if (!fullHtml && offDomain) {
    // Couldn't read the redirect target at all — can't prove it's the same business
    console.warn(`  [verify] Off-domain redirect target unreadable — dropping URL for: ${listingName}`);
    logDiscard('Off-domain redirect', listingName, `${url} → ${finalUrl}`);
    return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl };
  }

  if (fullHtml) {
    // A bot-challenge page (Cloudflare etc.) returns 200 with minimal JS — HEAD
    // passed so the real site is up; trust GMB rather than discard.
    if (!offDomain && isBotChallengePage(fullHtml)) {
      console.log(`  [network] Bot challenge page detected — trusting GMB listing for: ${finalUrl}`);
      return { verified: false, nullifyUrl: false, gmbTrust: true, finalUrl };
    }

    const linkCount = countInternalLinks(fullHtml, finalUrl);
    if (linkCount < THIN_LINK_THRESHOLD) {
      // WordPress: large <head> sections push nav links beyond the 100 KB cap.
      // JS builders (Wix, Squarespace, Webflow): data-href already counted above,
      // but detect as a safety net in case the HTML structure is unusual.
      // In both cases the HEAD check passed, so the site is real — trust GMB.
      // An off-domain redirect forfeits these shortcuts: the page must stand on
      // its own, since "real site" no longer implies "this business's site".
      if (!offDomain && (isWordPressSite(fullHtml) || isJsBuilderSite(fullHtml))) {
        console.log(`  [network] Known platform detected (${isWordPressSite(fullHtml) ? 'WordPress' : 'JS builder'}) — trusting GMB for: ${finalUrl}`);
        return { verified: false, nullifyUrl: false, gmbTrust: true, finalUrl };
      }
      if (!offDomain && isSimpleLegitSite(fullHtml)) {
        console.log(`  [network] Simple legitimate site detected — trusting GMB for: ${finalUrl}`);
        return { verified: false, nullifyUrl: false, gmbTrust: true, finalUrl };
      }
      console.warn(`  [verify] Thin content (${linkCount} internal links): ${finalUrl}`);
      logDiscard(offDomain ? 'Off-domain redirect' : 'Thin content', listingName);
      return { verified: false, nullifyUrl: true, gmbTrust: false, finalUrl };
    }
  }

  return { verified: true, nullifyUrl: false, gmbTrust: false, finalUrl };
}

/** Verify all website URLs in parallel, discarding social/spam URLs entirely */
export async function verifyWebsites(
  listings: EnrichedListing[]
): Promise<EnrichedListing[]> {
  const results = await Promise.all(
    listings.map(async (listing) => {
      if (!listing.websiteUrl) {
        return { ...listing, websiteVerified: false };
      }

      const { verified, nullifyUrl, gmbTrust, finalUrl } = await verifyUrl(listing.websiteUrl, listing.name);

      if (verified) {
        console.log(`  [verify] ✓ ${listing.name}: ${finalUrl}`);
      } else if (gmbTrust) {
        console.log(`  [network] URL check failed but trusting GMB listing for: ${finalUrl}`);
      } else if (!nullifyUrl) {
        console.log(`  [verify] ✗ ${listing.name}: ${finalUrl}`);
      }

      return {
        ...listing,
        websiteUrl: nullifyUrl ? null : finalUrl,
        websiteVerified: verified || gmbTrust,
      };
    })
  );

  return results;
}

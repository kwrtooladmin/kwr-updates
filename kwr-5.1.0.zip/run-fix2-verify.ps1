﻿Set-Location 'C:\Users\User\Desktop\KWR_Tool_WORK HERE'
$runs = @(
  @('charlotteuncovered.com', 'Charlotte', 'Property Lawyer'),
  @('daslokalottawa.com', 'Ottawa', 'Property Lawyer'),
  @('blueskycalgary.com', 'Calgary', 'Hifu'),
  @('toronto-travel-guide.com', 'Toronto', 'Mold Inspection'),
  @('allrightbirmingham.co.uk', 'Birmingham', 'Deep Cleaning Services'),
  @('londonjourney.co.uk', 'London', 'Singing Lesson'),
  @('wowwinnipeg.com', 'Winnipeg', 'Violin Lesson'),
  @('wowwinnipeg.com', 'Winnipeg', 'Guitar Lesson'),
  @('jacksonvilletribune.co', 'Jacksonville', 'Deck Builder'),
  @('cleveraussie.com', 'melbourne', 'Yoga Studios'))
$total = $runs.Count
$i = 0
foreach ($r in $runs) {
  $i++
  $site = $r[0]; $city = $r[1]; $vertical = $r[2]
  Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-fix2-verify.log' "[$(Get-Date -f 'HH:mm:ss')] RUN $i/$total - $site | $city | $vertical"
  npm run dev -- --site $site --city "$city" --vertical "$vertical"
  Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-fix2-verify.log' "[$(Get-Date -f 'HH:mm:ss')] DONE $i/$total"
}
Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-fix2-verify.log' "ALL DONE $(Get-Date)"

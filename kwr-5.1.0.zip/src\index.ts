import { Command } from 'commander';
import { buildConfig } from './config';
import { launchBrowser, createContext } from './browser';
import { geocodeCity, buildSearchUrl, siteToCountry, haversineDistance } from './geocoder';
import { scrollAndScrape } from './scraper';
import { runFilterPipeline, applyDomainFilter, applyEntityFilter } from './filters';
import { applyCategoryFilter } from './categoryFilter';
import { fetchWebsiteUrls } from './detailFetcher';
import { verifyWebsites } from './verifier';
import { writeCsv } from './output';
import { getDiscards } from './discardLog';
import { logRun } from './testLogger';
import { isCaptchaPresent, resolveSelector } from './selectors';
import * as fs from 'fs';
import { randomDelay } from './humanize';
import {
  CaptchaError,
  GeocodeError,
  SelectorBrokenError,
} from './errors';

async function main() {
  const program = new Command();

  program
    .name('kwr-selector')
    .description('Select best local businesses for a media site via Google Maps scraping')
    .requiredOption('--site <domain>', 'Media site domain (e.g. bestinsingapore.co)')
    .requiredOption('--city <name>', 'Target city (e.g. "Singapore" or "London, ON")')
    .requiredOption('--vertical <keyword>', 'Business vertical (e.g. "plumber")')
    .option('--allow-country', 'Allow country-level --city input (skips validation)', false)
    .option('--lang <languageCode>', 'Google Maps host language for localized results (e.g. th, fr)')
    .option('--radius <kilometers>', 'Geofence radius from city centre in km (default 30)', (v) => parseFloat(v), 30)
    .version(require('../package.json').version);

  program.parse(process.argv);

  const opts = program.opts<{ site: string; city: string; vertical: string; allowCountry: boolean; lang?: string; radius: number }>();
  const config = buildConfig(opts);

  console.log(`\nkwr-selector`);
  console.log(`  Site:     ${config.site}`);
  console.log(`  City:     ${config.city}`);
  console.log(`  Vertical: ${config.vertical}`);
  console.log(`  Output:   ${config.outputPath}\n`);

  // Baseline tracking
  let _totalScraped = 0;
  let _totalCandidates = 0;
  let _verifiedCount = 0;
  let _hadMarketRealityWarning = false;
  let _discardLogPath: string | null = null;

  const browser = await launchBrowser(config);
  const context = await createContext(browser, config);
  const page = await context.newPage();

  try {
    // Step 1: Geocode city
    console.log(`[Step 1/6] Geocoding "${config.city}"...`);
    const geo = await geocodeCity(page, config.city);
    console.log(`  → lat=${geo.lat}, lng=${geo.lng}, zoom=${geo.zoom}`);

    if (geo.locationType === 'country' && !config.allowCountry) {
      console.error(
        `\x1b[33m[INPUT ERROR] Country-level input detected: ${config.city}. ` +
        `Please specify a city (e.g., Bangkok instead of Thailand). ` +
        `To run a national search anyway, use the --allow-country flag.\x1b[0m`
      );
      await context.close();
      await browser.close();
      process.exit(1);
    }

    // Step 2: Navigate to vertical search
    const country = siteToCountry(config.site);
    const searchUrl = buildSearchUrl(config.vertical, geo, config.city, country, config.lang);
    console.log(`\n[Step 2/6] Loading vertical search...`);
    console.log(`  → ${searchUrl}`);
    await page.goto(searchUrl, { waitUntil: 'load', timeout: 30000 });
    await randomDelay(2000, 3500);

    if (await isCaptchaPresent(page)) {
      throw new CaptchaError();
    }

    // Early health check — abort before scraping if sidebar not found
    const feedReady = await resolveSelector(page, 'sidebarFeed', 5000).catch(() => null);
    if (!feedReady) {
      if (await isCaptchaPresent(page)) throw new CaptchaError();
      throw new SelectorBrokenError('sidebarFeed');
    }

    // Step 5: Scroll & scrape sidebar
    console.log(`\n[Step 3/6] Scraping sidebar listings...`);
    const rawListings = await scrollAndScrape(page, config);
    _totalScraped = rawListings.length;
    console.log(`  → ${rawListings.length} raw listings`);

    // Step 6: Filter & score
    console.log(`\n[Step 4/6] Filtering and scoring...`);
    const preFiltered = runFilterPipeline(rawListings, config);
    const candidates = applyCategoryFilter(preFiltered, config.vertical);
    _totalCandidates = candidates.length;
    console.log(`  → ${candidates.length} candidates for detail fetching`);

    // Step 7: Fetch website URLs + addresses (Phase 2)
    console.log(`\n[Step 5/6] Fetching website URLs from detail panels...`);
    const enriched = await fetchWebsiteUrls(page, candidates, config.city);

    // Step 7a: Geographic filter — text match, then haversine fallback
    const geoFiltered = enriched.filter((l) => {
      if (l.cityMatch) return true;
      if (l.lat != null && l.lng != null) {
        const dist = haversineDistance(geo.lat, geo.lng, l.lat, l.lng);
        if (dist <= config.radius) {
          console.log(`  [filter] Geo fallback ACCEPTED "${l.name}" (${dist.toFixed(1)} km from centre)`);
          return true;
        }
        console.log(`  [filter] Geo fallback REJECTED "${l.name}" (${dist.toFixed(1)} km, radius=${config.radius} km)`);
      }
      return false;
    });
    const geoBled = enriched.length - geoFiltered.length;
    if (geoBled > 0) {
      console.log(`  [filter] Geo: discarded ${geoBled} listing(s) outside "${config.city}"`);
    }

    // Step 7b: Domain-based chain filter
    const domainFiltered = applyDomainFilter(geoFiltered);

    // Step 7c: Entity filter (Dr. without dedicated clinic site)
    const entityFiltered = applyEntityFilter(domainFiltered);

    console.log(`  → ${entityFiltered.length} candidates after geo/domain/entity filters`);

    // Step 8: Verify websites (includes social media + spam checks)
    console.log(`\n[Step 6/6] Verifying website URLs...`);
    const verified = await verifyWebsites(entityFiltered);

    const verifiedCount = verified.filter((l) => l.websiteVerified).length;
    _verifiedCount = verifiedCount;
    console.log(`  → ${verifiedCount}/${verified.length} websites verified`);

    // Step 9: Market reality check
    if (verified.length === 0) {
      _hadMarketRealityWarning = true;
      console.log(
        `\n\x1b[33m[MARKET REALITY] 0 qualifying businesses found. ` +
        `This is likely a small market or highly niche vertical.\x1b[0m`
      );
      const emptyPath = await writeCsv([], config);
      console.log(`Empty CSV written to: ${emptyPath}`);
      logRun({
        site: config.site,
        city: config.city,
        vertical: config.vertical,
        totalScraped: _totalScraped,
        totalCandidates: _totalCandidates,
        verified: 0,
        hadMarketRealityWarning: true,
        discardLogPath: _discardLogPath,
        discards: getDiscards(),
        listings: [],
      });
      return; // finally block handles browser cleanup
    } else if (verified.length < config.minCandidates) {
      _hadMarketRealityWarning = true;
      console.log(
        `\n\x1b[33m[MARKET REALITY] Only found ${verified.length} qualifying businesses ` +
        `(Target: ${config.minCandidates}). Outputting partial list.\x1b[0m`
      );
    }

    // Step 10: Write CSV
    const outputPath = await writeCsv(verified, config);
    console.log(`\nDone! Output written to: ${outputPath}`);

    // Step 11: Write discard log
    const discards = getDiscards();
    if (discards.length > 0) {
      const discardPath = config.outputPath.replace('.csv', '-discards.log');
      const lines = discards.map((d) => `[DISCARDED: ${d.reason}] "${d.name}"${d.url ? ` → ${d.url}` : ''}`);
      fs.writeFileSync(discardPath, lines.join('\n') + '\n');
      console.log(`Discard log (${discards.length} entries): ${discardPath}`);
      _discardLogPath = discardPath;
    }

    // Summary
    const withUrl = verified.filter((l) => l.websiteUrl).length;
    console.log(`\nSummary:`);
    console.log(`  Total candidates: ${verified.length}`);
    console.log(`  With website URL: ${withUrl}`);
    console.log(`  Verified websites: ${verifiedCount}`);
    console.log(`  Primary listings: up to 5`);
    console.log(`  Backup listings: up to 3`);

    // Run result summary line
    const resultLabel = verifiedCount >= 5 ? 'PASS'
      : verifiedCount >= 2 ? 'PARTIAL'
      : (verifiedCount >= 1 && _hadMarketRealityWarning) ? 'THIN MARKET'
      : 'FAIL';

    const discardCounts: Record<string, number> = {};
    for (const d of discards) {
      discardCounts[d.reason] = (discardCounts[d.reason] ?? 0) + 1;
    }
    const topDiscard = Object.entries(discardCounts).sort((a, b) => b[1] - a[1])[0];

    let resultMsg = `\n[RESULT] ${resultLabel}`;
    if (resultLabel !== 'PASS') {
      if (verifiedCount === 0) {
        resultMsg += ` — No verified results found.`;
      } else {
        resultMsg += ` — Only ${verifiedCount} verified result${verifiedCount === 1 ? '' : 's'} found.`;
      }
      if (topDiscard) {
        resultMsg += ` Top discard reason: ${topDiscard[0]} (${topDiscard[1]}).`;
        if (topDiscard[0] === 'Wrong category') {
          resultMsg += ` Check the category filter for this vertical.`;
        } else if (topDiscard[0] === 'No website') {
          resultMsg += ` Most businesses in this vertical may not have a website.`;
        } else if (topDiscard[0] === 'Geo mismatch') {
          resultMsg += ` Many results were outside the target city.`;
        } else if (topDiscard[0] === 'Domain chain' || topDiscard[0] === 'Name chain') {
          resultMsg += ` Many results appear to be franchises or chains.`;
        }
      }
      if (_hadMarketRealityWarning) {
        resultMsg += ` This may be a thin market or niche vertical.`;
      }
    } else {
      resultMsg += ` — ${verifiedCount} verified results. Ready to use.`;
    }

    if (resultLabel === 'PASS') {
      console.log(`\x1b[32m${resultMsg}\x1b[0m`);
    } else if (resultLabel === 'PARTIAL' || resultLabel === 'THIN MARKET') {
      console.log(`\x1b[33m${resultMsg}\x1b[0m`);
    } else {
      console.log(`\x1b[31m${resultMsg}\x1b[0m`);
    }

    logRun({
      site: config.site,
      city: config.city,
      vertical: config.vertical,
      totalScraped: _totalScraped,
      totalCandidates: _totalCandidates,
      verified: _verifiedCount,
      hadMarketRealityWarning: _hadMarketRealityWarning,
      discardLogPath: _discardLogPath,
      discards: getDiscards(),
      listings: verified,
    });
  } catch (err) {
    // Set exitCode (don't call process.exit) so the finally block still runs and
    // closes the browser — process.exit() would skip it and orphan chrome.exe.
    if (err instanceof CaptchaError) {
      console.error(`\n[ERROR] ${err.message}`);
      process.exitCode = 1;
    } else if (err instanceof GeocodeError) {
      console.error(`\n[ERROR] ${err.message}`);
      process.exitCode = 1;
    } else if (err instanceof SelectorBrokenError) {
      console.error(
        `\n[ERROR] All selectors failed — possible Google Maps UI update. ` +
        `Check selector-drift.log and update selectors before next run.`
      );
      // Fail LOUDLY: a broken-selector run must not look like a successful empty
      // run. Print a FAIL marker, exit non-zero, and log the run so the breakage
      // reaches the baseline report and the daily email — that monitoring is the
      // whole point of detecting a Google layout change.
      console.log(`\n[RESULT] FAIL — selectors broken (possible Google Maps layout change). No results produced.`);
      const emptyOutputPath = await writeCsv([], config);
      console.log(`Empty CSV written to: ${emptyOutputPath}`);
      logRun({
        site: config.site,
        city: config.city,
        vertical: config.vertical,
        totalScraped: _totalScraped,
        totalCandidates: _totalCandidates,
        verified: 0,
        hadMarketRealityWarning: false,
        discardLogPath: _discardLogPath,
        discards: getDiscards(),
        listings: [],
      });
      process.exitCode = 1;
    } else {
      console.error('\n[ERROR] Unexpected error:', err);
      process.exitCode = 1;
    }
  } finally {
    try { await context.close(); } catch {}
    try { await browser.close(); } catch {}
  }
}

main();

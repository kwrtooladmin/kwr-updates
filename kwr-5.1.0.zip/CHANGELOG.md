# KWR Selector — Changelog

## Version 5.1.0 — Accuracy tuning (June 2026)

Targeted accuracy improvements driven by a full re-run of the baseline (58 runs) and independent verification of every result. The headline change is a new treatment-keyword gate that fixes a whole class of wrong-result problems no category rule could solve.

### Treatment-keyword gate (verifier)

Some verticals name a *procedure*, not a business type — "HIFU" is the clearest example. Every med spa matches the Google Maps category, so the category filter can't tell which ones actually offer the procedure, and name-based exclusions become endless whack-a-mole (block five spas, the next search returns five more).

The verifier now checks the business's own website for the procedure:

- For treatment-gated verticals, a **readable** page that never mentions the procedure (or an accepted synonym) is dropped automatically. HIFU accepts: `hifu`, `high-intensity focused ultrasound`, `ultherapy`, `ultraformer`, `ultracel`, `sygmalift`.
- **Conservative by design.** The gate only acts on positive evidence of *absence*. Sites that can't be read (bot-blocked, JS-rendered) keep the existing benefit-of-the-doubt, so a genuine provider on a Wix/Squarespace/Cloudflare site is never lost.
- **Name/category signal honoured.** A business that advertises the procedure in its own name or Google listing is kept even if its site is JS-rendered and the page copy can't be read.
- Adding a new treatment vertical (e.g. CoolSculpting, Morpheus8) is now a one-line entry — no code change.

On Calgary HIFU this moved results from 1-of-8 genuine to a clean set with zero real providers lost. Remaining edge cases (a site that mentions the word without offering the service) are left for human review rather than chased with more rules.

### Category & name filter tuning (from verification mismatch data)

Name/category exclusions added so these stop appearing in results:

- **Property Lawyer:** personal-injury, estate-planning, wills & trusts, civil-litigation and trial firms (incl. specific repeat offenders surfaced in testing)
- **Violin / Guitar Lesson:** music/instrument stores, named voice/piano studios, luthiers and guitar workshops, performer-only acts
- **Mold Inspection:** mold remediation, water-damage and restoration firms, waterproofers (these *do* the work but are not inspectors)
- **Deep Cleaning:** carpet/upholstery-only, commercial/office-only cleaners
- **Yoga Studios:** meditation/mindfulness-only studios
- **Singing Lesson:** speech/drama coaching, instrument-only schools
- **Cremation:** pet cremation and will-writing/funeral-plan services
- **Furnace Repair:** AC-only contractors

### Fix: name exclusions were being bypassed for mapped verticals

Vertical exclusions placed in the category-exclusion list were skipped whenever a business's Google Maps category matched the vertical's inclusion list (e.g. a med spa under HIFU). Business-name exclusions are now evaluated before the category-inclusion shortcut, so they apply regardless of category match.

---

## Version 5.0.0 — V5 (June 2026)

The V5 release — everything since V4 in one update, plus a new self-update system. This is the **last manual install**: from here on, updates are delivered automatically and applied with one click. V5 also incorporates a full independent code audit (correctness + security fixes below).

### Correctness & security (from the V5 code audit)

- **Geographic filtering now actually works.** The city filter previously passed every listing, so the `--radius` distance check never ran and out-of-city businesses could ship. The coordinate-based radius check is now the real gate.
- **Non-Latin markets no longer gutted.** Business names in Thai, Vietnamese, Chinese, etc. were being stripped to nothing, grouped together, and discarded as a fake "franchise." Names of every script are now preserved, so Bangkok/Hanoi/HCMC runs keep their real businesses.
- **Freely-typed verticals work.** A vertical not in the built-in map (e.g. "italian restaurant") was reproducibly failing because global exclusions ran anyway. A direct term match now runs first.
- **Broken-layout runs fail loudly.** If Google changes its page layout, the run now reports FAIL and logs it (reaching the daily email) instead of silently looking like a successful empty run.
- **Spreadsheet formula injection blocked.** A malicious business name like `=cmd|...` can no longer execute when the CSV/Excel output is opened.
- **Network safety.** The verifier can no longer hang or run out of memory on a hostile page (reads are size- and time-capped), won't fetch internal/private addresses (SSRF guard), and the local web UI rejects cross-site commands.
- **Reliability.** Browser processes always close after an error (no orphaned Chrome), mid-scrape CAPTCHAs are detected, listings with quotes in their name are no longer skipped, concurrent batches are rejected, and the daily email parses cities containing commas correctly.

### Automatic updates (new)

- On launch the tool checks for a newer version and shows an **"Update now"** banner when one exists. One click downloads the update, verifies its checksum, backs up the current install, swaps in the new files, and restarts — your `.env`, results, and history are preserved. If anything fails mid-update, it rolls back automatically to the previous version.
- Updates never run during an active scrape, never overwrite your settings, and skip reinstalling dependencies when they haven't changed (so most updates apply in seconds).

### QA / reporting isolation (new)

- A machine carrying a `.qa-mode` marker file never sends the daily email report, keeping a tester's runs out of the real reporting. The marker is excluded from published builds, so distributed copies always report normally.

### Website verification hardening (all verticals)

- **Dead sites no longer count as verified.** A site whose domain no longer resolves or refuses connections is dropped (`Dead website` in the discard log) instead of being trusted on the strength of its Google Maps listing. Timeouts still get the benefit of the doubt, since a slow site is not a dead one.
- **Hijacked-domain protection.** If a business URL redirects to a *different* domain (common when a domain expires and is bought by spammers), the destination must positively pass content checks — all trust shortcuts are forfeited. Failures are dropped as `Off-domain redirect`.
- **Parked-domain and broader spam detection.** The spam check now catches "domain for sale" / expired-domain parking pages (HugeDomains, Sedo, GoDaddy auctions) and scans visible page text, not just the title. Legitimate businesses mentioning e.g. "casino night events" are unaffected — body-text spam requires 3+ distinct keyword hits.

### Vertical filter tuning (from verifier mismatch data)

Name exclusions added so these no longer appear in results:

- **Deck Builder:** handyman/home-maintenance outfits, marine construction, docks, seawalls, enclosures/pergolas
- **Magician:** food businesses ("Magic Waffle"), photo booth / magic mirror hire, princess-party character entertainment
- **Property Lawyer:** elder law, personal injury, family law, criminal, divorce, DWI, accident firms, online wills platforms
- **Probate Lawyer:** conveyancing, business/corporate law, litigation, personal injury, criminal, immigration firms
- **Wedding Planners:** palazzo/palace/villa venues (venues are not planners)
- **Violin/Guitar Lesson:** performers (quartets, orchestras, symphonies), luthiers, school-of-rock-style band programs

---

## Version 5.0 foundation — Web UI & reporting (June 2026)

These capabilities are part of the V5.0.0 release above. They introduced the full web UI and reporting infrastructure, making the tool accessible to non-technical users and giving the admin team daily visibility into run results without manual checking.

---

### Web UI

The tool now has a browser-based interface. Non-technical users can run searches, watch live progress, download results, and view run history — all without opening a terminal.

- Double-click **`Launch KWR.vbs`** to start. The browser opens automatically.
- Fill in Site, City, and Vertical for each search. Queue multiple runs and start them all at once.
- Live Log tab streams real-time output as the tool works.
- Results tab shows a card for each completed run with its status badge (Pass, Partial, Thin Market, Fail, Stopped), verified result count, top discard reason, and download buttons for CSV and discard log.
- Run History is saved locally and persists between sessions.
- Shut Down button closes the server cleanly when done.

---

### Daily email report

A scheduled task runs silently at 7AM every day and emails a summary of the previous day's runs to the admin. The email includes pass rate, week-over-week comparison, a per-run breakdown, and four CSV attachments (baseline report, summary, discards, and verified results).

- If the machine was off at 7AM, the report sends automatically on next login.
- No action required from the user — the task is registered on first launch.

---

### Run result summary line

At the end of every run, the tool prints a plain-English result line in the live log:

- Green for Pass: `[RESULT] PASS — 7 verified results. Ready to use.`
- Amber for Partial/Thin Market: `[RESULT] PARTIAL — Only 3 verified results found. Top discard reason: Wrong category (12). Check the category filter for this vertical.`
- Red for Fail: `[RESULT] FAIL — No verified results found. Top discard reason: No website (8). Most businesses in this vertical may not have a website.`

---

### Category filter — medical and cosmetic verticals

30+ new medical and cosmetic verticals added with precision category rules:

- Allied health: chiropractor, acupuncture, optometrist, audiologist, podiatrist, orthopedic surgeon
- General medicine: GP / family doctor, pediatrician, cardiologist, neurologist, dermatologist, endocrinologist, urologist, psychiatrist, psychologist
- Cosmetic and plastic surgery: plastic surgeon, liposuction, rhinoplasty, breast augmentation, tummy tuck, facelift, blepharoplasty, CoolSculpting, ultherapy, thread lift

Each vertical has exclusion rules to prevent dental, veterinary, and unrelated medical clinics from slipping through.

---

### Bug fixes

**Multi-word vertical truncation** — vertical names containing a space (e.g. "General Practitioner", "Personal Injury Lawyer") were being truncated to the first word only due to a Windows shell quoting issue. Fixed — all multi-word verticals now pass through correctly.

**Batch stops after 2 runs** — related to the multi-word truncation bug. A malformed argument on the 3rd run caused the process to exit immediately, breaking the batch loop. Fixed alongside the quoting fix.

---

### Upgrading from V4

1. Replace your existing project folder with the new V5 folder.
2. Open PowerShell in the new folder and run: `npm install`
3. Run the browser installer again: `npx playwright install chromium`
4. Your existing `.env` settings carry over — no changes needed.

---

## Version 4.0 — June 2026

This update closes all remaining failures identified in the V3 independent review conducted by Madelline Ann. If you are upgrading from V3 or V3.1, this version addresses the specific businesses that were previously missing or returning blank fields.

---

### What was fixed

**Businesses with active websites being silently discarded (WordPress and Wix)**
4 businesses with real websites were not appearing in results at all. The root cause was two distinct issues. WordPress sites have very large page headers that exceed the tool's content fetch limit, so navigation links in the page body were never reached and the site was incorrectly flagged as empty. Wix sites store navigation links in a non-standard attribute called data-href instead of the standard href — the tool was not scanning this and counting zero links. Both are now detected and handled correctly. Genuinely empty or spam sites are unaffected.

Affected businesses now confirmed working: Dals (Manchester), NTIS UK (Manchester), Sworn Translator Edyta (Manchester), Appliance Technician (Ottawa).

**Businesses with no website returning blank fields**
When a business had no website the tool was leaving the website field completely blank. The content team had no link to reference at all. The tool now checks the Google Maps listing for a social media URL or Google Maps link and outputs that instead, so the content team always has something to work with. A Website Status column and Reference URL column have been added to the CSV output.

Affected businesses now confirmed working: Latin Dance Edinburgh (Instagram URL output), Saigon Memoire Edinburgh (Google Maps URL output).

**Business skipped due to name mismatch between Google Maps and website**
One business was being skipped because its name on Google Maps did not match the name displayed on its website. The tool was relying on name string matching to confirm a business — when the names differed it skipped the business entirely. The tool now checks whether the website is real and working by looking for a real page title, meta description, and contact information. If all three are present the business passes regardless of name difference.

Affected business now confirmed working: Maths Vella Bonello Private Lessons (Malta).

**Vietnam and Thailand language support**
Flagged as the next major challenge in the V3 review. Confirmed already working through prior testing across multiple Vietnam and Thailand verticals. No additional fix was required.

---

### New CSV columns

Two new columns have been added to the output spreadsheet:

| Column | Values | What it means |
|--------|--------|---------------|
| `Website Status` | verified, unverified, social_only, maps_only, none | Where the link in Reference URL came from |
| `Reference URL` | URL | Best available link — website first, then social media, then Google Maps |

---

### Web UI

A browser-based interface has been added so non-technical users can run the tool without touching the terminal.

- Double-click **`Launch KWR.vbs`** (Windows) or **`Launch KWR (Mac).command`** (Mac) to start
- Fill in Site, City, and Vertical — type freely or pick from the dropdown suggestions
- Queue multiple searches and run them all in sequence with a 5-minute cooldown between each
- Live log streams real-time output from the tool as it runs
- Results appear as cards with **↓ CSV** and **↓ Excel** download buttons when each run completes
- Run history is saved locally and persists between sessions
- Filter history by vertical or city
- Dark and light mode toggle — preference remembered between sessions
- Sound notification when a batch completes — mute toggle available

---

### Category filter improvements

Two verticals that previously returned zero results have been fixed:

**Vietnamese Restaurant** — Google Maps displays Vietnamese dong price ranges (`· ₫100–200K`) instead of a category label for restaurants in Vietnam. The `₫` symbol was not recognised as a price range indicator, causing all listings to be discarded as wrong category. Fixed. The `₫` symbol (and several other regional currency symbols) is now handled correctly.

**Furnace Repair** — Google Maps categorises all furnace and heating businesses as `HVAC contractor`, not `Furnace Repair`. The tool's direct-term match found no category match and discarded every result. Fixed by adding `furnace repair` to the category map with HVAC-related keywords.

---

### Baseline reporting

Every run now automatically appends a row to `baseline/baseline-report.csv` with the date, version, site, city, vertical, result count, pass/fail classification, and top discard reason. A summary file (`baseline/baseline-summary.csv`) is rebuilt after every run showing pass rates per vertical over time. This requires no action from the team — logging happens automatically in the background.

---

### Upgrading from V3 or V3.1

If you already have V3 or V3.1 installed, you do not need to reinstall Node.js or set up your settings file again. To upgrade:

1. Replace your existing project folder with the new V4 folder.
2. Open PowerShell in the new folder and run: `npm install`
3. Run the browser installer again: `npx playwright install chromium`
4. Your existing `.env` settings carry over — no changes needed.

---

## Version 3.1 — May 2026

This update focuses on improving result accuracy and removing false positives that were
causing legitimate businesses to be missed and wrong businesses to appear in results.

---

### What was fixed

**Wrong businesses appearing in results**
The tool now checks the business type of every result against what was searched. Before
this fix, searches were returning completely unrelated businesses — a security company
search returned a crypto hardware wallet seller, a mattress search returned hostels, and
naturopath searches returned dental clinics. The tool now reads the Google Maps business
category label and removes anything that does not match the vertical being searched.

**Legitimate businesses being wrongly removed**
Some real business websites block automated access as a security measure. The tool was
treating these blocked pages as empty sites and discarding the business. A well-known
Vietnamese law firm was being removed for this reason. Fixed — the tool now recognises
when a site is blocking automated access and keeps the business using the Google listing
as confirmation instead.

**Wrong business type slipping through by name**
Businesses were passing the category filter even when their name made it obvious they
were the wrong type. Fixed — the filter now checks the business name as well as the
Google Maps category label.

**Category scraper reading wrong text**
The tool was sometimes reading the star rating or review count off a business card
instead of the actual business type. Fixed — it now correctly identifies the business
type before deciding whether to include it.

**False broken selector warning every run**
Every run was logging a warning saying two parts of the tool were broken. They were never
actually broken — the tool was checking for them before the page they belong to had even
loaded. Fixed — the false warning is gone.

**Moving company searches returning wrong businesses**
Searches for movers were returning self-storage facilities, tourist bus operators, and
tour companies. Fixed — storage facilities, tour operators, and bus companies are now
excluded from mover searches. Legitimate movers including businesses listed as moving
and storage services are allowed through.

---


---

### Known behaviour to be aware of

**Filter tier not shown in output**
The CSV output labels all results as either `primary` (top 5) or `backup` (next 3).
However not all primary listings meet the top-tier quality threshold. When a search
returns fewer high-quality results than needed, the tool automatically accepts lower-rated
businesses to fill the list. A primary listing could therefore come from one of three
quality levels:

| Quality Level | Rating | Reviews | What it means |
|---------------|--------|---------|---------------|
| Top rated | ≥4.5 stars | ≥100 reviews | Best available — highest confidence |
| Good rated | ≥4.0 stars | ≥30 reviews | Solid but fewer reviews — check before publishing |
| Best available | Any | Any | Thin market — limited options, manual review recommended |

**How to check:** The Rating and Review Count columns are always included in the CSV.
Check these columns before publishing — if a primary listing has a rating below 4.5 or
fewer than 100 reviews, it came from the fallback tier and should be reviewed carefully.

This will be addressed in a future version by adding a Quality Level column to the output
so the tier is visible at a glance.

### Known limitations

- **Painting Service** — this vertical name is too broad. Google Maps returns art
  galleries, pottery studios, and nail bars instead of trade painters. A more specific
  vertical name such as "House Painter" or "Exterior Painting Contractor" is recommended.

- **Home Inspection in Vietnam** — home inspection does not exist as a formal
  professional service in Vietnam. Searches return zero results. This vertical is not
  suitable for the Vietnamese market.

- **Shortened links on Google listings** — shortened URLs such as bit.ly are now automatically resolved to the real website address before verification. This was fixed in V3.1.

- **Niche verticals** — for highly specialised verticals such as medical sub-specialties
  or specific legal niches, Google Maps may return related but not identical business
  types. A manual review of results is recommended for these verticals.

- **Thin markets** — in cities or markets where very few businesses exist for a given
  vertical, the tool may return only one or two results or none at all. This is expected
  behaviour and reflects the reality of the market.

---

### Tested markets in this version

Batch testing completed across Vietnam (Hanoi, Ho Chi Minh), Thailand (Bangkok),
Australia (Sydney, Melbourne, Brisbane, Canberra), UK (Edinburgh, Liverpool),
Canada (Montreal, Halifax, Toronto), USA (Phoenix, Dallas), Hong Kong, Winnipeg,
Malta, and El Paso / Philadelphia (on hold pending site confirmation).

---

### How to run

```
npm run dev -- --site YOURSITE.com --city "Your City" --vertical "business type"
```

See README.md for full setup and usage instructions.

﻿Set-Location 'C:\Users\User\Desktop\KWR_Tool_WORK HERE'
Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-fix4-verify.log' "[$(Get-Date -f 'HH:mm:ss')] RUN Calgary HIFU (treatment gate)"
npm run dev -- --site blueskycalgary.com --city "Calgary" --vertical "Hifu"
Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-fix4-verify.log' "ALL DONE $(Get-Date)"

"""
Merges fix-verification run results into the main baseline report.
For each affected vertical, replaces the OLD baseline entry with the NEW one,
and replaces the OLD output CSV with the NEW one.
Run after the fix-verify batch completes.
"""
import csv, os, shutil, re
from datetime import datetime

WORK_DIR = r"C:\Users\User\Desktop\KWR_Tool_WORK HERE"
OUTPUT_DIR = os.path.join(WORK_DIR, "output")
BASELINE = os.path.join(WORK_DIR, "baseline", "baseline-report-PapupHouse.csv")

# Verticals re-run in the fix batch (normalised lower)
FIX_VERTICALS = {
    ("blueskycalgary.com",        "calgary",      "hifu"),
    ("toronto-travel-guide.com",  "toronto",      "mold inspection"),
}

def key(row):
    return (
        row.get("Site","").lower().strip(),
        row.get("City","").lower().strip(),
        row.get("Vertical","").lower().strip(),
    )

# --- 1. Read baseline ---
with open(BASELINE, encoding="utf-8", newline="") as f:
    reader = csv.DictReader(f)
    fieldnames = reader.fieldnames
    all_rows = list(reader)

# Split into rows to keep and rows to replace
keep_rows = []
replaced = set()
for row in all_rows:
    k = key(row)
    if k in FIX_VERTICALS:
        replaced.add(k)
        # skip — will be replaced by new rows
        print(f"  Removing old: {row['Run ID']} | {row['Site']} | {row['City']} | {row['Vertical']}")
    else:
        keep_rows.append(row)

# Find new rows (today's fix-verify runs — latest timestamp per vertical key)
today = datetime.now().strftime("%Y-%m-%d")
new_rows = []
for row in all_rows:
    if row.get("Date","") == today and key(row) in FIX_VERTICALS:
        new_rows.append(row)

# If new rows aren't in all_rows yet, re-read baseline fresh
if not new_rows:
    with open(BASELINE, encoding="utf-8", newline="") as f:
        all_rows2 = list(csv.DictReader(f))
    for row in all_rows2:
        if row.get("Date","") == today and key(row) in FIX_VERTICALS:
            new_rows.append(row)

# Deduplicate new rows: keep latest per (site, city, vertical)
seen = {}
for row in new_rows:
    k = key(row)
    seen[k] = row  # last one wins
new_rows = list(seen.values())

print(f"\nReplacing {len(replaced)} old vertical entries with {len(new_rows)} new ones.")

# Re-number Run IDs sequentially
combined = keep_rows + new_rows
combined_sorted = sorted(combined, key=lambda r: int(re.sub(r"\D","", r.get("Run ID","0")) or 0))

# Re-assign clean sequential IDs
for i, row in enumerate(combined_sorted, 1):
    row["Run ID"] = f"RUN-{i:03d}"

# Write back
with open(BASELINE, "w", encoding="utf-8", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(combined_sorted)

print(f"Baseline updated: {len(combined_sorted)} total rows.")

# --- 2. Summary ---
passes   = sum(1 for r in combined_sorted if r.get("Result") == "PASS")
partials = sum(1 for r in combined_sorted if r.get("Result") == "PARTIAL")
fails    = sum(1 for r in combined_sorted if r.get("Result") == "FAIL")
total    = len(combined_sorted)
print(f"\n=== UPDATED BASELINE SUMMARY ===")
print(f"Total : {total}")
print(f"PASS  : {passes}  ({passes/total*100:.1f}%)")
print(f"PARTIAL: {partials} ({partials/total*100:.1f}%)")
print(f"FAIL  : {fails}  ({fails/total*100:.1f}%)")
print(f"Pass+Partial: {passes+partials} ({(passes+partials)/total*100:.1f}%)")

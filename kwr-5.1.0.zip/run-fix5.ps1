﻿Set-Location 'C:\Users\User\Desktop\KWR_Tool_WORK HERE'
npm run dev -- --site blueskycalgary.com --city "Calgary" --vertical "Hifu"
Add-Content 'C:\Users\User\Desktop\KWR_Tool_WORK HERE\batch-fix5.log' "ALL DONE $(Get-Date)"

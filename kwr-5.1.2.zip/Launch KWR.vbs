Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

' Get the folder where this VBS file lives
strDir = objFSO.GetParentFolderName(WScript.ScriptFullName)

' Run npm run ui silently (no terminal window)
objShell.Run "cmd /c cd /d """ & strDir & """ && npm run ui", 0, False

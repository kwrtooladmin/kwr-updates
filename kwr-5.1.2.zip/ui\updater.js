'use strict';

// Standalone self-updater. Launched DETACHED by server.js, then the server exits.
// Because it runs as its own process, it can safely overwrite the application
// files that the (now-exited) server was using.
//
// Usage (all args absolute paths):
//   node updater.js <installDir> <newVersionDir> <backupDir> <port> [workDir]
//
// Stability guarantees:
//   1. Full backup of current code before any file is touched (rollback source).
//   2. Waits for the server port to free up so no files are locked.
//   3. Copies are non-destructive (robocopy without /MIR) and skip user data.
//   4. npm install runs ONLY if dependencies changed.
//   5. Any failure during the swap restores from backup automatically.
//   6. Only the most recent backup is kept; older ones are pruned on success.

const fs = require('fs');
const path = require('path');
const net = require('net');
const crypto = require('crypto');
const { execFileSync, spawn } = require('child_process');

const [installDir, newVersionDir, backupDir, portArg, workDir] = process.argv.slice(2);
const PORT = parseInt(portArg, 10) || 3000;
const LOG = path.join(installDir, 'ui', 'update.log');

function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}\n`;
  try { fs.appendFileSync(LOG, line); } catch {}
}

// Directories/files that hold USER DATA — never overwritten or deleted.
const EXCLUDE_DIRS = ['node_modules', 'output', 'baseline', '.git'];
const EXCLUDE_FILES = ['.env', 'run-history.json', 'update.log'];

// robocopy exit codes 0-7 are success (8+ are real failures).
function robocopy(src, dst, extraArgs = []) {
  const args = [src, dst, '/E', '/NFL', '/NDL', '/NJH', '/NJS', '/NP', '/R:2', '/W:2', ...extraArgs];
  try {
    execFileSync('robocopy', args, { stdio: 'ignore' });
    return 0;
  } catch (err) {
    const code = err.status ?? 16;
    if (code < 8) return code; // success range
    throw new Error(`robocopy failed (${code}): ${src} -> ${dst}`);
  }
}

function waitForPortFree(port, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  return new Promise((resolve) => {
    const probe = () => {
      const sock = net.connect(port, '127.0.0.1');
      sock.on('connect', () => {
        sock.destroy();
        if (Date.now() > deadline) { resolve(false); return; }
        setTimeout(probe, 500); // still up — wait
      });
      sock.on('error', () => { sock.destroy(); resolve(true); }); // refused = free
    };
    probe();
  });
}

function depHash(pkgPath) {
  try {
    const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8').replace(/^﻿/, ''));
    // Sort keys so formatting / key-order differences don't read as a change.
    const sortObj = (o) => Object.keys(o || {}).sort().reduce((a, k) => { a[k] = o[k]; return a; }, {});
    const deps = JSON.stringify({ d: sortObj(pkg.dependencies), e: sortObj(pkg.devDependencies) });
    return crypto.createHash('sha256').update(deps).digest('hex');
  } catch { return null; }
}

async function main() {
  log('Updater started.');
  log(`install=${installDir}`);
  log(`newVersion=${newVersionDir}`);

  const free = await waitForPortFree(PORT);
  log(free ? 'Server port is free.' : 'Port still busy after timeout — proceeding anyway.');
  // Small grace period for OS file handles to release.
  await new Promise((r) => setTimeout(r, 1500));

  const oldDepHash = depHash(path.join(installDir, 'package.json'));

  // 1. Backup current code (for rollback).
  try {
    log('Backing up current install...');
    const excludeArgs = [
      '/XD', ...EXCLUDE_DIRS.map((d) => path.join(installDir, d)),
      backupDir, newVersionDir, '.update-backup-*',
      '/XF', ...EXCLUDE_FILES,
    ];
    robocopy(installDir, backupDir, excludeArgs);
    log('Backup complete.');
  } catch (err) {
    log(`Backup FAILED: ${err.message}. Aborting update — no files changed.`);
    relaunch();
    process.exit(1);
  }

  // 2. Swap in new files (non-destructive; user data untouched).
  try {
    log('Applying new version...');
    const excludeArgs = ['/XF', ...EXCLUDE_FILES];
    robocopy(newVersionDir, installDir, excludeArgs);
    log('Files applied.');
  } catch (err) {
    log(`Apply FAILED: ${err.message}. Rolling back...`);
    rollback();
    relaunch();
    process.exit(1);
  }

  // 3. Conditional npm install.
  const newDepHash = depHash(path.join(installDir, 'package.json'));
  if (oldDepHash !== newDepHash) {
    try {
      log('Dependencies changed - running npm install...');
      // shell:true is required on Windows to invoke npm.cmd (else EINVAL).
      execFileSync('npm', ['install', '--no-audit', '--no-fund'], {
        cwd: installDir, stdio: 'ignore', shell: true,
      });
      log('npm install complete.');
    } catch (err) {
      log(`npm install FAILED: ${err.message}. Rolling back...`);
      rollback();
      // A failed install can leave node_modules half-changed. Reconcile it back
      // to the (now restored) old package.json so the tool still starts.
      try {
        log('Reconciling node_modules to the previous version...');
        execFileSync('npm', ['install', '--no-audit', '--no-fund'], {
          cwd: installDir, stdio: 'ignore', shell: true,
        });
        log('Reconcile complete - previous version is runnable.');
      } catch (err2) {
        log(`Reconcile FAILED: ${err2.message}. If the tool will not start, run "npm install" in the tool folder manually.`);
      }
      relaunch();
      process.exit(1);
    }
  } else {
    log('Dependencies unchanged - skipping npm install.');
  }

  pruneOldBackups();
  cleanupTemp();
  log('Update successful. Relaunching tool.');
  relaunch();
  process.exit(0);
}

// Keep only the backup from THIS update; remove any older ones so they can't
// accumulate (and can't nest into future backups).
function pruneOldBackups() {
  try {
    const parent = path.dirname(backupDir);
    const keep = path.basename(backupDir);
    for (const name of fs.readdirSync(parent)) {
      if (name.startsWith('.update-backup-') && name !== keep) {
        fs.rmSync(path.join(parent, name), { recursive: true, force: true });
      }
    }
  } catch (err) { log(`Backup prune skipped: ${err.message}`); }
}

// Remove the temp working directory (downloaded zip + extracted tree).
function cleanupTemp() {
  try {
    if (workDir && fs.existsSync(workDir)) {
      fs.rmSync(workDir, { recursive: true, force: true });
    }
  } catch (err) { log(`Temp cleanup skipped: ${err.message}`); }
}

function rollback() {
  try {
    robocopy(backupDir, installDir, ['/XF', ...EXCLUDE_FILES]);
    log('Rollback complete - previous version restored.');
  } catch (err) {
    log(`Rollback FAILED: ${err.message}. Backup is at: ${backupDir}`);
  }
}

function relaunch() {
  try {
    // Reuse the same port so the already-open browser tab reconnects, and
    // suppress auto-opening a second tab (the existing one reloads itself).
    const env = { ...process.env, KWR_PORT: String(PORT), KWR_NO_OPEN: '1' };
    const vbs = path.join(installDir, 'Launch KWR.vbs');
    if (process.platform === 'win32' && fs.existsSync(vbs)) {
      const child = spawn('wscript', [vbs], { cwd: installDir, detached: true, stdio: 'ignore', env });
      child.unref();
    } else {
      const child = spawn('npm', ['run', 'ui'], {
        cwd: installDir, detached: true, stdio: 'ignore', shell: true, env,
      });
      child.unref();
    }
    log('Relaunch issued.');
  } catch (err) {
    log(`Relaunch FAILED: ${err.message}. User must start the tool manually.`);
  }
}

main().catch((err) => {
  log(`Updater crashed: ${err.stack || err.message}`);
  process.exit(1);
});

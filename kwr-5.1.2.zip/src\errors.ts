export class CaptchaError extends Error {
  constructor(message = 'CAPTCHA detected — try a residential proxy') {
    super(message);
    this.name = 'CaptchaError';
  }
}

export class GeocodeError extends Error {
  constructor(city: string) {
    super(`Failed to geocode "${city}" — check city spelling and try again`);
    this.name = 'GeocodeError';
  }
}

export class SelectorBrokenError extends Error {
  selectorName: string;
  constructor(selectorName: string) {
    super(`Selector broken and all fallbacks failed: ${selectorName}`);
    this.name = 'SelectorBrokenError';
    this.selectorName = selectorName;
  }
}

export class ScrollStallError extends Error {
  constructor() {
    super('Scroll stalled — reached end of results or Google pagination limit');
    this.name = 'ScrollStallError';
  }
}

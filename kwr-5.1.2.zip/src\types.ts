export interface CliArgs {
  site: string;
  city: string;
  vertical: string;
  allowCountry: boolean;
  lang?: string;
  radius: number;
}

export interface AppConfig extends CliArgs {
  minRating: number;
  minReviews: number;
  fallbackMinRating: number;
  fallbackMinReviews: number;
  targetResults: number;
  maxScrollAttempts: number;
  targetListingCount: number;
  discoveryCount: number;
  viewportWidth: number;
  viewportHeight: number;
  headless: boolean;
  outputPath: string;
  minCandidates: number;
}

export interface GeoLocation {
  lat: number;
  lng: number;
  zoom: number;
  locationType: 'country' | 'region' | 'city';
}

export interface RawListing {
  name: string;
  rating: number | null;
  reviewCount: number | null;
  cardElement: string;  // aria-label selector for Phase 2 re-location
  positionIndex: number;
  category: string | null;
  filterTier?: 'Top rated' | 'Good rated' | 'Best available';
  listingUrl?: string | null;  // Google Maps sidebar card URL
}

export interface EnrichedListing extends RawListing {
  websiteUrl: string | null;
  websiteVerified: boolean;
  address: string | null;   // full address text from detail panel
  cityMatch: boolean;       // true if address contains target city name (or address unavailable)
  lat?: number;
  lng?: number;
  socialUrl?: string | null;  // social media URL from GMB listing (fallback when no website)
  mapsUrl?: string | null;    // Google Maps place URL (last-resort reference)
}

export interface ScoredListing extends EnrichedListing {
  score: number;  // rating * ln(reviewCount + 1)
}

export interface SelectorSet {
  sidebarFeed: string;
  listingCard: string;
  listingAnchor: string;
  businessName: string;
  ratingNumber: string;
  reviewCount: string;
  websiteInDetail: string;
  captchaIndicator: string;
}

import { chromium } from 'playwright-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import { Browser, BrowserContext } from 'playwright';
import { AppConfig } from './types';
import { randomUserAgent } from './humanize';

// Register stealth plugin once at module level
chromium.use(StealthPlugin());

export async function launchBrowser(config: AppConfig): Promise<Browser> {
  const browser = await (chromium as any).launch({
    headless: config.headless,
    args: [
      '--disable-blink-features=AutomationControlled',
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-accelerated-2d-canvas',
      '--no-first-run',
      '--no-zygote',
      '--disable-gpu',
    ],
  });
  return browser as Browser;
}

export async function createContext(
  browser: Browser,
  config: AppConfig
): Promise<BrowserContext> {
  const ua = randomUserAgent();

  const locale = config.lang ?? 'en-US';

  const context = await browser.newContext({
    userAgent: ua,
    viewport: { width: config.viewportWidth, height: config.viewportHeight },
    locale,
    timezoneId: 'America/Chicago',
    // No geolocation — let Google use IP
  });

  // Override automation signals
  await context.addInitScript(() => {
    Object.defineProperty(navigator, 'webdriver', {
      get: () => undefined,
    });
    Object.defineProperty(navigator, 'plugins', {
      get: () => [1, 2, 3],
    });
  });
  await context.addInitScript({
    content: `Object.defineProperty(navigator, 'languages', { get: () => ['${locale}', '${locale}'.split('-')[0]] });`
  });

  return context;
}

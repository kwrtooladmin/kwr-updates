#!/bin/bash

# Get the directory where this script lives
DIR="$(cd "$(dirname "$0")" && pwd)"

# Change to the project folder and start the UI
cd "$DIR"
npm run ui

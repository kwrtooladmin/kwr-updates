interface DiscardEntry {
  reason: string;
  name: string;
  url?: string;
}

const entries: DiscardEntry[] = [];

export function logDiscard(reason: string, name: string, url?: string): void {
  entries.push({ reason, name, url });
  const urlPart = url ? ` -> ${url}` : '';
  console.log(`  [DISCARDED: ${reason}] "${name}"${urlPart}`);
}

export function getDiscards(): DiscardEntry[] {
  return [...entries];
}

export function clearDiscards(): void {
  entries.length = 0;
}

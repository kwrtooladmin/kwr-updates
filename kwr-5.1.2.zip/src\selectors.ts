import { Page } from 'playwright';
import * as fs from 'fs';
import * as path from 'path';
import { SelectorBrokenError } from './errors';

export const PRIMARY_SELECTORS = {
  sidebarFeed: 'div[role="feed"]',
  listingCard: 'div.Nv2PK',
  listingAnchor: 'a.hfpxzc',
  businessName: 'div.qBF1Pd',
  ratingNumber: 'span.MW4etd',
  reviewCount: 'span[aria-label*="review"]',
  businessCategory: 'div.W4Efsd div.W4Efsd span span',
  websiteInDetail: 'a[data-item-id="authority"]',
  addressInDetail: 'button[data-item-id="address"]',
  captchaIndicator: 'form#captcha-form',
} as const;

export const FALLBACK_CHAINS: Record<string, string[]> = {
  sidebarFeed: [
    'div[role="feed"]',              // primary — confirmed live 2026-05-06
    '[aria-label*="Results for"]',   // label-based fallback
    'div.m6QErb[aria-label]',        // Maps result pane class (more stable than jstcache)
    'div[jstcache] > div > div',     // legacy last-resort
  ],
  listingCard: ['div.Nv2PK', 'div[jsaction*="mouseover:pane"]', 'div[data-result-index]'],
  listingAnchor: ['a.hfpxzc', 'a[jsaction*="click:pane"]', 'a[href*="/maps/place/"]'],
  businessName: ['div.qBF1Pd', 'span[class*="fontHeadlineSmall"]', 'div[class*="fontHeadline"]'],
  ratingNumber: ['span.MW4etd', 'span[class*="fontBodyMedium"] > span', 'span[aria-hidden="true"]'],
  businessCategory: ['div.W4Efsd div.W4Efsd span span', 'div.W4Efsd span span', 'span.fontBodyMedium span'],
  reviewCount: ['span[aria-label*="review"]', 'span.UY7F9', 'span[class*="fontBodyMedium"]:nth-child(2)'],
  websiteInDetail: [
    'a[data-item-id="authority"]',
    'a[aria-label="Website"]',
    'a[aria-label*="website" i]',
    'a[data-tooltip="Open website"]',
    'a[jsaction*="pane.heroHeaderImage.website"]',
  ],
  addressInDetail: [
    'button[data-item-id="address"]',
    'button[aria-label*="ddress"]',
    'div[data-item-id="address"]',
  ],
  captchaIndicator: ['form#captcha-form', 'iframe[src*="recaptcha"]', '#recaptcha'],
};

const DRIFT_LOG = path.resolve('./selector-drift.log');

function logDrift(message: string): void {
  const line = `[${new Date().toISOString()}] ${message}\n`;
  fs.appendFileSync(DRIFT_LOG, line);
}

/** Try a selector chain, returning the first one that finds elements */
export async function resolveSelector(
  page: Page,
  name: string,
  timeout = 3000
): Promise<string> {
  const chain = FALLBACK_CHAINS[name] ?? [PRIMARY_SELECTORS[name as keyof typeof PRIMARY_SELECTORS]];

  for (let i = 0; i < chain.length; i++) {
    const selector = chain[i];
    try {
      await page.waitForSelector(selector, { timeout, state: 'attached' });
      if (i > 0) {
        logDrift(`FALLBACK FIRED: "${name}" → used fallback[${i}]: "${selector}" (primary broken)`);
        console.warn(`  [selector] Using fallback for "${name}": ${selector}`);
      }
      return selector;
    } catch {
      // try next
    }
  }

  throw new SelectorBrokenError(name);
}

/** Validate all primary selectors, log any broken ones */
export async function validateSelectors(page: Page): Promise<void> {
  const selectorNames = Object.keys(PRIMARY_SELECTORS).filter(
    (k) => k !== 'captchaIndicator' && // don't expect CAPTCHA on normal pages
            k !== 'websiteInDetail' && // only present inside an open detail panel
            k !== 'addressInDetail'    // only present inside an open detail panel
  );

  for (const name of selectorNames) {
    const primary = PRIMARY_SELECTORS[name as keyof typeof PRIMARY_SELECTORS];
    try {
      await page.waitForSelector(primary, { timeout: 2000, state: 'attached' });
    } catch {
      logDrift(`BROKEN PRIMARY: "${name}" → "${primary}" not found on page`);
      console.warn(`  [selector] Primary selector broken: "${name}" (${primary})`);
    }
  }
}

/** Check if CAPTCHA is present */
export async function isCaptchaPresent(page: Page): Promise<boolean> {
  for (const sel of FALLBACK_CHAINS.captchaIndicator) {
    try {
      await page.waitForSelector(sel, { timeout: 1000, state: 'visible' });
      return true;
    } catch {
      // continue
    }
  }
  return false;
}

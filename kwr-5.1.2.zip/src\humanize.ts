import { Page } from 'playwright';

/** Sleep for a random duration between min and max milliseconds */
export function randomDelay(min: number, max: number): Promise<void> {
  const ms = Math.floor(Math.random() * (max - min) + min);
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** 20% chance of a longer "reading" pause (1.5–3s) */
export async function maybeReadingPause(): Promise<void> {
  if (Math.random() < 0.2) {
    await randomDelay(1500, 3000);
  }
}

/** Move mouse to element with human-like jitter before clicking */
export async function humanMove(
  page: Page,
  x: number,
  y: number
): Promise<void> {
  const jitterX = Math.floor(Math.random() * 8) - 4;
  const jitterY = Math.floor(Math.random() * 8) - 4;
  const steps = Math.floor(Math.random() * 8) + 5; // 5–12 steps
  await page.mouse.move(x + jitterX, y + jitterY, { steps });
  await randomDelay(100, 400);
}

/** Human-like scroll of a feed element by a random amount */
export async function humanScroll(
  page: Page,
  feedSelector: string
): Promise<void> {
  const amount = Math.floor(Math.random() * 400) + 300; // 300–700px
  await page.evaluate(
    ({ selector, scrollAmount }: { selector: string; scrollAmount: number }) => {
      const el = document.querySelector(selector);
      if (el) {
        el.scrollBy({ top: scrollAmount, behavior: 'smooth' });
      }
    },
    { selector: feedSelector, scrollAmount: amount }
  );
  await randomDelay(600, 3000);
  await maybeReadingPause();
}

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
];

export function randomUserAgent(): string {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

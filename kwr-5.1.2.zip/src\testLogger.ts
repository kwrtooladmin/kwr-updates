import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { EnrichedListing } from './types';

const OUTPUT_DIR = process.env.KWR_OUTPUT_DIR ?? './output';
const BASELINE_DIR = './baseline';
const MACHINE_NAME  = os.hostname();
const REPORT_PATH   = path.join(BASELINE_DIR, `baseline-report-${MACHINE_NAME}.csv`);
const SUMMARY_PATH  = path.join(BASELINE_DIR, `baseline-summary-${MACHINE_NAME}.csv`);
const DISCARDS_PATH = path.join(BASELINE_DIR, `baseline-discards-${MACHINE_NAME}.csv`);
const RESULTS_PATH  = path.join(BASELINE_DIR, `baseline-verified-results-${MACHINE_NAME}.csv`);

const REPORT_HEADERS = [
  'Run ID',
  'Date',
  'Version',
  'Machine',
  'Site',
  'City',
  'Vertical',
  'Total Scraped',
  'Total Candidates',
  'Verified',
  'Result',
  'Top Discard Reason',
  'Notes',
];

const DISCARDS_HEADERS = [
  'Run ID',
  'Date',
  'Vertical',
  'City',
  'Site',
  'Business Name',
  'Reason',
  'Maps URL',
];

const SUMMARY_HEADERS = [
  'Vertical',
  'Total Runs',
  'Pass',
  'Partial',
  'Thin Market',
  'Fail',
  'Pass Rate %',
  'Last Run Date',
];

export interface DiscardEntry {
  reason: string;
  name: string;
  url?: string;
}

const VERIFIED_RESULTS_HEADERS = [
  'Run ID',
  'Date',
  'Machine',
  'Site',
  'City',
  'Vertical',
  'Tier',
  'Business Name',
  'Rating',
  'Review Count',
  'Website URL',
  'Website Status',
  'Maps URL',
];

export interface RunStats {
  site: string;
  city: string;
  vertical: string;
  totalScraped: number;
  totalCandidates: number;
  verified: number;
  hadMarketRealityWarning: boolean;
  discardLogPath: string | null;
  discards?: DiscardEntry[];
  listings?: EnrichedListing[];
}

function getVersion(): string {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8'));
    return pkg.version ?? '?';
  } catch {
    return '?';
  }
}

function getNextRunId(): string {
  // Scan all baseline-report*.csv files to find the highest run number globally,
  // so the counter never resets when a new machine-named file is created.
  let maxNum = 0;
  try {
    const files = fs.readdirSync(BASELINE_DIR)
      .filter(f => f.startsWith('baseline-report') && f.endsWith('.csv'));
    for (const file of files) {
      const lines = fs.readFileSync(path.join(BASELINE_DIR, file), 'utf8')
        .split('\n').filter(Boolean).slice(1);
      for (const line of lines) {
        const id = parseCsvLine(line)[0] ?? '';
        const num = parseInt(id.replace('RUN-', ''), 10) || 0;
        if (num > maxNum) maxNum = num;
      }
    }
  } catch { /* baseline dir may not exist yet */ }
  return `RUN-${String(maxNum + 1).padStart(3, '0')}`;
}

function ensureDiscardsExists(): void {
  if (!fs.existsSync(DISCARDS_PATH)) {
    fs.writeFileSync(DISCARDS_PATH, DISCARDS_HEADERS.map(csvCell).join(',') + '\n');
  }
}

function writeDiscards(runId: string, date: string, stats: RunStats): void {
  if (!stats.discards || stats.discards.length === 0) return;
  ensureDiscardsExists();
  const rows = stats.discards.map(d =>
    [runId, date, stats.vertical, stats.city, stats.site, d.name, d.reason, d.url ?? '']
      .map(csvCell).join(',')
  );
  fs.appendFileSync(DISCARDS_PATH, rows.join('\n') + '\n');
}

function ensureReportExists(): void {
  if (!fs.existsSync(BASELINE_DIR)) {
    fs.mkdirSync(BASELINE_DIR, { recursive: true });
    // Hide the folder on Windows so users don't see or tamper with it
    if (process.platform === 'win32') {
      try {
        require('child_process').execSync(`attrib +h +s "${BASELINE_DIR}"`, { stdio: 'ignore' });
      } catch {}
    }
  }
  if (!fs.existsSync(REPORT_PATH)) {
    fs.writeFileSync(REPORT_PATH, REPORT_HEADERS.map(csvCell).join(',') + '\n');
  }
}

function csvCell(value: string | number): string {
  let str = String(value ?? '');
  // Neutralize spreadsheet formula injection (business names are attacker-controlled).
  if (/^[=+\-@\t\r]/.test(str)) str = `'${str}`;
  // Wrap in quotes if contains comma, quote, or newline
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

type DiscardReason =
  | 'Wrong category'
  | 'Thin content'
  | 'No website'
  | 'Domain chain'
  | 'Name chain'
  | 'Geo mismatch'
  | '';

function parseTopDiscardReason(discardLogPath: string | null): DiscardReason {
  if (!discardLogPath || !fs.existsSync(discardLogPath)) return '';

  const content = fs.readFileSync(discardLogPath, 'utf8');
  const lines = content.split('\n').filter(Boolean);

  const counts: Record<string, number> = {};

  const reasonMap: [string, DiscardReason][] = [
    ['Wrong category',  'Wrong category'],
    ['Thin content',    'Thin content'],
    ['No website',      'No website'],
    ['Domain chain',    'Domain chain'],
    ['Name chain',      'Name chain'],
    ['Franchise',       'Name chain'],
    ['Geo',             'Geo mismatch'],
    ['Entity',          'No website'],
  ];

  for (const line of lines) {
    for (const [pattern, label] of reasonMap) {
      // Match only the structured marker — the old `|| line.includes(pattern)`
      // fallback matched any line containing e.g. "Geo" and miscounted reasons.
      if (line.includes(`DISCARDED: ${pattern}`)) {
        counts[label] = (counts[label] ?? 0) + 1;
        break;
      }
    }
  }

  if (Object.keys(counts).length === 0) return '';

  // Return the most frequent reason
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0] as DiscardReason;
}

type ResultLabel = 'PASS' | 'PARTIAL' | 'THIN MARKET' | 'FAIL';

function classifyResult(verified: number, hadMarketRealityWarning: boolean): ResultLabel {
  if (verified >= 5) return 'PASS';
  if (verified >= 2) return 'PARTIAL';
  if (verified >= 1 && hadMarketRealityWarning) return 'THIN MARKET';
  return 'FAIL';
}

function buildNotes(result: ResultLabel, topDiscardReason: DiscardReason): string {
  if ((result === 'FAIL' || result === 'PARTIAL') && topDiscardReason === 'Wrong category') {
    return 'Check category filter';
  }
  return '';
}

function websiteStatus(l: EnrichedListing): string {
  if (l.websiteUrl && l.websiteVerified) return 'verified';
  if (l.websiteUrl) return 'unverified';
  if (l.socialUrl) return 'social_only';
  if (l.mapsUrl) return 'maps_only';
  return 'none';
}

function writeVerifiedResults(runId: string, date: string, stats: RunStats): void {
  if (!stats.listings || stats.listings.length === 0) return;

  const fileExists = fs.existsSync(RESULTS_PATH);
  if (!fileExists) {
    fs.writeFileSync(RESULTS_PATH, VERIFIED_RESULTS_HEADERS.map(csvCell).join(',') + '\n');
  }

  const machine = os.hostname();
  const { primary, backup } = selectListings(stats.listings);

  const rows = [
    ...primary.map(l => buildResultRow(runId, date, machine, stats, 'primary', l)),
    ...backup.map(l => buildResultRow(runId, date, machine, stats, 'backup', l)),
  ];

  fs.appendFileSync(RESULTS_PATH, rows.join('\n') + '\n');
}

function selectListings(listings: EnrichedListing[]): { primary: EnrichedListing[]; backup: EnrichedListing[] } {
  const withWebsite = listings.filter(l => l.websiteUrl && l.websiteUrl.trim() !== '');
  const fallback = listings.filter(l => (!l.websiteUrl || !l.websiteUrl.trim()) && (l.socialUrl || l.mapsUrl));
  const verified = withWebsite.filter(l => l.websiteVerified);
  const primary = verified.slice(0, 5);
  const backupPool = [...verified.slice(5), ...withWebsite.filter(l => !l.websiteVerified), ...fallback];
  return { primary, backup: backupPool.slice(0, 3) };
}

function buildResultRow(runId: string, date: string, machine: string, stats: RunStats, tier: string, l: EnrichedListing): string {
  return [
    runId,
    date,
    machine,
    stats.site,
    stats.city,
    stats.vertical,
    tier,
    l.name,
    l.rating !== null ? l.rating.toFixed(1) : '',
    l.reviewCount !== null ? String(l.reviewCount) : '',
    l.websiteUrl ?? l.socialUrl ?? '',
    websiteStatus(l),
    l.mapsUrl ?? '',
  ].map(csvCell).join(',');
}

export function logRun(stats: RunStats): void {
  try {
    ensureReportExists();

    const runId = getNextRunId();
    const version = getVersion();
    const date = new Date().toISOString().slice(0, 10);
    const machine = os.hostname();
    const topDiscardReason = parseTopDiscardReason(stats.discardLogPath);
    const result = classifyResult(stats.verified, stats.hadMarketRealityWarning);
    const notes = buildNotes(result, topDiscardReason);

    const row = [
      runId,
      date,
      version,
      machine,
      stats.site,
      stats.city,
      stats.vertical,
      stats.totalScraped,
      stats.totalCandidates,
      stats.verified,
      result,
      topDiscardReason,
      notes,
    ].map(csvCell).join(',');

    fs.appendFileSync(REPORT_PATH, row + '\n');
    writeDiscards(runId, date, stats);
    writeVerifiedResults(runId, date, stats);
    console.log(`\n[baseline] Run logged → ${REPORT_PATH} (${runId} — ${result})`);

    updateSummary();
  } catch (err) {
    console.warn(`[baseline] Failed to log run: ${err}`);
  }
}

function updateSummary(): void {
  try {
    if (!fs.existsSync(REPORT_PATH)) return;

    const lines = fs.readFileSync(REPORT_PATH, 'utf8').split('\n').filter(Boolean);
    // Skip header
    const dataLines = lines.slice(1);

    // Parse rows
    const summaryMap = new Map<string, {
      total: number; pass: number; partial: number; thin: number; fail: number; lastDate: string;
    }>();

    for (const line of dataLines) {
      // Simple CSV parse (handles quoted fields)
      const cols = parseCsvLine(line);
      if (cols.length < 9) continue;

      const vertical   = cols[6] ?? '';  // Run ID, Date, Version, Machine, Site, City, Vertical
      const result     = cols[10] ?? ''; // ..., Total Scraped, Total Candidates, Verified, Result
      const date       = cols[1] ?? '';

      if (!vertical) continue;

      const existing = summaryMap.get(vertical) ?? { total: 0, pass: 0, partial: 0, thin: 0, fail: 0, lastDate: '' };
      existing.total++;
      if (result === 'PASS')         existing.pass++;
      else if (result === 'PARTIAL') existing.partial++;
      else if (result === 'THIN MARKET') existing.thin++;
      else if (result === 'FAIL')    existing.fail++;
      if (date > existing.lastDate)  existing.lastDate = date;
      summaryMap.set(vertical, existing);
    }

    const summaryLines = [SUMMARY_HEADERS.map(csvCell).join(',')];
    for (const [vertical, s] of summaryMap.entries()) {
      const passRate = s.total > 0 ? Math.round((s.pass / s.total) * 100) : 0;
      summaryLines.push([
        vertical,
        s.total,
        s.pass,
        s.partial,
        s.thin,
        s.fail,
        `${passRate}%`,
        s.lastDate,
      ].map(csvCell).join(','));
    }

    const tmpPath = SUMMARY_PATH + '.tmp';
    fs.writeFileSync(tmpPath, summaryLines.join('\n') + '\n');
    fs.renameSync(tmpPath, SUMMARY_PATH);
  } catch (err) {
    console.warn(`[baseline] Failed to update summary: ${err}`);
  }
}

/** Minimal CSV line parser that handles double-quoted fields */
function parseCsvLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += ch;
    }
  }
  result.push(current);
  return result;
}

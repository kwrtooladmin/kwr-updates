import * as dotenv from 'dotenv';
import * as path from 'path';
import * as fs from 'fs';
import { CliArgs, AppConfig } from './types';

dotenv.config();

function envFloat(key: string, fallback: number): number {
  const val = process.env[key];
  if (!val) return fallback;
  const parsed = parseFloat(val);
  return isNaN(parsed) ? fallback : parsed;
}

function envInt(key: string, fallback: number): number {
  const val = process.env[key];
  if (!val) return fallback;
  const parsed = parseInt(val, 10);
  return isNaN(parsed) ? fallback : parsed;
}

function envBool(key: string, fallback: boolean): boolean {
  const val = process.env[key];
  if (!val) return fallback;
  return val.toLowerCase() !== 'false' && val !== '0';
}

export function buildConfig(args: CliArgs): AppConfig {
  const outputDir = process.env.KWR_OUTPUT_DIR ?? './output';
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const safeCity = args.city.replace(/\s+/g, '-').toLowerCase();
  const safeVertical = args.vertical.replace(/\s+/g, '-').toLowerCase();
  const outputPath = path.join(outputDir, `kwr-${safeCity}-${safeVertical}-${timestamp}.csv`);

  // Ensure output directory exists
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  return {
    ...args,
    city: args.city.replace(/^"|"$/g, '').trim(),
    minRating: envFloat('KWR_MIN_RATING', 4.5),
    minReviews: envInt('KWR_MIN_REVIEWS', 100),
    fallbackMinRating: envFloat('KWR_FALLBACK_RATING', 4.0),
    fallbackMinReviews: envInt('KWR_FALLBACK_REVIEWS', 30),
    targetResults: envInt('KWR_TARGET_COUNT', 30),
    maxScrollAttempts: envInt('KWR_MAX_SCROLL', 15),
    targetListingCount: envInt('KWR_TARGET_COUNT', 30),
    discoveryCount: envInt('KWR_DISCOVERY_COUNT', 60),
    viewportWidth: 1366,
    viewportHeight: 768,
    headless: envBool('KWR_HEADLESS', true),
    outputPath,
    minCandidates: envInt('KWR_MIN_CANDIDATES', 3),
  };
}

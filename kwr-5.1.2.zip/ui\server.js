'use strict';

const express = require('express');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');
const https = require('https');
const crypto = require('crypto');
const xlsx = require('xlsx');
let _open;

// ── Auto-update check ─────────────────────────────────────────────────────────

const VERSION_URL = 'https://raw.githubusercontent.com/kwrtooladmin/kwr-updates/main/version.json';
const LOCAL_VERSION = require('../package.json').version;

// True only when `remote` is strictly newer than `local` (semver-ish: numeric
// dot parts). Prevents downgrade prompts and a perpetual banner on a dev machine
// running an unpublished build.
function isNewerVersion(remote, local) {
  if (!remote || typeof remote !== 'string') return false;
  const r = remote.split('.').map((n) => parseInt(n, 10) || 0);
  const l = local.split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(r.length, l.length); i++) {
    const a = r[i] || 0, b = l[i] || 0;
    if (a > b) return true;
    if (a < b) return false;
  }
  return false;
}

function checkForUpdates() {
  https.get(VERSION_URL, (res) => {
    let data = '';
    res.on('data', (chunk) => data += chunk);
    res.on('end', () => {
      try {
        const { version, message } = JSON.parse(data);
        if (isNewerVersion(version, LOCAL_VERSION)) {
          console.log(`\n*** UPDATE AVAILABLE: v${version} (you have v${LOCAL_VERSION}) ***`);
          console.log(`*** Open the tool in your browser and click "Update now". ***\n`);
        } else {
          console.log(`[update] ${message || 'You are on the latest version.'} (v${LOCAL_VERSION})`);
        }
      } catch {}
    });
  }).on('error', () => {
    // Silently skip if offline or GitHub unreachable
  });
}

const app = express();
const PREFERRED_PORT = 3000;
const ROOT = path.join(__dirname, '..');
const OUTPUT_DIR = path.join(ROOT, 'output');
const HISTORY_FILE = path.join(__dirname, 'run-history.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── Run history ──────────────────────────────────────────────────────────────

function loadHistory() {
  if (!fs.existsSync(HISTORY_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf8')); }
  catch { return []; }
}

function saveHistory(history) {
  fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
}

// ── SSE helpers ──────────────────────────────────────────────────────────────

const clients = new Set();

// Buffer for current batch — replayed to clients that reconnect mid-run
let eventBuffer = [];
let lastDelayTick = null; // only keep the latest tick, not all of them

const EVENT_BUFFER_CAP = 2000; // bound memory + reconnect replay on long batches

function bufferEvent(data) {
  if (data.type === 'delay_tick') {
    lastDelayTick = data;
    return; // don't push ticks into buffer — we'll inject the latest on connect
  }
  eventBuffer.push(data);
  if (eventBuffer.length > EVENT_BUFFER_CAP) {
    eventBuffer.splice(0, eventBuffer.length - EVENT_BUFFER_CAP);
  }
}

function broadcast(data) {
  bufferEvent(data);
  const msg = `data: ${JSON.stringify(data)}\n\n`;
  clients.forEach((res) => res.write(msg));
}

app.get('/events', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  // Replay buffered events so a reconnecting browser catches up
  for (const event of eventBuffer) {
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  }
  // If we're mid-cooldown, send the latest tick so the timer shows immediately
  if (lastDelayTick) {
    res.write(`data: ${JSON.stringify(lastDelayTick)}\n\n`);
  }

  clients.add(res);
  req.on('close', () => clients.delete(res));
});

// ── Run state ─────────────────────────────────────────────────────────────────

let activeProcess = null;
let isStopped = false;
let batchRunning = false;

// ── Run a single job ──────────────────────────────────────────────────────────

async function runJob(job, jobIndex, total) {
  return new Promise((resolve) => {
    const { site, city, vertical, id } = job;

    broadcast({ type: 'job_start', id, jobIndex, total, site, city, vertical });

    // Build a single shell string. Quoting differs by platform:
    // Windows cmd.exe: escape embedded quotes as "" inside double-quoted strings.
    // Mac/Linux bash: escape embedded single-quotes as '\'' inside single-quoted strings.
    let cmd;
    if (process.platform === 'win32') {
      const shellEsc = (s) => `"${String(s).replace(/"/g, '""')}"`;
      cmd = `npm run dev -- --site ${shellEsc(site)} --city ${shellEsc(city)} --vertical ${shellEsc(vertical)}`;
    } else {
      const shellEsc = (s) => `'${String(s).replace(/'/g, "'\\''")}'`;
      cmd = `npm run dev -- --site ${shellEsc(site)} --city ${shellEsc(city)} --vertical ${shellEsc(vertical)}`;
    }

    const proc = spawn(cmd, {
      cwd: ROOT,
      shell: true,
      env: { ...process.env },
    });

    activeProcess = proc;

    let outputLines = [];

    function onData(data) {
      const lines = data.toString().split(/\r?\n/);
      lines.forEach((line) => {
        if (!line) return;
        outputLines.push(line);
        broadcast({ type: 'log', id, line });
      });
    }

    proc.stdout.on('data', onData);
    proc.stderr.on('data', onData);

    proc.on('close', (code) => {
      activeProcess = null;

      // Find the CSV written for this run
      let csvFile = null;
      const doneMatch = outputLines.find((l) => l.includes('Output written to:') || l.includes('Empty CSV written to:'));
      if (doneMatch) {
        const match = doneMatch.match(/(?:Output written to:|Empty CSV written to:)\s*(.+\.csv)/);
        if (match) csvFile = path.basename(match[1].trim());
      }

      // Fallback: newest CSV in output dir
      if (!csvFile && fs.existsSync(OUTPUT_DIR)) {
        const csvs = fs.readdirSync(OUTPUT_DIR)
          .filter((f) => f.endsWith('.csv'))
          .map((f) => ({ f, t: fs.statSync(path.join(OUTPUT_DIR, f)).mtimeMs }))
          .sort((a, b) => b.t - a.t);
        if (csvs.length) csvFile = csvs[0].f;
      }

      // Find the discard log written for this run
      let discardLogFile = null;
      const discardMatch = outputLines.find((l) => l.includes('Discard log ('));
      if (discardMatch) {
        const m = discardMatch.match(/Discard log \(\d+ entries\):\s*(.+-discards\.log)/);
        if (m) discardLogFile = path.basename(m[1].trim());
      }

      // Count verified from log
      let verified = 0;
      const verLine = outputLines.find((l) => /Verified websites:/.test(l));
      if (verLine) {
        const m = verLine.match(/Verified websites:\s*(\d+)/);
        if (m) verified = parseInt(m[1], 10);
      }

      // Tally discard reasons from log lines like: [DISCARDED: Wrong category] "Foo Bar"
      let topDiscardReason = '';
      const discardCounts = {};
      for (const line of outputLines) {
        const m = line.match(/\[DISCARDED:\s*([^\]]+)\]/);
        if (m) {
          const reason = m[1].trim();
          discardCounts[reason] = (discardCounts[reason] || 0) + 1;
        }
      }
      const discardEntries = Object.entries(discardCounts).sort((a, b) => b[1] - a[1]);
      if (discardEntries.length > 0) {
        const [reason, count] = discardEntries[0];
        topDiscardReason = `${count} discarded — ${reason}`;
      }

      // Derive true result from baseline log line: [baseline] Run logged → ... (PASS/PARTIAL/FAIL/THIN MARKET)
      let baselineResult = null;
      const baselineLine = outputLines.find(l => /\[baseline\]/.test(l));
      if (baselineLine) {
        const m = baselineLine.match(/—\s*(PASS|PARTIAL|FAIL|THIN MARKET)\s*\)/);
        if (m) baselineResult = m[1];
      }

      let status;
      if (isStopped) {
        status = 'stopped';
      } else if (code !== 0) {
        status = 'failed';
      } else if (baselineResult === 'PASS') {
        status = 'completed';
      } else if (baselineResult === 'PARTIAL' || baselineResult === 'THIN MARKET' || baselineResult === 'FAIL') {
        status = baselineResult.toLowerCase().replace(' ', '-');
      } else {
        status = 'completed';
      }

      const entry = {
        id,
        site,
        city,
        vertical,
        status,
        verified,
        csvFile,
        discardLogFile,
        topDiscardReason,
        completedAt: new Date().toISOString(),
      };

      const history = loadHistory();
      history.unshift(entry);
      saveHistory(history);

      broadcast({ type: 'job_done', ...entry, jobIndex, total });
      resolve(entry);
    });
  });
}

// ── POST /run ─────────────────────────────────────────────────────────────────

app.post('/run', async (req, res) => {
  if (!isLocalRequest(req)) return res.status(403).json({ error: 'Forbidden' });
  const { jobs } = req.body;
  if (!jobs || !jobs.length) return res.status(400).json({ error: 'No jobs' });
  // Reject a second batch while one is running — concurrent batches clobber
  // activeProcess, scramble history, and /stop would only kill one.
  if (batchRunning) return res.status(409).json({ error: 'A batch is already running' });

  batchRunning = true;
  res.json({ ok: true });

  isStopped = false;
  eventBuffer = [];
  lastDelayTick = null;

  try {
    for (let i = 0; i < jobs.length; i++) {
      if (isStopped) break;

      const job = { ...jobs[i], id: `${Date.now()}-${i}` };
      await runJob(job, i + 1, jobs.length);

      if (isStopped) break;

      // 2-minute delay between jobs (skip after last)
      if (i < jobs.length - 1) {
        broadcast({ type: 'delay', seconds: 120 });
        await new Promise((resolve) => {
          let remaining = 120;
          const tick = setInterval(() => {
            if (isStopped || remaining <= 0) {
              clearInterval(tick);
              resolve();
              return;
            }
            remaining--;
            broadcast({ type: 'delay_tick', remaining });
          }, 1000);
        });
      }
    }
  } finally {
    batchRunning = false;
    broadcast({ type: 'batch_done' });
  }
});

// ── POST /stop ────────────────────────────────────────────────────────────────

app.post('/stop', (req, res) => {
  if (!isLocalRequest(req)) return res.status(403).json({ error: 'Forbidden' });
  isStopped = true;
  if (activeProcess) {
    try {
      // On Windows, SIGTERM doesn't propagate through shell-spawned processes.
      // taskkill /T kills the entire process tree including npm → ts-node → chromium.
      if (process.platform === 'win32') {
        spawn('taskkill', ['/pid', String(activeProcess.pid), '/T', '/F'], { shell: true });
      } else {
        process.kill(-activeProcess.pid, 'SIGTERM');
      }
    } catch {}
  }
  res.json({ ok: true });
});

// ── POST /shutdown ────────────────────────────────────────────────────────────

app.post('/shutdown', (req, res) => {
  if (!isLocalRequest(req)) return res.status(403).json({ error: 'Forbidden' });
  if (activeProcess) {
    return res.status(409).json({ error: 'A run is in progress' });
  }
  res.json({ ok: true });
  broadcast({ type: 'shutdown' });
  setTimeout(() => process.exit(0), 500);
});

// ── Update helpers ────────────────────────────────────────────────────────────

function fetchJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', (c) => data += c);
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } });
    }).on('error', reject);
  });
}

// Download a URL to a file, following redirects (GitHub release assets redirect).
// Hardened against silent hangs: a stalled or aborted connection rejects instead
// of leaving the promise (and the UI's "Downloading…") pending forever.
function downloadFile(url, dest, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 5) return reject(new Error('Too many redirects'));
    let settled = false;
    const done = (err) => {
      if (settled) return;
      settled = true;
      if (err) { try { fs.unlinkSync(dest); } catch {} reject(err); }
      else resolve();
    };
    const req = https.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return downloadFile(res.headers.location, dest, redirects + 1).then(resolve, reject);
      }
      if (res.statusCode !== 200) {
        res.resume();
        return done(new Error(`Download failed: HTTP ${res.statusCode}`));
      }
      const file = fs.createWriteStream(dest);
      res.on('error', done);
      res.on('aborted', () => done(new Error('Download connection aborted')));
      file.on('error', done);
      file.on('finish', () => file.close(() => done()));
      res.pipe(file);
    });
    req.on('error', done);
    // Abort if no data flows for 60s (dropped/stalled connection).
    req.setTimeout(60000, () => { req.destroy(new Error('Download timed out')); });
  });
}

function sha256File(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('data', (d) => hash.update(d));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });
}

// Extract a .zip using PowerShell's built-in Expand-Archive (no npm dep needed).
// Paths are single-quoted for PowerShell with embedded apostrophes doubled, so a
// Windows username containing ' (e.g. O'Brien) can't break quoting or inject.
function extractZip(zipPath, destDir) {
  return new Promise((resolve, reject) => {
    const q = (s) => `'${String(s).replace(/'/g, "''")}'`;
    const ps = `Expand-Archive -LiteralPath ${q(zipPath)} -DestinationPath ${q(destDir)} -Force`;
    const child = spawn('powershell', ['-NoProfile', '-NonInteractive', '-Command', ps], { stdio: 'ignore' });
    child.on('error', reject);
    child.on('close', (code) => code === 0 ? resolve() : reject(new Error(`Expand-Archive exited ${code}`)));
  });
}

// GitHub release zips wrap everything in a single top-level folder. Find the real root.
function resolveExtractRoot(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  if (fs.existsSync(path.join(dir, 'package.json'))) return dir;
  const dirs = entries.filter((e) => e.isDirectory());
  if (dirs.length === 1 && fs.existsSync(path.join(dir, dirs[0].name, 'package.json'))) {
    return path.join(dir, dirs[0].name);
  }
  return dir;
}

let updateInProgress = false;
let serverPort = PREFERRED_PORT;

// Reject cross-origin POSTs so a random website the user visits can't drive-by
// trigger /update or /shutdown via fetch(). Same-origin requests from our own
// served page send no Origin (or a localhost one); browsers always attach a
// cross-origin Origin header, which we block.
function isLocalRequest(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try {
    const h = new URL(origin).hostname;
    return h === 'localhost' || h === '127.0.0.1' || h === '::1';
  } catch { return false; }
}

// ── GET /health ───────────────────────────────────────────────────────────────

app.get('/health', (req, res) => res.json({ ok: true, version: LOCAL_VERSION }));

// ── GET /update-status ───────────────────────────────────────────────────────

app.get('/update-status', (req, res) => {
  https.get(VERSION_URL, (remote) => {
    let data = '';
    remote.on('data', (chunk) => data += chunk);
    remote.on('end', () => {
      try {
        const { version, message } = JSON.parse(data);
        // Auto-update is Windows-only (updater.js uses robocopy). On Mac, report
        // the new version in the console but don't offer the in-app update button.
        const canAutoUpdate = process.platform === 'win32';
        res.json({ localVersion: LOCAL_VERSION, remoteVersion: version, message, updateAvailable: isNewerVersion(version, LOCAL_VERSION) && canAutoUpdate });
      } catch { res.json({ updateAvailable: false }); }
    });
  }).on('error', () => res.json({ updateAvailable: false }));
});

// ── POST /update ──────────────────────────────────────────────────────────────
// Downloads + verifies the new release, then hands off to the detached updater
// and exits this server so the files it uses can be replaced.

app.post('/update', async (req, res) => {
  if (!isLocalRequest(req)) return res.status(403).json({ error: 'Forbidden' });
  if (updateInProgress) return res.status(409).json({ error: 'Update already in progress' });
  if (activeProcess) return res.status(409).json({ error: 'A scrape run is in progress — wait for it to finish' });
  updateInProgress = true;

  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'kwr-update-'));
  const zipPath = path.join(work, 'release.zip');
  const extractDir = path.join(work, 'extracted');

  try {
    const manifest = await fetchJson(VERSION_URL);
    if (!isNewerVersion(manifest.version, LOCAL_VERSION)) {
      throw new Error('No newer version available');
    }
    if (!manifest.zipUrl) throw new Error('Release manifest is missing zipUrl');
    if (!manifest.sha256) throw new Error('Release manifest is missing sha256 checksum — update aborted for safety');

    await downloadFile(manifest.zipUrl, zipPath);

    const actual = await sha256File(zipPath);
    if (actual.toLowerCase() !== manifest.sha256.toLowerCase()) {
      throw new Error('Checksum mismatch — download may be corrupt. Update aborted.');
    }

    fs.mkdirSync(extractDir, { recursive: true });
    await extractZip(zipPath, extractDir);
    const newVersionDir = resolveExtractRoot(extractDir);
    if (!fs.existsSync(path.join(newVersionDir, 'package.json'))) {
      throw new Error('Extracted release does not look like a valid KWR build');
    }

    const backupDir = path.join(ROOT, `.update-backup-${Date.now()}`);

    // Hand off to the detached updater, then shut ourselves down.
    res.json({ ok: true, version: manifest.version });

    const updaterPath = path.join(__dirname, 'updater.js');
    const child = spawn('node', [updaterPath, ROOT, newVersionDir, backupDir, String(serverPort), work], {
      detached: true, stdio: 'ignore', cwd: ROOT,
    });
    child.unref();

    // Give the response time to flush, then exit so files unlock.
    setTimeout(() => process.exit(0), 800);
  } catch (err) {
    updateInProgress = false;
    try { fs.rmSync(work, { recursive: true, force: true }); } catch {}
    if (!res.headersSent) res.status(500).json({ error: String(err.message || err) });
  }
});

// ── GET /history ──────────────────────────────────────────────────────────────

app.get('/history', (req, res) => {
  res.json(loadHistory());
});

// ── POST /history/clear ───────────────────────────────────────────────────────

app.post('/history/clear', (req, res) => {
  if (!isLocalRequest(req)) return res.status(403).json({ error: 'Forbidden' });
  saveHistory([]);
  res.json({ ok: true });
});

// ── GET /known-issues ─────────────────────────────────────────────────────────

app.get('/known-issues', (req, res) => {
  const baselineDir = path.join(ROOT, 'baseline');
  if (!fs.existsSync(baselineDir)) return res.json({ active: [], resolved: [] });

  // Reports are written per-machine as baseline-report-<hostname>.csv, so read them
  // all (the old hardcoded 'baseline-report.csv' never existed → tab was always empty).
  const reportFiles = fs.readdirSync(baselineDir)
    .filter(f => f.startsWith('baseline-report') && f.endsWith('.csv'));
  if (reportFiles.length === 0) return res.json({ active: [], resolved: [] });

  const lines = reportFiles.flatMap(f =>
    fs.readFileSync(path.join(baselineDir, f), 'utf8').split('\n').filter(Boolean).slice(1)
  );

  // Parse rows — headers: Run ID,Date,Version,Machine,Site,City,Vertical,...,Result,Top Discard Reason,Notes
  const rows = lines.map(line => {
    const cols = parseCsvLine(line);
    return {
      runId:    cols[0] ?? '',
      date:     cols[1] ?? '',
      vertical: cols[6] ?? '',
      city:     cols[5] ?? '',
      site:     cols[4] ?? '',
      result:   cols[10] ?? '',
      reason:   cols[11] ?? '',
    };
  }).filter(r => r.vertical);

  // Group by vertical
  const map = new Map();
  for (const r of rows) {
    if (!map.has(r.vertical)) map.set(r.vertical, []);
    map.get(r.vertical).push(r);
  }

  const active = [];
  const resolved = [];

  for (const [vertical, runs] of map.entries()) {
    const fails = runs.filter(r => r.result === 'FAIL' && r.reason === 'Wrong category');
    const passes = runs.filter(r => r.result === 'PASS');
    const lastRun = runs[runs.length - 1];
    const lastResult = lastRun.result;

    if (fails.length >= 2 && lastResult !== 'PASS') {
      active.push({
        vertical,
        failCount: fails.length,
        reason: 'Wrong category',
        lastCity: lastRun.city,
        lastDate: lastRun.date,
        status: 'Investigating',
      });
    } else if (fails.length >= 1 && lastResult === 'PASS' && passes.length >= 1) {
      resolved.push({
        vertical,
        fixedDate: lastRun.date,
        lastCity: lastRun.city,
        failCount: fails.length,
      });
    }
  }

  res.json({ active, resolved });
});

function parseCsvLine(line) {
  const result = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') { current += '"'; i++; }
      else inQuotes = !inQuotes;
    } else if (ch === ',' && !inQuotes) {
      result.push(current); current = '';
    } else { current += ch; }
  }
  result.push(current);
  return result;
}

// ── GET /download/log/:filename ───────────────────────────────────────────────

app.get('/download/log/:filename', (req, res) => {
  const file = path.join(OUTPUT_DIR, path.basename(req.params.filename));
  if (!fs.existsSync(file)) return res.status(404).send('Not found');
  res.download(file);
});

// ── GET /download/csv/:filename ───────────────────────────────────────────────

app.get('/download/csv/:filename', (req, res) => {
  const file = path.join(OUTPUT_DIR, path.basename(req.params.filename));
  if (!fs.existsSync(file)) return res.status(404).send('Not found');
  res.download(file);
});

// ── GET /download/xlsx/:filename ──────────────────────────────────────────────

app.get('/download/xlsx/:filename', (req, res) => {
  const csvPath = path.join(OUTPUT_DIR, path.basename(req.params.filename));
  if (!fs.existsSync(csvPath)) return res.status(404).send('Not found');

  const wb = xlsx.readFile(csvPath);
  const xlsxName = path.basename(req.params.filename, '.csv') + '.xlsx';
  const tmpPath = path.join(OUTPUT_DIR, xlsxName);
  xlsx.writeFile(wb, tmpPath);
  res.download(tmpPath, xlsxName, () => {
    fs.unlink(tmpPath, () => {});
  });
});

// ── Daily email report scheduled task (Windows + Mac) ────────────────────────
// Registered on every launch so settings stay correct after the folder is moved
// or the tool is updated.
//
// Windows: PowerShell Register-ScheduledTask with AllowStartIfOnBatteries so
//   laptops are not silently skipped (error 0x800710E0).
// Mac: crontab entry at 7am daily. We read the current crontab, remove any
//   stale KWR line, and append the current one — idempotent on every launch.

function registerEmailReportTask() {
  const scriptPath = path.join(__dirname, 'emailReport.js');
  const workDir    = path.join(__dirname, '..');

  if (process.platform === 'win32') {
    const ps = [
      `$a = New-ScheduledTaskAction -Execute 'node' -Argument '"${scriptPath}"' -WorkingDirectory '${workDir}'`,
      `$t = New-ScheduledTaskTrigger -Daily -At 7am`,
      `$s = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable`,
      `Register-ScheduledTask -TaskName 'KWR Daily Email Report' -Action $a -Trigger $t -Settings $s -Force | Out-Null`,
    ].join('; ');
    const child = spawn('powershell', ['-NoProfile', '-NonInteractive', '-Command', ps], {
      stdio: 'ignore',
      detached: true,
    });
    child.on('error', () => {});
    child.unref();
    return;
  }

  if (process.platform === 'darwin') {
    // Build the cron line: 7:00 AM every day, run node emailReport.js from the
    // project root so dotenv resolves .env correctly.
    const nodeBin   = process.execPath;
    const cronLine  = `0 7 * * * cd "${workDir}" && "${nodeBin}" "${scriptPath}" >> /tmp/kwr-email.log 2>&1 # KWR Daily Email Report`;
    const marker    = '# KWR Daily Email Report';

    const readCron = spawn('crontab', ['-l'], { stdio: ['ignore', 'pipe', 'ignore'] });
    let existing = '';
    readCron.stdout.on('data', d => { existing += d.toString(); });
    readCron.on('close', () => {
      // Remove any previous KWR line then append the current one.
      const filtered = existing.split('\n').filter(l => !l.includes(marker)).join('\n').trimEnd();
      const newCron  = (filtered ? filtered + '\n' : '') + cronLine + '\n';
      const writeCron = spawn('crontab', ['-'], { stdio: ['pipe', 'ignore', 'ignore'] });
      writeCron.on('error', () => {});
      writeCron.stdin.end(newCron);
    });
    readCron.on('error', () => {});
    return;
  }
}

// ── Start ─────────────────────────────────────────────────────────────────────

if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR, { recursive: true });

// A machine flagged as QA (a `.qa-mode` file in the project root) never registers
// the daily email task — keeps QA/test runs out of the real reporting. The flag is
// excluded from published builds, so user machines always report normally.
if (fs.existsSync(path.join(ROOT, '.qa-mode'))) {
  console.log('[qa-mode] This machine is flagged QA — daily email report disabled.');
} else {
  registerEmailReportTask();
}
checkForUpdates();

function findPort(preferred) {
  return new Promise((resolve) => {
    const net = require('net');
    const server = net.createServer();
    server.once('error', () => {
      // preferred port busy — let OS pick a free one
      const fallback = net.createServer();
      fallback.once('listening', () => {
        const port = fallback.address().port;
        fallback.close(() => resolve(port));
      });
      fallback.listen(0);
    });
    server.once('listening', () => {
      server.close(() => resolve(preferred));
    });
    server.listen(preferred);
  });
}

// When the updater relaunches us, it sets KWR_PORT so we rebind the SAME port the
// already-open browser tab is polling, and KWR_NO_OPEN so we don't open a 2nd tab.
const preferredPort = parseInt(process.env.KWR_PORT, 10) || PREFERRED_PORT;

findPort(preferredPort).then((PORT) => {
  serverPort = PORT;
  app.listen(PORT, async () => {
    const url = `http://localhost:${PORT}`;
    console.log(`KWR UI running at ${url}`);
    if (PORT !== preferredPort) {
      console.log(`(Port ${preferredPort} was in use — using ${PORT} instead)`);
    }
    if (process.env.KWR_NO_OPEN === '1') return; // relaunched after update — tab already open
    try {
      if (!_open) _open = (await import('open')).default;
      await _open(url);
    } catch {}
  });
});

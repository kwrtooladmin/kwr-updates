import { Page } from 'playwright';
import { RawListing, AppConfig } from './types';
import { CaptchaError, SelectorBrokenError } from './errors';
import { isCaptchaPresent, resolveSelector, validateSelectors } from './selectors';
import { humanScroll } from './humanize';

async function countCards(page: Page, cardSelector: string): Promise<number> {
  return page.$$eval(cardSelector, (els) => els.length);
}

async function extractCard(
  page: Page,
  index: number,
  cardSelector: string,
  nameSelector: string,
  ratingSelector: string,
  reviewSelector: string,
  anchorSelector: string,
): Promise<RawListing | null> {
  return page.evaluate(
    ({
      idx, cardSel, nameSel, ratingSel, reviewSel, anchorSel,
    }: {
      idx: number; cardSel: string; nameSel: string; ratingSel: string;
      reviewSel: string; anchorSel: string;
    }) => {
      const cards = document.querySelectorAll(cardSel);
      const card = cards[idx];
      if (!card) return null;

      const nameEl = card.querySelector(nameSel);
      const ratingEl = card.querySelector(ratingSel);
      const reviewEl = card.querySelector(reviewSel);
      const anchorEl = card.querySelector(anchorSel) as HTMLAnchorElement | null;


      const name = nameEl?.textContent?.trim() ?? '';
      if (!name) return null;

      const ratingText = ratingEl?.textContent?.trim() ?? null;
      const rating = ratingText ? parseFloat(ratingText) : null;

      const reviewText = reviewEl?.textContent?.trim() ?? null;
      // Prefer a parenthesized count like "(1,234)" so a concatenated blob such as
      // "4.5(1,234)" or "1.2 km · 1,049" doesn't merge unrelated digits together.
      let reviewCount = null;
      if (reviewText) {
        const paren = reviewText.match(/\(([\d,]+)\)/);
        const digits = (paren ? paren[1] : reviewText).replace(/[^0-9]/g, '');
        reviewCount = digits ? (parseInt(digits, 10) || null) : null;
      }

      // Category extraction — walk all span spans inside W4Efsd blocks and find
      // the one that looks like a business category (not a number, not a distance).
      // Google Maps shows: "<category> · <distance>" so we grab the first
      // non-numeric, non-empty span that is not a review count or distance.
      let category: string | null = null;
      const categoryCandidates = card.querySelectorAll("div.W4Efsd span span, div.W4Efsd span");
      for (const el of Array.from(categoryCandidates)) {
        const text = el.textContent?.trim() ?? "";
        if (!text) continue;
        // Skip purely numeric/punctuation strings
        if (/^[\d.,·\s]+$/.test(text)) continue;
        // Skip bullet separators
        if (text === "·" || text === "•") continue;
        // Skip distance strings e.g. "1.2 km", "0.5 mi"
        if (/^\d+(\.\d+)?\s*(km|mi|m)$/i.test(text)) continue;
        // Skip rating strings e.g. "4.5(1,049)" or "4.9(96)"
        if (/^\d+\.\d+\s*\([\d,]+\)$/.test(text)) continue;
        // Skip review count in parentheses e.g. "(1,049)" or "(96)"
        if (/^\([\d,]+\)$/.test(text)) continue;
        // Skip open/closed hours e.g. "Open", "Closed", "Opens at 9 AM"
        if (/^(open|closed|opens|closes)/i.test(text)) continue;
        // Skip strings that are too long to be a category label
        if (text.length > 60) continue;
        category = text;
        break;
      }
      const ariaLabel = anchorEl?.getAttribute('aria-label') ?? name;
      const listingUrl = anchorEl?.href ?? null;

      return { name, rating, reviewCount, cardElement: ariaLabel, positionIndex: idx, category, listingUrl };
    },
    { idx: index, cardSel: cardSelector, nameSel: nameSelector, ratingSel: ratingSelector,
      reviewSel: reviewSelector, anchorSel: anchorSelector }
  );
}

export async function scrollAndScrape(page: Page, config: AppConfig): Promise<RawListing[]> {
  const feedSel = await resolveSelector(page, 'sidebarFeed', 20000).catch(async () => {
    if (await isCaptchaPresent(page)) throw new CaptchaError();
    throw new SelectorBrokenError('sidebarFeed');
  });

  await validateSelectors(page);

  const cardSel = await resolveSelector(page, 'listingCard');
  const nameSel = await resolveSelector(page, 'businessName');
  const ratingSel = await resolveSelector(page, 'ratingNumber');
  const reviewSel = await resolveSelector(page, 'reviewCount');
  const anchorSel = await resolveSelector(page, 'listingAnchor');

  let staleCount = 0;
  let lastCount = 0;

  for (let i = 0; i < config.maxScrollAttempts; i++) {
    const currentCount = await countCards(page, cardSel);
    console.log(`  [scraper] Scroll ${i + 1}/${config.maxScrollAttempts}: ${currentCount} cards`);

    if (currentCount >= config.discoveryCount) {
      console.log(`  [scraper] Discovery target reached (${currentCount})`);
      break;
    }

    if (currentCount === lastCount) {
      staleCount++;
      if (staleCount >= 3) {
        // A CAPTCHA thrown mid-scroll freezes the count and looks identical to
        // "end of results" — check before concluding so a challenge surfaces as a
        // real CaptchaError instead of a silently partial scrape.
        if (await isCaptchaPresent(page)) throw new CaptchaError();
        console.log(`  [scraper] Scroll stalled after 3 identical counts -- end of results`);
        break;
      }
    } else {
      staleCount = 0;
    }

    lastCount = currentCount;
    await humanScroll(page, feedSel);
  }

  const totalCards = await countCards(page, cardSel);
  console.log(`  [scraper] Extracting ${totalCards} cards...`);

  const listings: RawListing[] = [];
  for (let i = 0; i < totalCards; i++) {
    const listing = await extractCard(page, i, cardSel, nameSel, ratingSel, reviewSel, anchorSel);
    if (listing) listings.push(listing);
  }

  console.log(`  [scraper] Extracted ${listings.length} valid listings`);
  return listings;
}

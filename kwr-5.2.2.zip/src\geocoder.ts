import { Page } from 'playwright';
import { GeoLocation } from './types';
import { GeocodeError, CaptchaError } from './errors';
import { randomDelay } from './humanize';
import { isCaptchaPresent } from './selectors';
import { isInsideCountry } from './siteMarkets';

// siteToCountry lives in siteMarkets.ts (site -> country table); re-exported so existing imports keep working.
export { siteToCountry } from './siteMarkets';

export const GEO_REGEX = /@(-?\d+\.\d+),(-?\d+\.\d+),([\d\.]+)z/;

/** The business's own pin inside a Google Maps place URL: ...!3d<lat>!4d<lng>... */
const PLACE_PIN_REGEX = /!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/;

/**
 * Coordinates of the business itself. The "@lat,lng,zoom" part of a place URL is only the
 * map's view centre, which can stay on the searched city while the pin is in another country
 * (Liverpool UK search, listing in Liverpool NSW). Prefer the pin; fall back to the view centre.
 */
export function placeCoordsFromUrl(url: string): { lat: number; lng: number } | null {
  const pin = PLACE_PIN_REGEX.exec(url);
  if (pin) return { lat: parseFloat(pin[1]), lng: parseFloat(pin[2]) };
  const view = GEO_REGEX.exec(url);
  return view ? { lat: parseFloat(view[1]), lng: parseFloat(view[2]) } : null;
}

/**
 * Cities that Google Maps sometimes zooms out too far for.
 * Any input matching one of these is always treated as a city
 * regardless of the zoom level returned.
 */
const KNOWN_CITY_COORDS: Record<string, { lat: number; lng: number; zoom: number }> = {
  'ho chi minh': { lat: 10.8230989, lng: 106.6296638, zoom: 11 },
  'ho chi minh city': { lat: 10.8230989, lng: 106.6296638, zoom: 11 },
  'kuala lumpur': { lat: 3.1390, lng: 101.6869, zoom: 11 },
  'phnom penh': { lat: 11.5564, lng: 104.9282, zoom: 11 },
  'vientiane': { lat: 17.9757, lng: 102.6331, zoom: 11 },
};

const KNOWN_CITIES = new Set([
  'ho chi minh', 'ho chi minh city', 'kuala lumpur', 'buenos aires',
  'mexico city', 'new york', 'new york city', 'los angeles', 'san francisco',
  'hong kong', 'sao paulo', 'rio de janeiro', 'cape town', 'dar es salaam',
  'addis ababa', 'port of spain', 'port elizabeth', 'phnom penh',
  'vientiane', 'ulaanbaatar', 'port moresby',
]);

function classifyZoom(zoom: number, cityInput?: string): 'country' | 'region' | 'city' {
  // If the input is a known multi-word city, always treat it as a city
  if (cityInput) {
    const norm = cityInput.toLowerCase().trim();
    if (KNOWN_CITIES.has(norm)) return 'city';
  }
  // Raised threshold — only flag as country if very zoomed out
  if (zoom <= 5) return 'country';
  if (zoom <= 8) return 'region';
  return 'city';
}

function extractGeoFromUrl(url: string, cityInput?: string): GeoLocation | null {
  const match = GEO_REGEX.exec(url);
  if (!match) return null;
  const zoom = parseInt(match[3], 10);
  return {
    lat: parseFloat(match[1]),
    lng: parseFloat(match[2]),
    zoom,
    locationType: classifyZoom(zoom, cityInput),
  };
}

/**
 * Run one geocode query and return the most specific reading. The Maps URL animates
 * from a wide (low-zoom) view to the city as the map pans, so reading it once can
 * catch the early world-level coordinates (the cause of valid cities like "Liverpool"
 * being mis-flagged as country-level). Polling and keeping the highest-zoom reading
 * avoids that.
 */
async function tryGeocode(page: Page, query: string, cityInput: string): Promise<GeoLocation | null> {
  const url = `https://www.google.com/maps/search/${encodeURIComponent(query)}`;
  await page.goto(url, { waitUntil: 'load', timeout: 30000 });
  await randomDelay(2000, 3500);
  if (await isCaptchaPresent(page)) throw new CaptchaError();

  let best = extractGeoFromUrl(page.url(), cityInput);
  for (let i = 0; i < 3; i++) {
    await randomDelay(1200, 1800);
    const g = extractGeoFromUrl(page.url(), cityInput);
    if (g && (!best || g.zoom > best.zoom)) best = g;
  }
  return best;
}

export async function geocodeCity(page: Page, city: string, country?: string | null): Promise<GeoLocation> {
  // Check for known city with hardcoded coordinates first
  const normCity = city.toLowerCase().trim();
  if (KNOWN_CITY_COORDS[normCity]) {
    const coords = KNOWN_CITY_COORDS[normCity];
    return { lat: coords.lat, lng: coords.lng, zoom: coords.zoom, locationType: 'city' };
  }

  // A bare city name is ambiguous ("Halifax", "Hamilton", "Perth"), and Google resolves
  // it using the IP address of whoever runs the tool: from the Philippines "Halifax"
  // lands on Manila and the tool then scrapes Philippine businesses for a Canadian
  // site. So when the site's market country is known, ALWAYS qualify the query with it
  // instead of using it only as a fallback after Google has already answered wrongly.
  // Skip when the user already typed a qualified place ("Halifax, Canada") or when the
  // "city" is the country itself (Singapore, Malta, Hong Kong).
  const alreadyQualified = city.includes(',');
  const cityIsCountry = !!country && normCity === country.toLowerCase();
  const qualify = !!country && !alreadyQualified && !cityIsCountry;
  const query = qualify ? `${city}, ${country}` : city;

  let best = await tryGeocode(page, query, city);

  if (!best) throw new GeocodeError(city);

  // Fail loudly on a wrong-country answer rather than silently scraping the wrong
  // country. Only enforced when we applied the country ourselves: a user who typed an
  // explicit place ("Paris, France" on a UK site) is trusted.
  if (qualify) {
    const inside = isInsideCountry(country!, best.lat, best.lng);
    if (inside === false) {
      throw new GeocodeError(
        city,
        `"${city}" resolved to lat=${best.lat.toFixed(2)}, lng=${best.lng.toFixed(2)}, which is outside ${country}. ` +
        `Refusing to scrape the wrong country. Type the place with its country (e.g. "${city}, ${country}") ` +
        `or check the spelling.`
      );
    }
    console.log(`  [geocoder] "${query}" -> lat=${best.lat.toFixed(2)}, lng=${best.lng.toFixed(2)}` +
      (inside === true ? ` (inside ${country})` : ` (no bounds known for ${country}; not checked)`));
  } else if (!country && !alreadyQualified && !KNOWN_CITIES.has(normCity)) {
    console.warn(
      `  [geocoder] WARNING: no market country is known for this site, so "${city}" was resolved by Google ` +
      `using this computer's location (lat=${best.lat.toFixed(2)}, lng=${best.lng.toFixed(2)}). If these ` +
      `coordinates are in the wrong country, type the place with its country (e.g. "${city}, Canada") ` +
      `or add the site to src/siteMarkets.ts.`
    );
  }

  return best;
}

export function haversineDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function buildSearchUrl(
  vertical: string,
  geo: GeoLocation,
  city?: string,
  country?: string | null,
  lang?: string,
): string {
  let query = vertical;
  if (city) {
    query += ` in ${city}`;
    // Only append country when there is NO city — a city already scopes the search.
    // Appending country alongside a city causes Google to misinterpret the location
    // (e.g. "Hair Salon in Hanoi, United States" for a .com site based in Vietnam).
  } else if (country) {
    query += ` in ${country}`;
  }
  const encoded = encodeURIComponent(query);
  const base = `https://www.google.com/maps/search/${encoded}/@${geo.lat},${geo.lng},${geo.zoom}z`;
  // Default to English (hl=en) so results stay relevant in non-English countries.
  // User can override with --lang flag.
  const language = lang ?? 'en';
  return `${base}?hl=${language}`;
}
